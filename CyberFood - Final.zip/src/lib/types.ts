export type UserType = 'client' | 'owner'

export type User = {
  id: string
  name: string
  email: string
  password: string
  type: UserType
  foodTruckId?: string
  createdAt: string
}

export type DayKey = 'seg' | 'ter' | 'qua' | 'qui' | 'sex' | 'sab' | 'dom'

export type DaySchedule = {
  open: boolean
  start: string
  end: string
}

export type OperatingHours = Record<DayKey, DaySchedule>

export type SubscriptionPlan = 'free' | 'essential' | 'professional'

export type PaymentMethod = 'PIX' | 'Cartão de crédito' | 'Cartão de débito' | 'Dinheiro na retirada'

export type FoodTruck = {
  id: string
  ownerId: string
  name: string
  cnpj: string
  description: string
  category: string
  phone: string
  location: string
  image: string
  isOpen: boolean
  hours: OperatingHours
  isDemo: boolean
  avgRating: number
  totalReviews: number
  prepTime: string
  subscriptionPlan: SubscriptionPlan
  acceptedPayments: PaymentMethod[]
  createdAt: string
}

export type ProductIngredient = {
  inventoryItemId: string
  inventoryItemName: string
  quantity: number
  unit: string
}

export type ProductAddon = {
  id: string
  name: string
  price: number
  inventoryItemId?: string
  consumeQty?: number
  available: boolean
}

export type Product = {
  id: string
  foodTruckId: string
  name: string
  description: string
  price: number
  image: string
  category: string
  ingredients: string[]
  recipe: ProductIngredient[]
  addons: ProductAddon[]
  available: boolean
  createdAt: string
}

export type InventoryCategory = 'Vegetais' | 'Perecíveis' | 'Laticínios' | 'Carnes' | 'Bebidas' | 'Outros'

export type InventoryItem = {
  id: string
  foodTruckId: string
  name: string
  category: InventoryCategory
  quantity: number
  unit: string
  minStock: number
  maxStock: number
}

export type InventoryBatch = {
  id: string
  foodTruckId: string
  inventoryItemId: string
  itemName: string
  addedQty: number
  remainingQty: number
  expiresAt: string
  lotLabel?: string
  addedAt: string
}

export type DisposalRecord = {
  id: string
  foodTruckId: string
  inventoryItemId: string
  itemName: string
  batchId?: string
  quantity: number
  unit: string
  reason: string
  estimatedValue?: number
  createdAt: string
}

export type OrderStatus = 'Novo' | 'Aceito' | 'Preparando' | 'Pronto para retirada' | 'Retirado'

export type CartAddon = {
  addonId: string
  name: string
  price: number
}

export type OrderItem = {
  productId: string
  name: string
  price: number
  quantity: number
  image: string
  addons: CartAddon[]
  finalPrice: number
}

export type Order = {
  id: string
  foodTruckId: string
  foodTruckName: string
  clientId: string
  clientName: string
  items: OrderItem[]
  total: number
  status: OrderStatus
  paymentMethod: PaymentMethod
  notes: string
  createdAt: string
  updatedAt: string
}

export type Favorite = {
  clientId: string
  foodTruckId: string
}

export type Review = {
  id: string
  foodTruckId: string
  clientId: string
  clientName: string
  orderId: string
  rating: number
  comment: string
  createdAt: string
}

export type DiscountType = 'percentage' | 'fixed'

export type Promotion = {
  id: string
  foodTruckId: string
  productId: string
  name: string
  description: string
  discountType: DiscountType
  discountValue: number
  startDate: string
  endDate: string
  active: boolean
  usageCount: number
  createdAt: string
}

export type Restock = {
  id: string
  foodTruckId: string
  inventoryItemId: string
  itemName: string
  addedQty: number
  newQty: number
  note: string
  expiresAt: string
  batchId: string
  createdAt: string
}

export type AuditAction =
  | 'Produto criado'
  | 'Produto editado'
  | 'Produto excluído'
  | 'Estoque alterado'
  | 'Reabastecimento realizado'
  | 'Pedido atualizado'
  | 'Promoção criada'
  | 'Promoção editada'
  | 'Promoção excluída'
  | 'Food Truck aberto'
  | 'Food Truck fechado'
  | 'Configuração alterada'
  | 'Food Truck criado'
  | 'Conta criada'
  | 'Descarte registrado'
  | 'Estoque consumido'

export type AuditLog = {
  id: string
  foodTruckId: string
  action: AuditAction
  description: string
  userId: string
  createdAt: string
}

export type CartItem = {
  cartItemId: string
  productId: string
  name: string
  price: number
  quantity: number
  image: string
  addons: CartAddon[]
  finalPrice: number
}

export type Cart = {
  foodTruckId: string | null
  foodTruckName: string
  items: CartItem[]
  notes: string
}

export type AuthModalMode = 'login' | 'register-client' | 'register-ft'

export type AuthModalState = {
  open: boolean
  mode: AuthModalMode
  returnTo?: string
}

export type Feedback = {
  id: string
  clientId: string
  foodTruckId?: string
  type: 'Reclamação' | 'Sugestão' | 'Elogio'
  subject: string
  message: string
  createdAt: string
}
