import type {
  User, FoodTruck, Product, InventoryItem, Order,
  Favorite, Review, Promotion, Restock, AuditLog, Feedback,
  InventoryBatch, DisposalRecord, CartItem, Cart,
} from './types'
import { DEMO_FOOD_TRUCKS, DEMO_PRODUCTS, DEMO_INVENTORY, DEMO_REVIEWS, DEMO_ORDERS, DEMO_USERS } from './seed'

const KEY = {
  seeded: 'cf_seeded',
  users: 'cf_users',
  foodTrucks: 'cf_food_trucks',
  products: 'cf_products',
  inventory: 'cf_inventory',
  orders: 'cf_orders',
  favorites: 'cf_favorites',
  reviews: 'cf_reviews',
  promotions: 'cf_promotions',
  restocks: 'cf_restocks',
  auditLogs: 'cf_audit_logs',
  feedback: 'cf_feedback',
  batches: 'cf_inventory_batches',
  disposals: 'cf_disposals',
  currentUserId: 'cf_current_user_id',
  theme: 'cf_theme',
  cart: 'cf_cart',
  pendingCartAdd: 'cf_pending_cart_add',
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch { /* */ }
}

export function ensureSeeded() {
  if (localStorage.getItem(KEY.seeded) === '4') return
  // bump version key when seed schema changes
  save(KEY.foodTrucks, DEMO_FOOD_TRUCKS)
  save(KEY.products, DEMO_PRODUCTS)
  save(KEY.inventory, DEMO_INVENTORY)
  save(KEY.reviews, DEMO_REVIEWS)
  save(KEY.orders, DEMO_ORDERS)
  save(KEY.users, DEMO_USERS)
  save(KEY.favorites, [])
  save(KEY.promotions, [])
  save(KEY.restocks, [])
  save(KEY.auditLogs, [])
  save(KEY.feedback, [])
  save(KEY.batches, [])
  save(KEY.disposals, [])
  localStorage.setItem(KEY.seeded, '4')
}

export const storage = {
  getTheme: () => load<'light' | 'dark'>(KEY.theme, 'light'),
  setTheme: (t: 'light' | 'dark') => save(KEY.theme, t),

  getCurrentUserId: () => load<string | null>(KEY.currentUserId, null),
  setCurrentUserId: (id: string | null) => save(KEY.currentUserId, id),

  getUsers: () => load<User[]>(KEY.users, []),
  saveUsers: (users: User[]) => save(KEY.users, users),

  getFoodTrucks: () => load<FoodTruck[]>(KEY.foodTrucks, []),
  saveFoodTrucks: (fts: FoodTruck[]) => save(KEY.foodTrucks, fts),

  getProducts: () => load<Product[]>(KEY.products, []),
  saveProducts: (prods: Product[]) => save(KEY.products, prods),

  getInventory: () => load<InventoryItem[]>(KEY.inventory, []),
  saveInventory: (items: InventoryItem[]) => save(KEY.inventory, items),

  getOrders: () => load<Order[]>(KEY.orders, []),
  saveOrders: (orders: Order[]) => save(KEY.orders, orders),

  getFavorites: () => load<Favorite[]>(KEY.favorites, []),
  saveFavorites: (favs: Favorite[]) => save(KEY.favorites, favs),

  getReviews: () => load<Review[]>(KEY.reviews, []),
  saveReviews: (reviews: Review[]) => save(KEY.reviews, reviews),

  getPromotions: () => load<Promotion[]>(KEY.promotions, []),
  savePromotions: (promos: Promotion[]) => save(KEY.promotions, promos),

  getRestocks: () => load<Restock[]>(KEY.restocks, []),
  saveRestocks: (restocks: Restock[]) => save(KEY.restocks, restocks),

  getAuditLogs: () => load<AuditLog[]>(KEY.auditLogs, []),
  saveAuditLogs: (logs: AuditLog[]) => save(KEY.auditLogs, logs),

  getFeedback: () => load<Feedback[]>(KEY.feedback, []),
  saveFeedback: (fb: Feedback[]) => save(KEY.feedback, fb),

  getBatches: () => load<InventoryBatch[]>(KEY.batches, []),
  saveBatches: (batches: InventoryBatch[]) => save(KEY.batches, batches),

  getDisposals: () => load<DisposalRecord[]>(KEY.disposals, []),
  saveDisposals: (disposals: DisposalRecord[]) => save(KEY.disposals, disposals),

  getCart: () => load<Cart>(KEY.cart, { foodTruckId: null, foodTruckName: '', items: [], notes: '' }),
  saveCart: (cart: Cart) => save(KEY.cart, cart),

  getPendingCartAdd: () => load<{ item: CartItem; ftId: string; ftName: string } | null>(KEY.pendingCartAdd, null),
  savePendingCartAdd: (data: { item: CartItem; ftId: string; ftName: string }) => save(KEY.pendingCartAdd, data),
  clearPendingCartAdd: () => { try { localStorage.removeItem(KEY.pendingCartAdd) } catch { /* */ } },
}

export function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}
