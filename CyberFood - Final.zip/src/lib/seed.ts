import type { FoodTruck, Product, InventoryItem, Order, Review, OperatingHours, User } from './types'

const defaultHours = (): OperatingHours => ({
  seg: { open: true, start: '10:00', end: '20:00' },
  ter: { open: true, start: '10:00', end: '20:00' },
  qua: { open: true, start: '10:00', end: '20:00' },
  qui: { open: true, start: '10:00', end: '20:00' },
  sex: { open: true, start: '10:00', end: '22:00' },
  sab: { open: true, start: '11:00', end: '22:00' },
  dom: { open: false, start: '11:00', end: '18:00' },
})

export const DEMO_FOOD_TRUCKS: FoodTruck[] = [
  {
    id: 'demo-ft-1',
    ownerId: 'demo-owner-1',
    name: 'Burger Express',
    cnpj: '11.222.333/0001-81',
    description: 'Os melhores hambúrgueres artesanais da cidade, feitos com ingredientes selecionados e muito amor. Cada burger é uma experiência única.',
    category: 'Hambúrgueres',
    phone: '(11) 98765-4321',
    location: 'Praça da República, São Paulo',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&h=500&fit=crop&auto=format',
    isOpen: true,
    hours: defaultHours(),
    isDemo: true,
    avgRating: 4.8,
    totalReviews: 247,
    prepTime: '15–25 min',
    subscriptionPlan: 'professional',
    acceptedPayments: ['PIX', 'Cartão de crédito', 'Cartão de débito', 'Dinheiro na retirada'],
    createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'demo-ft-2',
    ownerId: 'demo-owner-2',
    name: 'Taco Loco',
    cnpj: '22.333.444/0001-81',
    description: 'Culinária mexicana autêntica com sabores vibrantes. Tacos, burritos e nachos preparados na hora com receitas tradicionais.',
    category: 'Mexicana',
    phone: '(11) 97654-3210',
    location: 'Parque Ibirapuera, São Paulo',
    image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&h=500&fit=crop&auto=format',
    isOpen: true,
    hours: {
      ...defaultHours(),
      seg: { open: false, start: '11:00', end: '20:00' },
    },
    isDemo: true,
    avgRating: 4.6,
    totalReviews: 189,
    prepTime: '10–20 min',
    subscriptionPlan: 'essential',
    acceptedPayments: ['PIX', 'Dinheiro na retirada'],
    createdAt: '2024-02-01T10:00:00Z',
  },
  {
    id: 'demo-ft-3',
    ownerId: 'demo-owner-3',
    name: 'Pizza Street',
    cnpj: '33.444.555/0001-81',
    description: 'Pizzas italianas com massa crocante feita na hora, molho caseiro e ingredientes premium. Uma fatia de Nápoles no coração da cidade.',
    category: 'Pizza',
    phone: '(11) 96543-2109',
    location: 'Vila Madalena, São Paulo',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&h=500&fit=crop&auto=format',
    isOpen: false,
    hours: {
      ...defaultHours(),
      seg: { open: false, start: '12:00', end: '22:00' },
      ter: { open: false, start: '12:00', end: '22:00' },
      sex: { open: true, start: '12:00', end: '23:00' },
      sab: { open: true, start: '12:00', end: '23:00' },
      dom: { open: true, start: '12:00', end: '21:00' },
    },
    isDemo: true,
    avgRating: 4.9,
    totalReviews: 312,
    prepTime: '20–30 min',
    subscriptionPlan: 'professional',
    acceptedPayments: ['PIX', 'Cartão de crédito', 'Cartão de débito'],
    createdAt: '2024-01-20T10:00:00Z',
  },
  {
    id: 'demo-ft-4',
    ownerId: 'demo-owner-4',
    name: 'Asia Fusion',
    cnpj: '44.555.666/0001-81',
    description: 'Uma viagem gastronômica pela Ásia. De sushis crocantes a noodles quentes, trazemos o melhor da culinária oriental para você.',
    category: 'Asiática',
    phone: '(11) 95432-1098',
    location: 'Liberdade, São Paulo',
    image: 'https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=800&h=500&fit=crop&auto=format',
    isOpen: true,
    hours: {
      ...defaultHours(),
      dom: { open: true, start: '12:00', end: '20:00' },
    },
    isDemo: true,
    avgRating: 4.7,
    totalReviews: 156,
    prepTime: '15–25 min',
    subscriptionPlan: 'essential',
    acceptedPayments: ['PIX', 'Cartão de crédito'],
    createdAt: '2024-03-01T10:00:00Z',
  },
  {
    id: 'demo-ft-5',
    ownerId: 'demo-owner-5',
    name: 'Banana King',
    cnpj: '55.666.777/0001-81',
    description: 'Sobremesas e lanches tropicais com banana como protagonista. Crepes, vitaminas, açaí e muito mais no ritmo tropical.',
    category: 'Sobremesas',
    phone: '(11) 94321-0987',
    location: 'Mercado Municipal, São Paulo',
    image: 'https://images.unsplash.com/photo-1571805341302-f857308690e3?w=800&h=500&fit=crop&auto=format',
    isOpen: true,
    hours: {
      ...defaultHours(),
      sex: { open: true, start: '09:00', end: '21:00' },
      sab: { open: true, start: '09:00', end: '21:00' },
      dom: { open: true, start: '10:00', end: '18:00' },
    },
    isDemo: true,
    avgRating: 4.5,
    totalReviews: 98,
    prepTime: '5–15 min',
    subscriptionPlan: 'free',
    acceptedPayments: ['PIX', 'Dinheiro na retirada'],
    createdAt: '2024-03-15T10:00:00Z',
  },
]

export const DEMO_PRODUCTS: Product[] = [
  // Burger Express
  {
    id: 'dp-1', foodTruckId: 'demo-ft-1', name: 'Smash Burger Clássico', description: 'Blend de angus 180g, queijo cheddar, alface, tomate, cebola caramelizada e molho especial', price: 28.90, image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=300&fit=crop&auto=format', category: 'Hambúrgueres', ingredients: ['Blend angus', 'Queijo cheddar', 'Alface', 'Tomate', 'Cebola'], recipe: [], addons: [
      { id: 'addon-1a', name: 'Bacon extra', price: 5.00, inventoryItemId: 'di-5', consumeQty: 0.05, available: true },
      { id: 'addon-1b', name: 'Queijo duplo', price: 4.00, inventoryItemId: 'di-2', consumeQty: 0.05, available: true },
      { id: 'addon-1c', name: 'Molho especial extra', price: 2.00, available: true },
    ], available: true, createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'dp-2', foodTruckId: 'demo-ft-1', name: 'Double Bacon Smash', description: 'Dois blends de 150g, bacon crocante, queijo americano duplo e maionese temperada', price: 38.90, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop&auto=format', category: 'Hambúrgueres', ingredients: ['Blend angus x2', 'Bacon', 'Queijo americano', 'Maionese'], recipe: [], addons: [
      { id: 'addon-2a', name: 'Bacon extra', price: 5.00, inventoryItemId: 'di-5', consumeQty: 0.05, available: true },
    ], available: true, createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'dp-3', foodTruckId: 'demo-ft-1', name: 'Batata Frita Rústica', description: 'Batatas em palha grossa com sal temperado e ervas frescas', price: 14.90, image: 'https://images.unsplash.com/photo-1576107232684-1279f8a4e7b1?w=400&h=300&fit=crop&auto=format', category: 'Acompanhamentos', ingredients: ['Batata', 'Sal', 'Ervas'], recipe: [], addons: [
      { id: 'addon-3a', name: 'Cheddar derretido', price: 4.00, available: true },
      { id: 'addon-3b', name: 'Bacon bits', price: 3.00, available: true },
    ], available: true, createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'dp-4', foodTruckId: 'demo-ft-1', name: 'Refrigerante Lata', description: 'Coca-Cola, Guaraná ou Sprite gelados', price: 7.00, image: 'https://images.unsplash.com/photo-1581006852262-e4307cf6283a?w=400&h=300&fit=crop&auto=format', category: 'Bebidas', ingredients: [], recipe: [], addons: [], available: true, createdAt: '2024-01-15T10:00:00Z',
  },
  // Taco Loco
  {
    id: 'dp-5', foodTruckId: 'demo-ft-2', name: 'Taco de Carnitas', description: 'Tortilla de milho, carne suína desfiada, pico de gallo, coentro e lime', price: 16.90, image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=300&fit=crop&auto=format', category: 'Tacos', ingredients: ['Tortilla', 'Carnitas', 'Pico de gallo', 'Coentro'], recipe: [], addons: [
      { id: 'addon-5a', name: 'Guacamole', price: 4.00, available: true },
      { id: 'addon-5b', name: 'Jalapeño', price: 2.00, available: true },
    ], available: true, createdAt: '2024-02-01T10:00:00Z',
  },
  {
    id: 'dp-6', foodTruckId: 'demo-ft-2', name: 'Burrito Supremo', description: 'Wrap recheado com arroz, feijão, frango grelhado, guacamole e sour cream', price: 29.90, image: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=400&h=300&fit=crop&auto=format', category: 'Burritos', ingredients: ['Tortilla grande', 'Arroz', 'Feijão', 'Frango', 'Guacamole'], recipe: [], addons: [], available: true, createdAt: '2024-02-01T10:00:00Z',
  },
  {
    id: 'dp-7', foodTruckId: 'demo-ft-2', name: 'Nachos com Queijo', description: 'Chips de tortilla crocantes com molho de queijo derretido, jalapeño e salsa', price: 22.90, image: 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=400&h=300&fit=crop&auto=format', category: 'Nachos', ingredients: ['Chips', 'Molho de queijo', 'Jalapeño', 'Salsa'], recipe: [], addons: [], available: true, createdAt: '2024-02-01T10:00:00Z',
  },
  {
    id: 'dp-8', foodTruckId: 'demo-ft-2', name: 'Agua de Jamaica', description: 'Chá gelado de hibisco com hortelã e uma pitada de limão', price: 9.90, image: 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=300&fit=crop&auto=format', category: 'Bebidas', ingredients: ['Hibisco', 'Hortelã', 'Limão'], recipe: [], addons: [], available: true, createdAt: '2024-02-01T10:00:00Z',
  },
  // Pizza Street
  {
    id: 'dp-9', foodTruckId: 'demo-ft-3', name: 'Margherita Clássica', description: 'Molho de tomate San Marzano, fior di latte, manjericão fresco e azeite extra-virgem', price: 32.90, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop&auto=format', category: 'Pizzas', ingredients: ['Molho tomate', 'Fior di latte', 'Manjericão', 'Azeite'], recipe: [], addons: [
      { id: 'addon-9a', name: 'Queijo extra', price: 5.00, available: true },
      { id: 'addon-9b', name: 'Borda recheada', price: 8.00, available: true },
    ], available: true, createdAt: '2024-01-20T10:00:00Z',
  },
  {
    id: 'dp-10', foodTruckId: 'demo-ft-3', name: 'Pepperoni Picante', description: 'Generosa camada de pepperoni importado, molho de tomate e mix de queijos', price: 38.90, image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=300&fit=crop&auto=format', category: 'Pizzas', ingredients: ['Pepperoni', 'Molho tomate', 'Mix de queijos'], recipe: [], addons: [
      { id: 'addon-10a', name: 'Borda recheada', price: 8.00, available: true },
    ], available: true, createdAt: '2024-01-20T10:00:00Z',
  },
  {
    id: 'dp-11', foodTruckId: 'demo-ft-3', name: 'Massa Alla Carbonara', description: 'Tagliatelle fresco com guanciale, gema de ovo, pecorino romano e pimenta-do-reino', price: 34.90, image: 'https://images.unsplash.com/photo-1555949258-eb67b1ef0ceb?w=400&h=300&fit=crop&auto=format', category: 'Massas', ingredients: ['Tagliatelle', 'Guanciale', 'Gema de ovo', 'Pecorino'], recipe: [], addons: [], available: true, createdAt: '2024-01-20T10:00:00Z',
  },
  {
    id: 'dp-12', foodTruckId: 'demo-ft-3', name: 'Limonada Siciliana', description: 'Limonada cremosa com limão siciliano, leite condensado e muito gelo', price: 11.90, image: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400&h=300&fit=crop&auto=format', category: 'Bebidas', ingredients: ['Limão siciliano', 'Leite condensado', 'Água'], recipe: [], addons: [], available: true, createdAt: '2024-01-20T10:00:00Z',
  },
  // Asia Fusion
  {
    id: 'dp-13', foodTruckId: 'demo-ft-4', name: 'Ramen Tonkotsu', description: 'Caldo de osso de porco, noodle artesanal, chashu, ovo marinado e nori', price: 35.90, image: 'https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=400&h=300&fit=crop&auto=format', category: 'Noodles', ingredients: ['Caldo tonkotsu', 'Noodle', 'Chashu', 'Ovo marinado', 'Nori'], recipe: [], addons: [
      { id: 'addon-13a', name: 'Ovo marinado extra', price: 4.00, available: true },
      { id: 'addon-13b', name: 'Chashu extra', price: 8.00, available: true },
      { id: 'addon-13c', name: 'Noodle extra', price: 3.00, available: true },
    ], available: true, createdAt: '2024-03-01T10:00:00Z',
  },
  {
    id: 'dp-14', foodTruckId: 'demo-ft-4', name: 'Pad Thai Clássico', description: 'Macarrão de arroz, camarão, tofu, broto de feijão, amendoim e molho tamarindo', price: 29.90, image: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=400&h=300&fit=crop&auto=format', category: 'Noodles', ingredients: ['Macarrão de arroz', 'Camarão', 'Tofu', 'Amendoim'], recipe: [], addons: [], available: true, createdAt: '2024-03-01T10:00:00Z',
  },
  {
    id: 'dp-15', foodTruckId: 'demo-ft-4', name: 'Spring Rolls (4 un)', description: 'Rolinhos primavera crocantes recheados com vegetais e frango, com molho agridoce', price: 18.90, image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400&h=300&fit=crop&auto=format', category: 'Entradas', ingredients: ['Massa de rolinho', 'Frango', 'Vegetais', 'Molho agridoce'], recipe: [], addons: [], available: true, createdAt: '2024-03-01T10:00:00Z',
  },
  {
    id: 'dp-16', foodTruckId: 'demo-ft-4', name: 'Chá Gelado Matcha', description: 'Matcha premium batido com leite de aveia e adoçado levemente', price: 12.90, image: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&h=300&fit=crop&auto=format', category: 'Bebidas', ingredients: ['Matcha', 'Leite de aveia'], recipe: [], addons: [], available: true, createdAt: '2024-03-01T10:00:00Z',
  },
  // Banana King
  {
    id: 'dp-17', foodTruckId: 'demo-ft-5', name: 'Crepe de Banana Caramelada', description: 'Crepe fino com banana caramelada na manteiga, mel de agave e granola artesanal', price: 19.90, image: 'https://images.unsplash.com/photo-1519676867240-f03562e64548?w=400&h=300&fit=crop&auto=format', category: 'Crepes', ingredients: ['Crepe', 'Banana', 'Mel de agave', 'Granola'], recipe: [], addons: [
      { id: 'addon-17a', name: 'Leite condensado', price: 2.00, available: true },
      { id: 'addon-17b', name: 'Chocolate quente', price: 3.00, available: true },
    ], available: true, createdAt: '2024-03-15T10:00:00Z',
  },
  {
    id: 'dp-18', foodTruckId: 'demo-ft-5', name: 'Açaí Royal 500ml', description: 'Açaí puro batido, granola, banana, morango e leite condensado', price: 24.90, image: 'https://images.unsplash.com/photo-1590301157890-4810ed352733?w=400&h=300&fit=crop&auto=format', category: 'Açaí', ingredients: ['Açaí', 'Granola', 'Banana', 'Morango', 'Leite condensado'], recipe: [], addons: [
      { id: 'addon-18a', name: 'Paçoca', price: 2.00, available: true },
      { id: 'addon-18b', name: 'Mel', price: 2.00, available: true },
    ], available: true, createdAt: '2024-03-15T10:00:00Z',
  },
  {
    id: 'dp-19', foodTruckId: 'demo-ft-5', name: 'Vitamina de Banana', description: 'Vitamina cremosa com banana congelada, leite, aveia e mel', price: 14.90, image: 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?w=400&h=300&fit=crop&auto=format', category: 'Bebidas', ingredients: ['Banana', 'Leite', 'Aveia', 'Mel'], recipe: [], addons: [], available: true, createdAt: '2024-03-15T10:00:00Z',
  },
  {
    id: 'dp-20', foodTruckId: 'demo-ft-5', name: 'Tapioca Tropical', description: 'Tapioca recheada com banana, queijo coalho e raspas de coco', price: 16.90, image: 'https://images.unsplash.com/photo-1571805341302-f857308690e3?w=400&h=300&fit=crop&auto=format', category: 'Tapiocas', ingredients: ['Tapioca', 'Banana', 'Queijo coalho', 'Coco'], recipe: [], addons: [], available: true, createdAt: '2024-03-15T10:00:00Z',
  },
]

export const DEMO_INVENTORY: InventoryItem[] = [
  // Burger Express
  { id: 'di-1', foodTruckId: 'demo-ft-1', name: 'Blend Angus', category: 'Carnes', quantity: 45, unit: 'kg', minStock: 10, maxStock: 60 },
  { id: 'di-2', foodTruckId: 'demo-ft-1', name: 'Queijo Cheddar', category: 'Laticínios', quantity: 8, unit: 'kg', minStock: 5, maxStock: 20 },
  { id: 'di-3', foodTruckId: 'demo-ft-1', name: 'Pão Brioche', category: 'Outros', quantity: 120, unit: 'un', minStock: 30, maxStock: 200 },
  { id: 'di-4', foodTruckId: 'demo-ft-1', name: 'Alface', category: 'Vegetais', quantity: 3, unit: 'kg', minStock: 2, maxStock: 10 },
  { id: 'di-5', foodTruckId: 'demo-ft-1', name: 'Bacon', category: 'Carnes', quantity: 4, unit: 'kg', minStock: 3, maxStock: 15 },
]

export const DEMO_USERS: User[] = [
  { id: 'demo-owner-1', name: 'Ana Burger', email: 'burger@demo.com', password: 'senha123', type: 'owner', foodTruckId: 'demo-ft-1', createdAt: '2024-01-15T10:00:00Z' },
  { id: 'demo-owner-2', name: 'Carlos Taco', email: 'taco@demo.com', password: 'senha123', type: 'owner', foodTruckId: 'demo-ft-2', createdAt: '2024-02-01T10:00:00Z' },
  { id: 'demo-owner-3', name: 'Maria Pizza', email: 'pizza@demo.com', password: 'senha123', type: 'owner', foodTruckId: 'demo-ft-3', createdAt: '2024-01-20T10:00:00Z' },
  { id: 'demo-owner-4', name: 'Kenji Asia', email: 'asia@demo.com', password: 'senha123', type: 'owner', foodTruckId: 'demo-ft-4', createdAt: '2024-03-01T10:00:00Z' },
  { id: 'demo-owner-5', name: 'Beatriz Banana', email: 'banana@demo.com', password: 'senha123', type: 'owner', foodTruckId: 'demo-ft-5', createdAt: '2024-03-15T10:00:00Z' },
  { id: 'demo-client-1', name: 'Maria Santos', email: 'cliente@demo.com', password: 'senha123', type: 'client', createdAt: '2024-04-01T10:00:00Z' },
]

export const DEMO_REVIEWS: Review[] = [
  { id: 'dr-1', foodTruckId: 'demo-ft-1', clientId: 'demo-client-1', clientName: 'Maria Santos', orderId: 'demo-ord-1', rating: 5, comment: 'Melhor hambúrguer que já comi! Carne no ponto certo e o pão era incrível.', createdAt: '2024-06-10T14:30:00Z' },
  { id: 'dr-2', foodTruckId: 'demo-ft-1', clientId: 'demo-client-2', clientName: 'João Silva', orderId: 'demo-ord-2', rating: 4, comment: 'Muito bom! Só achei que poderia ter um pouco mais de molho.', createdAt: '2024-06-12T18:00:00Z' },
  { id: 'dr-3', foodTruckId: 'demo-ft-2', clientId: 'demo-client-1', clientName: 'Maria Santos', orderId: 'demo-ord-3', rating: 5, comment: 'Tacos autênticos e deliciosos! Voltarei com certeza.', createdAt: '2024-06-08T12:00:00Z' },
  { id: 'dr-4', foodTruckId: 'demo-ft-3', clientId: 'demo-client-2', clientName: 'João Silva', orderId: 'demo-ord-4', rating: 5, comment: 'A melhor pizza que já comi num food truck! Massa perfeita.', createdAt: '2024-06-15T20:00:00Z' },
]

export const DEMO_ORDERS: Order[] = [
  {
    id: 'demo-ord-1', foodTruckId: 'demo-ft-1', foodTruckName: 'Burger Express',
    clientId: 'demo-client-1', clientName: 'Maria Santos',
    items: [
      { productId: 'dp-1', name: 'Smash Burger Clássico', price: 28.90, quantity: 2, image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=300&fit=crop&auto=format', addons: [], finalPrice: 28.90 },
      { productId: 'dp-3', name: 'Batata Frita Rústica', price: 14.90, quantity: 1, image: 'https://images.unsplash.com/photo-1576107232684-1279f8a4e7b1?w=400&h=300&fit=crop&auto=format', addons: [], finalPrice: 14.90 },
    ],
    total: 72.70, status: 'Retirado', paymentMethod: 'PIX', notes: '',
    createdAt: '2024-06-10T14:00:00Z', updatedAt: '2024-06-10T14:30:00Z',
  },
  {
    id: 'demo-ord-2', foodTruckId: 'demo-ft-1', foodTruckName: 'Burger Express',
    clientId: 'demo-client-2', clientName: 'João Silva',
    items: [
      { productId: 'dp-2', name: 'Double Bacon Smash', price: 38.90, quantity: 1, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop&auto=format', addons: [], finalPrice: 38.90 },
    ],
    total: 38.90, status: 'Retirado', paymentMethod: 'Cartão de crédito', notes: '',
    createdAt: '2024-06-12T17:30:00Z', updatedAt: '2024-06-12T18:00:00Z',
  },
]
