import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import AuthModal from './components/AuthModal'
import PublicLayout from './layouts/PublicLayout'
import ManageLayout from './layouts/ManageLayout'
import HomePage from './pages/HomePage'
import FoodTruckPage from './pages/FoodTruckPage'
import RegisterFoodTruckPage from './pages/RegisterFoodTruckPage'
import ClientHomePage from './pages/client/ClientHomePage'
import CartPage from './pages/client/CartPage'
import CheckoutPage from './pages/client/CheckoutPage'
import OrderTrackingPage from './pages/client/OrderTrackingPage'
import FavoritesPage from './pages/client/FavoritesPage'
import ClientOrdersPage from './pages/client/ClientOrdersPage'
import ClientProfilePage from './pages/client/ClientProfilePage'
import FeedbackPage from './pages/client/FeedbackPage'
import DashboardPage from './pages/manage/DashboardPage'
import OrdersManagePage from './pages/manage/OrdersManagePage'
import ProductsPage from './pages/manage/ProductsPage'
import InventoryPage from './pages/manage/InventoryPage'
import RestockingPage from './pages/manage/RestockingPage'
import PromotionsPage from './pages/manage/PromotionsPage'
import CustomersPage from './pages/manage/CustomersPage'
import HistoryPage from './pages/manage/HistoryPage'
import SettingsPage from './pages/manage/SettingsPage'
import PlanManagePage from './pages/manage/PlanManagePage'
import LotsPage from './pages/manage/LotsPage'
import WastePage from './pages/manage/WastePage'
import AnalyticsPage from './pages/manage/AnalyticsPage'
import ForecastingPage from './pages/manage/ForecastingPage'
import PlansPage from './pages/PlansPage'

function RequireClient({ children }: { children: React.ReactNode }) {
  const { currentUser } = useApp()
  if (!currentUser) return <Navigate to="/" replace />
  if (currentUser.type !== 'client') return <Navigate to="/manage" replace />
  return <>{children}</>
}

function RequireOwner({ children }: { children: React.ReactNode }) {
  const { currentUser } = useApp()
  if (!currentUser) return <Navigate to="/" replace />
  if (currentUser.type !== 'owner') return <Navigate to="/client" replace />
  return <>{children}</>
}

function AppRoutes() {
  return (
    <>
      <AuthModal />
      <Routes>
        {/* Public */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/food-trucks" element={<HomePage />} />
          <Route path="/food-truck/:id" element={<FoodTruckPage />} />
          <Route path="/food-truck/plans" element={<PlansPage />} />
          <Route path="/register/food-truck" element={<RegisterFoodTruckPage />} />
        </Route>

        {/* Client */}
        <Route path="/client" element={<RequireClient><PublicLayout /></RequireClient>}>
          <Route index element={<ClientHomePage />} />
          <Route path="cart" element={<CartPage />} />
          <Route path="checkout" element={<CheckoutPage />} />
          <Route path="order/:id" element={<OrderTrackingPage />} />
          <Route path="orders" element={<ClientOrdersPage />} />
          <Route path="favorites" element={<FavoritesPage />} />
          <Route path="profile" element={<ClientProfilePage />} />
          <Route path="feedback" element={<FeedbackPage />} />
        </Route>

        {/* Management */}
        <Route path="/manage" element={<RequireOwner><ManageLayout /></RequireOwner>}>
          <Route index element={<DashboardPage />} />
          <Route path="orders" element={<OrdersManagePage />} />
          <Route path="products" element={<ProductsPage />} />
          <Route path="inventory" element={<InventoryPage />} />
          <Route path="restocking" element={<RestockingPage />} />
          <Route path="lots" element={<LotsPage />} />
          <Route path="promotions" element={<PromotionsPage />} />
          <Route path="customers" element={<CustomersPage />} />
          <Route path="history" element={<HistoryPage />} />
          <Route path="settings" element={<SettingsPage />} />
          <Route path="waste" element={<WastePage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
          <Route path="forecasting" element={<ForecastingPage />} />
          <Route path="plans" element={<PlanManagePage />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  )
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AppProvider>
  )
}
