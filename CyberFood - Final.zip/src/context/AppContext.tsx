import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react'
import type {
  User, FoodTruck, Product, InventoryItem, Order, OrderStatus,
  Favorite, Review, Promotion, Restock, AuditLog, Feedback,
  Cart, CartItem, AuthModalState, AuthModalMode, AuditAction,
  PaymentMethod, SubscriptionPlan, InventoryBatch, DisposalRecord,
} from '../lib/types'
import { storage, ensureSeeded, uid } from '../lib/storage'

type AppState = {
  theme: 'light' | 'dark'
  currentUser: User | null
  users: User[]
  foodTrucks: FoodTruck[]
  products: Product[]
  inventory: InventoryItem[]
  orders: Order[]
  favorites: Favorite[]
  reviews: Review[]
  promotions: Promotion[]
  restocks: Restock[]
  auditLogs: AuditLog[]
  feedback: Feedback[]
  batches: InventoryBatch[]
  disposals: DisposalRecord[]
  cart: Cart
  authModal: AuthModalState
}

type Action =
  | { type: 'INIT'; payload: Partial<AppState> }
  | { type: 'SET_THEME'; payload: 'light' | 'dark' }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_FOOD_TRUCKS'; payload: FoodTruck[] }
  | { type: 'SET_PRODUCTS'; payload: Product[] }
  | { type: 'SET_INVENTORY'; payload: InventoryItem[] }
  | { type: 'SET_ORDERS'; payload: Order[] }
  | { type: 'SET_FAVORITES'; payload: Favorite[] }
  | { type: 'SET_REVIEWS'; payload: Review[] }
  | { type: 'SET_PROMOTIONS'; payload: Promotion[] }
  | { type: 'SET_RESTOCKS'; payload: Restock[] }
  | { type: 'SET_AUDIT_LOGS'; payload: AuditLog[] }
  | { type: 'SET_FEEDBACK'; payload: Feedback[] }
  | { type: 'SET_USERS'; payload: User[] }
  | { type: 'SET_CART'; payload: Cart }
  | { type: 'SET_AUTH_MODAL'; payload: AuthModalState }
  | { type: 'SET_BATCHES'; payload: InventoryBatch[] }
  | { type: 'SET_DISPOSALS'; payload: DisposalRecord[] }

const initialCart: Cart = { foodTruckId: null, foodTruckName: '', items: [], notes: '' }
const closedModal: AuthModalState = { open: false, mode: 'login' }

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'INIT': return { ...state, ...action.payload }
    case 'SET_THEME': return { ...state, theme: action.payload }
    case 'SET_USER': return { ...state, currentUser: action.payload }
    case 'SET_FOOD_TRUCKS': return { ...state, foodTrucks: action.payload }
    case 'SET_PRODUCTS': return { ...state, products: action.payload }
    case 'SET_INVENTORY': return { ...state, inventory: action.payload }
    case 'SET_ORDERS': return { ...state, orders: action.payload }
    case 'SET_FAVORITES': return { ...state, favorites: action.payload }
    case 'SET_REVIEWS': return { ...state, reviews: action.payload }
    case 'SET_PROMOTIONS': return { ...state, promotions: action.payload }
    case 'SET_RESTOCKS': return { ...state, restocks: action.payload }
    case 'SET_AUDIT_LOGS': return { ...state, auditLogs: action.payload }
    case 'SET_FEEDBACK': return { ...state, feedback: action.payload }
    case 'SET_USERS': return { ...state, users: action.payload }
    case 'SET_CART': return { ...state, cart: action.payload }
    case 'SET_AUTH_MODAL': return { ...state, authModal: action.payload }
    case 'SET_BATCHES': return { ...state, batches: action.payload }
    case 'SET_DISPOSALS': return { ...state, disposals: action.payload }
    default: return state
  }
}

type AppContextValue = AppState & {
  toggleTheme: () => void
  login: (email: string, password: string) => { ok: boolean; error?: string }
  logout: () => void
  registerClient: (name: string, email: string, password: string) => { ok: boolean; error?: string }
  registerFoodTruck: (ownerName: string, email: string, password: string, ftData: Partial<FoodTruck> & { cnpj: string }) => { ok: boolean; error?: string }
  upgradePlan: (ftId: string, plan: SubscriptionPlan) => void
  openAuthModal: (mode: AuthModalMode, returnTo?: string) => void
  closeAuthModal: () => void
  addToCart: (item: CartItem, ftId: string, ftName: string) => 'added' | 'conflict'
  removeFromCart: (cartItemId: string) => void
  updateCartQty: (cartItemId: string, qty: number) => void
  updateCartNotes: (notes: string) => void
  clearCart: () => void
  placeOrder: (paymentMethod: PaymentMethod) => Order | null
  updateOrderStatus: (orderId: string, status: OrderStatus) => void
  toggleFavorite: (foodTruckId: string) => void
  isFavorite: (foodTruckId: string) => boolean
  addReview: (ftId: string, orderId: string, rating: number, comment: string) => void
  createProduct: (data: Omit<Product, 'id' | 'createdAt'>) => void
  updateProduct: (id: string, data: Partial<Product>) => void
  deleteProduct: (id: string) => void
  createInventoryItem: (data: Omit<InventoryItem, 'id'>) => void
  updateInventoryItem: (id: string, data: Partial<InventoryItem>) => void
  deleteInventoryItem: (id: string) => void
  restock: (ftId: string, itemId: string, qty: number, note: string, expiresAt: string, restockedAt?: string, lotLabel?: string) => void
  registerDisposal: (data: Omit<DisposalRecord, 'id' | 'createdAt'>) => void
  createPromotion: (data: Omit<Promotion, 'id' | 'createdAt'>) => void
  updatePromotion: (id: string, data: Partial<Promotion>) => void
  deletePromotion: (id: string) => void
  incrementPromotionUsage: (promoId: string) => void
  updateFoodTruck: (id: string, data: Partial<FoodTruck>) => void
  deleteFoodTruck: (id: string) => void
  toggleFoodTruckOpen: (id: string) => void
  addAuditLog: (ftId: string, action: AuditAction, description: string) => void
  submitFeedback: (data: Omit<Feedback, 'id' | 'createdAt'>) => void
  getMyFoodTruck: () => FoodTruck | null
  getFoodTruckProducts: (ftId: string) => Product[]
  getFoodTruckOrders: (ftId: string) => Order[]
  getFoodTruckReviews: (ftId: string) => Review[]
  getFoodTruckInventory: (ftId: string) => InventoryItem[]
  getFoodTruckPromotions: (ftId: string) => Promotion[]
  getFoodTruckAuditLogs: (ftId: string) => AuditLog[]
  getFoodTruckRestocks: (ftId: string) => Restock[]
  getFoodTruckBatches: (ftId: string) => InventoryBatch[]
  getFoodTruckDisposals: (ftId: string) => DisposalRecord[]
  getClientOrders: (clientId: string) => Order[]
  getOrderById: (id: string) => Order | null
  getActivePromotionsForFoodTruck: (ftId: string) => Promotion[]
}

const AppCtx = createContext<AppContextValue | null>(null)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, {
    theme: 'light',
    currentUser: null,
    users: [],
    foodTrucks: [],
    products: [],
    inventory: [],
    orders: [],
    favorites: [],
    reviews: [],
    promotions: [],
    restocks: [],
    auditLogs: [],
    feedback: [],
    batches: [],
    disposals: [],
    cart: initialCart,
    authModal: closedModal,
  })

  useEffect(() => {
    ensureSeeded()
    const users = storage.getUsers()
    const currentUserId = storage.getCurrentUserId()
    const currentUser = currentUserId ? users.find(u => u.id === currentUserId) || null : null
    dispatch({
      type: 'INIT',
      payload: {
        theme: storage.getTheme(),
        users,
        currentUser,
        foodTrucks: storage.getFoodTrucks(),
        products: storage.getProducts(),
        inventory: storage.getInventory(),
        orders: storage.getOrders(),
        favorites: storage.getFavorites(),
        reviews: storage.getReviews(),
        promotions: storage.getPromotions(),
        restocks: storage.getRestocks(),
        auditLogs: storage.getAuditLogs(),
        feedback: storage.getFeedback(),
        batches: storage.getBatches(),
        disposals: storage.getDisposals(),
        cart: storage.getCart(),
      },
    })
  }, [])

  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [state.theme])

  const toggleTheme = useCallback(() => {
    const next = state.theme === 'light' ? 'dark' : 'light'
    storage.setTheme(next)
    dispatch({ type: 'SET_THEME', payload: next })
  }, [state.theme])

  const addAuditLog = useCallback((ftId: string, action: AuditAction, description: string) => {
    const log: AuditLog = { id: uid(), foodTruckId: ftId, action, description, userId: state.currentUser?.id || '', createdAt: new Date().toISOString() }
    const logs = [...state.auditLogs, log]
    storage.saveAuditLogs(logs)
    dispatch({ type: 'SET_AUDIT_LOGS', payload: logs })
  }, [state.auditLogs, state.currentUser])

  const login = useCallback((email: string, password: string) => {
    const user = state.users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password)
    if (!user) return { ok: false, error: 'E-mail ou senha incorretos.' }
    storage.setCurrentUserId(user.id)
    dispatch({ type: 'SET_USER', payload: user })

    // Process pending cart add only for client accounts; owners are redirected to /manage
    const pending = storage.getPendingCartAdd()
    if (pending) {
      if (user.type === 'client') {
        const currentCart = state.cart
        if (!currentCart.foodTruckId || currentCart.foodTruckId === pending.ftId) {
          const existing = currentCart.items.find(i => i.cartItemId === pending.item.cartItemId)
          let items: CartItem[]
          if (existing) {
            items = currentCart.items.map(i => i.cartItemId === pending.item.cartItemId ? { ...i, quantity: i.quantity + pending.item.quantity } : i)
          } else {
            items = [...currentCart.items, pending.item]
          }
          const newCart: Cart = { foodTruckId: pending.ftId, foodTruckName: pending.ftName, items, notes: currentCart.notes }
          storage.saveCart(newCart)
          dispatch({ type: 'SET_CART', payload: newCart })
        }
      }
      storage.clearPendingCartAdd()
    }

    return { ok: true }
  }, [state.users, state.cart])

  const logout = useCallback(() => {
    storage.setCurrentUserId(null)
    dispatch({ type: 'SET_USER', payload: null })
  }, [])

  const registerClient = useCallback((name: string, email: string, password: string) => {
    if (state.users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'Este e-mail já está em uso.' }
    }
    const user: User = { id: uid(), name, email, password, type: 'client', createdAt: new Date().toISOString() }
    const users = [...state.users, user]
    storage.saveUsers(users)
    storage.setCurrentUserId(user.id)
    dispatch({ type: 'SET_USERS', payload: users })
    dispatch({ type: 'SET_USER', payload: user })
    return { ok: true }
  }, [state.users])

  const registerFoodTruck = useCallback((ownerName: string, email: string, password: string, ftData: Partial<FoodTruck> & { cnpj: string }) => {
    if (state.users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'Este e-mail já está em uso.' }
    }
    const normalizedCnpj = ftData.cnpj.replace(/\D/g, '')
    const cnpjInUse = state.foodTrucks.find(f => f.cnpj.replace(/\D/g, '') === normalizedCnpj)
    if (cnpjInUse) {
      return { ok: false, error: 'Este CNPJ já está cadastrado na plataforma.' }
    }
    const ftId = uid()
    const ownerId = uid()
    const user: User = { id: ownerId, name: ownerName, email, password, type: 'owner', foodTruckId: ftId, createdAt: new Date().toISOString() }
    const ft: FoodTruck = {
      id: ftId, ownerId,
      name: ftData.name || 'Meu Food Truck',
      cnpj: ftData.cnpj,
      description: ftData.description || '',
      category: ftData.category || 'Outros',
      phone: ftData.phone || '',
      location: ftData.location || '',
      image: ftData.image || 'https://images.unsplash.com/photo-1565123409695-7b5ef63a2efb?w=800&h=500&fit=crop&auto=format',
      isOpen: false,
      hours: ftData.hours || {
        seg: { open: true, start: '10:00', end: '20:00' },
        ter: { open: true, start: '10:00', end: '20:00' },
        qua: { open: true, start: '10:00', end: '20:00' },
        qui: { open: true, start: '10:00', end: '20:00' },
        sex: { open: true, start: '10:00', end: '22:00' },
        sab: { open: true, start: '11:00', end: '22:00' },
        dom: { open: false, start: '11:00', end: '18:00' },
      },
      isDemo: false,
      avgRating: 0,
      totalReviews: 0,
      prepTime: '15–25 min',
      subscriptionPlan: 'free',
      acceptedPayments: ['PIX', 'Dinheiro na retirada'],
      createdAt: new Date().toISOString(),
    }
    const users = [...state.users, user]
    const fts = [...state.foodTrucks, ft]
    storage.saveUsers(users)
    storage.saveFoodTrucks(fts)
    storage.setCurrentUserId(user.id)
    dispatch({ type: 'SET_USERS', payload: users })
    dispatch({ type: 'SET_FOOD_TRUCKS', payload: fts })
    dispatch({ type: 'SET_USER', payload: user })

    const now = new Date().toISOString()
    const log: AuditLog = { id: uid(), foodTruckId: ftId, action: 'Food Truck criado', description: `Food Truck "${ft.name}" criado.`, userId: ownerId, createdAt: now }
    const logs = [...state.auditLogs, log]
    storage.saveAuditLogs(logs)
    dispatch({ type: 'SET_AUDIT_LOGS', payload: logs })
    return { ok: true }
  }, [state.users, state.foodTrucks, state.auditLogs])

  const openAuthModal = useCallback((mode: AuthModalMode, returnTo?: string) => {
    dispatch({ type: 'SET_AUTH_MODAL', payload: { open: true, mode, returnTo } })
  }, [])

  const closeAuthModal = useCallback(() => {
    dispatch({ type: 'SET_AUTH_MODAL', payload: closedModal })
  }, [])

  const addToCart = useCallback((item: CartItem, ftId: string, ftName: string): 'added' | 'conflict' => {
    const cart = state.cart
    if (cart.foodTruckId && cart.foodTruckId !== ftId) return 'conflict'
    const existing = cart.items.find(i => i.cartItemId === item.cartItemId)
    let items: CartItem[]
    if (existing) {
      items = cart.items.map(i => i.cartItemId === item.cartItemId ? { ...i, quantity: i.quantity + item.quantity } : i)
    } else {
      items = [...cart.items, item]
    }
    const newCart: Cart = { foodTruckId: ftId, foodTruckName: ftName, items, notes: cart.notes }
    storage.saveCart(newCart)
    dispatch({ type: 'SET_CART', payload: newCart })
    return 'added'
  }, [state.cart])

  const removeFromCart = useCallback((cartItemId: string) => {
    const items = state.cart.items.filter(i => i.cartItemId !== cartItemId)
    const newCart: Cart = items.length === 0 ? initialCart : { ...state.cart, items }
    storage.saveCart(newCart)
    dispatch({ type: 'SET_CART', payload: newCart })
  }, [state.cart])

  const updateCartQty = useCallback((cartItemId: string, qty: number) => {
    if (qty <= 0) { removeFromCart(cartItemId); return }
    const items = state.cart.items.map(i => i.cartItemId === cartItemId ? { ...i, quantity: qty } : i)
    const newCart = { ...state.cart, items }
    storage.saveCart(newCart)
    dispatch({ type: 'SET_CART', payload: newCart })
  }, [state.cart, removeFromCart])

  const updateCartNotes = useCallback((notes: string) => {
    const newCart = { ...state.cart, notes }
    storage.saveCart(newCart)
    dispatch({ type: 'SET_CART', payload: newCart })
  }, [state.cart])

  const clearCart = useCallback(() => {
    storage.saveCart(initialCart)
    dispatch({ type: 'SET_CART', payload: initialCart })
  }, [])

  const placeOrder = useCallback((paymentMethod: PaymentMethod): Order | null => {
    if (!state.currentUser || !state.cart.foodTruckId || state.cart.items.length === 0) return null
    const total = state.cart.items.reduce((s, i) => s + i.finalPrice * i.quantity, 0)
    const order: Order = {
      id: uid(),
      foodTruckId: state.cart.foodTruckId,
      foodTruckName: state.cart.foodTruckName,
      clientId: state.currentUser.id,
      clientName: state.currentUser.name,
      items: state.cart.items.map(i => ({
        productId: i.productId,
        name: i.name,
        price: i.price,
        quantity: i.quantity,
        image: i.image,
        addons: i.addons,
        finalPrice: i.finalPrice,
      })),
      total,
      status: 'Novo',
      paymentMethod,
      notes: state.cart.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    const orders = [...state.orders, order]
    storage.saveOrders(orders)
    dispatch({ type: 'SET_ORDERS', payload: orders })
    clearCart()
    return order
  }, [state.currentUser, state.cart, state.orders, clearCart])

  const consumeInventoryForOrder = useCallback((order: Order) => {
    const deductions: Record<string, number> = {}

    for (const orderItem of order.items) {
      const product = state.products.find(p => p.id === orderItem.productId)
      if (!product?.recipe?.length) continue

      for (const ingredient of product.recipe) {
        const total = ingredient.quantity * orderItem.quantity
        deductions[ingredient.inventoryItemId] = (deductions[ingredient.inventoryItemId] || 0) + total
      }

      for (const addon of orderItem.addons || []) {
        const productAddon = product.addons?.find(a => a.id === addon.addonId)
        if (productAddon?.inventoryItemId && productAddon?.consumeQty) {
          const total = productAddon.consumeQty * orderItem.quantity
          deductions[productAddon.inventoryItemId] = (deductions[productAddon.inventoryItemId] || 0) + total
        }
      }
    }

    if (Object.keys(deductions).length === 0) return

    // FEFO batch deduction: consume valid lots with nearest expiry first; same expiry → oldest lot first
    const todayStr = new Date().toISOString().slice(0, 10)
    let updatedBatches = [...state.batches]

    for (const [itemId, amount] of Object.entries(deductions)) {
      let remaining = amount
      const validBatchIds = [...updatedBatches]
        .filter(b => b.inventoryItemId === itemId && b.remainingQty > 0 && b.expiresAt >= todayStr)
        .sort((a, b) => a.expiresAt !== b.expiresAt ? a.expiresAt.localeCompare(b.expiresAt) : a.addedAt.localeCompare(b.addedAt))
        .map(b => b.id)

      updatedBatches = updatedBatches.map(b => {
        if (!validBatchIds.includes(b.id) || remaining <= 0) return b
        const deduct = Math.min(b.remainingQty, remaining)
        remaining -= deduct
        return { ...b, remainingQty: b.remainingQty - deduct }
      })
    }

    storage.saveBatches(updatedBatches)
    dispatch({ type: 'SET_BATCHES', payload: updatedBatches })

    const inventory = state.inventory.map(item => {
      const deduct = deductions[item.id] || 0
      return deduct > 0 ? { ...item, quantity: Math.max(0, item.quantity - deduct) } : item
    })

    storage.saveInventory(inventory)
    dispatch({ type: 'SET_INVENTORY', payload: inventory })

    const summary = Object.keys(deductions).map(id => {
      const item = state.inventory.find(i => i.id === id)
      return item ? `${item.name}: -${deductions[id].toFixed(2)} ${item.unit}` : null
    }).filter(Boolean).join(', ')

    if (summary) {
      const log: AuditLog = {
        id: uid(), foodTruckId: order.foodTruckId, action: 'Estoque consumido',
        description: `Pedido #${order.id.slice(-6).toUpperCase()} retirado. Consumo: ${summary}`,
        userId: state.currentUser?.id || '', createdAt: new Date().toISOString(),
      }
      const logs = [...state.auditLogs, log]
      storage.saveAuditLogs(logs)
      dispatch({ type: 'SET_AUDIT_LOGS', payload: logs })
    }
  }, [state.products, state.inventory, state.auditLogs, state.currentUser, state.batches])

  const updateOrderStatus = useCallback((orderId: string, status: OrderStatus) => {
    const orders = state.orders.map(o => o.id === orderId ? { ...o, status, updatedAt: new Date().toISOString() } : o)
    storage.saveOrders(orders)
    dispatch({ type: 'SET_ORDERS', payload: orders })

    const order = orders.find(o => o.id === orderId)
    if (order) {
      const log: AuditLog = { id: uid(), foodTruckId: order.foodTruckId, action: 'Pedido atualizado', description: `Pedido #${orderId.slice(-6).toUpperCase()} atualizado para "${status}".`, userId: state.currentUser?.id || '', createdAt: new Date().toISOString() }
      const logs = [...state.auditLogs, log]
      storage.saveAuditLogs(logs)
      dispatch({ type: 'SET_AUDIT_LOGS', payload: logs })

      if (status === 'Retirado') {
        consumeInventoryForOrder(order)
      }
    }
  }, [state.orders, state.auditLogs, state.currentUser, consumeInventoryForOrder])

  const toggleFavorite = useCallback((foodTruckId: string) => {
    if (!state.currentUser) return
    const clientId = state.currentUser.id
    const exists = state.favorites.find(f => f.clientId === clientId && f.foodTruckId === foodTruckId)
    const favs = exists
      ? state.favorites.filter(f => !(f.clientId === clientId && f.foodTruckId === foodTruckId))
      : [...state.favorites, { clientId, foodTruckId }]
    storage.saveFavorites(favs)
    dispatch({ type: 'SET_FAVORITES', payload: favs })
  }, [state.currentUser, state.favorites])

  const isFavorite = useCallback((foodTruckId: string) => {
    if (!state.currentUser) return false
    return state.favorites.some(f => f.clientId === state.currentUser!.id && f.foodTruckId === foodTruckId)
  }, [state.currentUser, state.favorites])

  const addReview = useCallback((ftId: string, orderId: string, rating: number, comment: string) => {
    if (!state.currentUser) return
    const review: Review = {
      id: uid(), foodTruckId: ftId, clientId: state.currentUser.id,
      clientName: state.currentUser.name, orderId, rating, comment,
      createdAt: new Date().toISOString(),
    }
    const reviews = [...state.reviews, review]
    storage.saveReviews(reviews)
    dispatch({ type: 'SET_REVIEWS', payload: reviews })

    const ftReviews = reviews.filter(r => r.foodTruckId === ftId)
    const avg = ftReviews.reduce((s, r) => s + r.rating, 0) / ftReviews.length
    const fts = state.foodTrucks.map(ft => ft.id === ftId ? { ...ft, avgRating: Math.round(avg * 10) / 10, totalReviews: ftReviews.length } : ft)
    storage.saveFoodTrucks(fts)
    dispatch({ type: 'SET_FOOD_TRUCKS', payload: fts })
  }, [state.currentUser, state.reviews, state.foodTrucks])

  const createProduct = useCallback((data: Omit<Product, 'id' | 'createdAt'>) => {
    const product: Product = { ...data, id: uid(), createdAt: new Date().toISOString() }
    const products = [...state.products, product]
    storage.saveProducts(products)
    dispatch({ type: 'SET_PRODUCTS', payload: products })
    addAuditLog(data.foodTruckId, 'Produto criado', `Produto "${data.name}" criado.`)
  }, [state.products])

  const updateProduct = useCallback((id: string, data: Partial<Product>) => {
    const products = state.products.map(p => p.id === id ? { ...p, ...data } : p)
    storage.saveProducts(products)
    dispatch({ type: 'SET_PRODUCTS', payload: products })
    const p = products.find(p => p.id === id)
    if (p) addAuditLog(p.foodTruckId, 'Produto editado', `Produto "${p.name}" editado.`)
  }, [state.products])

  const deleteProduct = useCallback((id: string) => {
    const p = state.products.find(p => p.id === id)
    const products = state.products.filter(p => p.id !== id)
    storage.saveProducts(products)
    dispatch({ type: 'SET_PRODUCTS', payload: products })
    if (p) addAuditLog(p.foodTruckId, 'Produto excluído', `Produto "${p.name}" excluído.`)
  }, [state.products])

  const createInventoryItem = useCallback((data: Omit<InventoryItem, 'id'>) => {
    const item: InventoryItem = { ...data, id: uid() }
    const inventory = [...state.inventory, item]
    storage.saveInventory(inventory)
    dispatch({ type: 'SET_INVENTORY', payload: inventory })
    addAuditLog(data.foodTruckId, 'Estoque alterado', `Item "${data.name}" adicionado ao estoque.`)
  }, [state.inventory])

  const updateInventoryItem = useCallback((id: string, data: Partial<InventoryItem>) => {
    const inventory = state.inventory.map(i => i.id === id ? { ...i, ...data } : i)
    storage.saveInventory(inventory)
    dispatch({ type: 'SET_INVENTORY', payload: inventory })
    const item = inventory.find(i => i.id === id)
    if (item) addAuditLog(item.foodTruckId, 'Estoque alterado', `Item "${item.name}" atualizado.`)
  }, [state.inventory])

  const deleteInventoryItem = useCallback((id: string) => {
    const item = state.inventory.find(i => i.id === id)
    const inventory = state.inventory.filter(i => i.id !== id)
    storage.saveInventory(inventory)
    dispatch({ type: 'SET_INVENTORY', payload: inventory })
    if (item) addAuditLog(item.foodTruckId, 'Estoque alterado', `Item "${item.name}" removido do estoque.`)
  }, [state.inventory])

  const restock = useCallback((ftId: string, itemId: string, qty: number, note: string, expiresAt: string, restockedAt?: string, lotLabel?: string) => {
    const item = state.inventory.find(i => i.id === itemId)
    if (!item) return
    const newQty = item.quantity + qty
    const inventory = state.inventory.map(i => i.id === itemId ? { ...i, quantity: newQty } : i)
    storage.saveInventory(inventory)
    dispatch({ type: 'SET_INVENTORY', payload: inventory })

    const batchId = uid()
    const batch: InventoryBatch = {
      id: batchId, foodTruckId: ftId, inventoryItemId: itemId, itemName: item.name,
      addedQty: qty, remainingQty: qty, expiresAt,
      lotLabel: lotLabel || undefined,
      addedAt: restockedAt || new Date().toISOString(),
    }
    const batches = [...state.batches, batch]
    storage.saveBatches(batches)
    dispatch({ type: 'SET_BATCHES', payload: batches })

    const rs: Restock = { id: uid(), foodTruckId: ftId, inventoryItemId: itemId, itemName: item.name, addedQty: qty, newQty, note, expiresAt, batchId, createdAt: new Date().toISOString() }
    const restocks = [...state.restocks, rs]
    storage.saveRestocks(restocks)
    dispatch({ type: 'SET_RESTOCKS', payload: restocks })
    addAuditLog(ftId, 'Reabastecimento realizado', `${item.name}: +${qty} ${item.unit}. Total: ${newQty} ${item.unit}. Validade: ${new Date(expiresAt).toLocaleDateString('pt-BR')}.`)
  }, [state.inventory, state.restocks, state.batches])

  const registerDisposal = useCallback((data: Omit<DisposalRecord, 'id' | 'createdAt'>) => {
    const disposal: DisposalRecord = { ...data, id: uid(), createdAt: new Date().toISOString() }
    const disposals = [...state.disposals, disposal]
    storage.saveDisposals(disposals)
    dispatch({ type: 'SET_DISPOSALS', payload: disposals })

    // Update batch remainingQty — specific batch if provided, otherwise FEFO
    const todayStr = new Date().toISOString().slice(0, 10)
    let updatedBatches: InventoryBatch[]

    if (data.batchId) {
      updatedBatches = state.batches.map(b =>
        b.id === data.batchId ? { ...b, remainingQty: Math.max(0, b.remainingQty - data.quantity) } : b
      )
    } else {
      let remaining = data.quantity
      const validBatchIds = [...state.batches]
        .filter(b => b.inventoryItemId === data.inventoryItemId && b.remainingQty > 0 && b.expiresAt >= todayStr)
        .sort((a, b) => a.expiresAt !== b.expiresAt ? a.expiresAt.localeCompare(b.expiresAt) : a.addedAt.localeCompare(b.addedAt))
        .map(b => b.id)

      updatedBatches = state.batches.map(b => {
        if (!validBatchIds.includes(b.id) || remaining <= 0) return b
        const deduct = Math.min(b.remainingQty, remaining)
        remaining -= deduct
        return { ...b, remainingQty: b.remainingQty - deduct }
      })
    }

    storage.saveBatches(updatedBatches)
    dispatch({ type: 'SET_BATCHES', payload: updatedBatches })

    // Deduct from inventory summary total
    const inventory = state.inventory.map(i => i.id === data.inventoryItemId ? { ...i, quantity: Math.max(0, i.quantity - data.quantity) } : i)
    storage.saveInventory(inventory)
    dispatch({ type: 'SET_INVENTORY', payload: inventory })

    const batchNote = data.batchId ? ` Lote: ${data.batchId.slice(-6).toUpperCase()}.` : ''
    addAuditLog(data.foodTruckId, 'Descarte registrado', `${data.itemName}: descartado ${data.quantity} ${data.unit}. Motivo: ${data.reason}.${batchNote}`)
  }, [state.disposals, state.inventory, state.batches])

  const createPromotion = useCallback((data: Omit<Promotion, 'id' | 'createdAt'>) => {
    const promo: Promotion = { ...data, id: uid(), createdAt: new Date().toISOString() }
    const promotions = [...state.promotions, promo]
    storage.savePromotions(promotions)
    dispatch({ type: 'SET_PROMOTIONS', payload: promotions })
    addAuditLog(data.foodTruckId, 'Promoção criada', `Promoção "${data.name}" criada.`)
  }, [state.promotions])

  const updatePromotion = useCallback((id: string, data: Partial<Promotion>) => {
    const promotions = state.promotions.map(p => p.id === id ? { ...p, ...data } : p)
    storage.savePromotions(promotions)
    dispatch({ type: 'SET_PROMOTIONS', payload: promotions })
    const p = promotions.find(p => p.id === id)
    if (p) addAuditLog(p.foodTruckId, 'Promoção editada', `Promoção "${p.name}" editada.`)
  }, [state.promotions])

  const deletePromotion = useCallback((id: string) => {
    const p = state.promotions.find(p => p.id === id)
    const promotions = state.promotions.filter(p => p.id !== id)
    storage.savePromotions(promotions)
    dispatch({ type: 'SET_PROMOTIONS', payload: promotions })
    if (p) addAuditLog(p.foodTruckId, 'Promoção excluída', `Promoção "${p.name}" excluída.`)
  }, [state.promotions])

  const incrementPromotionUsage = useCallback((promoId: string) => {
    const promotions = state.promotions.map(p => p.id === promoId ? { ...p, usageCount: p.usageCount + 1 } : p)
    storage.savePromotions(promotions)
    dispatch({ type: 'SET_PROMOTIONS', payload: promotions })
  }, [state.promotions])

  const updateFoodTruck = useCallback((id: string, data: Partial<FoodTruck>) => {
    const fts = state.foodTrucks.map(ft => ft.id === id ? { ...ft, ...data } : ft)
    storage.saveFoodTrucks(fts)
    dispatch({ type: 'SET_FOOD_TRUCKS', payload: fts })
    addAuditLog(id, 'Configuração alterada', 'Informações do Food Truck atualizadas.')
  }, [state.foodTrucks])

  const deleteFoodTruck = useCallback((id: string) => {
    const fts = state.foodTrucks.filter(ft => ft.id !== id)
    storage.saveFoodTrucks(fts)
    dispatch({ type: 'SET_FOOD_TRUCKS', payload: fts })
    storage.setCurrentUserId(null)
    dispatch({ type: 'SET_USER', payload: null })
  }, [state.foodTrucks])

  const toggleFoodTruckOpen = useCallback((id: string) => {
    const ft = state.foodTrucks.find(f => f.id === id)
    if (!ft) return
    const next = !ft.isOpen
    const fts = state.foodTrucks.map(f => f.id === id ? { ...f, isOpen: next } : f)
    storage.saveFoodTrucks(fts)
    dispatch({ type: 'SET_FOOD_TRUCKS', payload: fts })
    addAuditLog(id, next ? 'Food Truck aberto' : 'Food Truck fechado', next ? 'Food Truck aberto para pedidos.' : 'Food Truck fechado para novos pedidos.')
  }, [state.foodTrucks])

  const upgradePlan = useCallback((ftId: string, plan: SubscriptionPlan) => {
    const fts = state.foodTrucks.map(ft => ft.id === ftId ? { ...ft, subscriptionPlan: plan } : ft)
    storage.saveFoodTrucks(fts)
    dispatch({ type: 'SET_FOOD_TRUCKS', payload: fts })
    addAuditLog(ftId, 'Configuração alterada', `Plano de assinatura alterado para ${plan}.`)
  }, [state.foodTrucks])

  const submitFeedback = useCallback((data: Omit<Feedback, 'id' | 'createdAt'>) => {
    const fb: Feedback = { ...data, id: uid(), createdAt: new Date().toISOString() }
    const feedback = [...state.feedback, fb]
    storage.saveFeedback(feedback)
    dispatch({ type: 'SET_FEEDBACK', payload: feedback })
  }, [state.feedback])

  const getMyFoodTruck = useCallback(() => {
    if (!state.currentUser?.foodTruckId) return null
    return state.foodTrucks.find(ft => ft.id === state.currentUser!.foodTruckId) || null
  }, [state.currentUser, state.foodTrucks])

  const getActivePromotionsForFoodTruck = useCallback((ftId: string): Promotion[] => {
    const today = new Date().toISOString().slice(0, 10)
    return state.promotions.filter(p =>
      p.foodTruckId === ftId &&
      p.active &&
      p.startDate <= today &&
      p.endDate >= today
    )
  }, [state.promotions])

  const getFoodTruckProducts = useCallback((ftId: string) => state.products.filter(p => p.foodTruckId === ftId), [state.products])
  const getFoodTruckOrders = useCallback((ftId: string) => state.orders.filter(o => o.foodTruckId === ftId), [state.orders])
  const getFoodTruckReviews = useCallback((ftId: string) => state.reviews.filter(r => r.foodTruckId === ftId), [state.reviews])
  const getFoodTruckInventory = useCallback((ftId: string) => state.inventory.filter(i => i.foodTruckId === ftId), [state.inventory])
  const getFoodTruckPromotions = useCallback((ftId: string) => state.promotions.filter(p => p.foodTruckId === ftId), [state.promotions])
  const getFoodTruckAuditLogs = useCallback((ftId: string) => state.auditLogs.filter(l => l.foodTruckId === ftId), [state.auditLogs])
  const getFoodTruckRestocks = useCallback((ftId: string) => state.restocks.filter(r => r.foodTruckId === ftId), [state.restocks])
  const getFoodTruckBatches = useCallback((ftId: string) => state.batches.filter(b => b.foodTruckId === ftId), [state.batches])
  const getFoodTruckDisposals = useCallback((ftId: string) => state.disposals.filter(d => d.foodTruckId === ftId), [state.disposals])
  const getClientOrders = useCallback((clientId: string) => state.orders.filter(o => o.clientId === clientId), [state.orders])
  const getOrderById = useCallback((id: string) => state.orders.find(o => o.id === id) || null, [state.orders])

  const value: AppContextValue = {
    ...state,
    toggleTheme, login, logout, registerClient, registerFoodTruck,
    openAuthModal, closeAuthModal,
    addToCart, removeFromCart, updateCartQty, updateCartNotes, clearCart, placeOrder,
    updateOrderStatus, toggleFavorite, isFavorite,
    addReview, createProduct, updateProduct, deleteProduct,
    createInventoryItem, updateInventoryItem, deleteInventoryItem,
    restock, registerDisposal, createPromotion, updatePromotion, deletePromotion, incrementPromotionUsage,
    updateFoodTruck, deleteFoodTruck, toggleFoodTruckOpen, addAuditLog,
    upgradePlan, submitFeedback, getMyFoodTruck, getFoodTruckProducts, getFoodTruckOrders,
    getFoodTruckReviews, getFoodTruckInventory, getFoodTruckPromotions,
    getFoodTruckAuditLogs, getFoodTruckRestocks, getFoodTruckBatches, getFoodTruckDisposals,
    getClientOrders, getOrderById, getActivePromotionsForFoodTruck,
  }

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>
}

export function useApp() {
  const ctx = useContext(AppCtx)
  if (!ctx) throw new Error('useApp must be inside AppProvider')
  return ctx
}
