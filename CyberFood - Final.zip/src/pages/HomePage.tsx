import { useState, useMemo } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import FoodTruckCard from '../components/FoodTruckCard'

const CATEGORIES = ['Todos', 'Hambúrgueres', 'Mexicana', 'Pizza', 'Asiática', 'Sobremesas', 'Brasileira', 'Outros']

export default function HomePage() {
  const { foodTrucks, currentUser } = useApp()
  const [searchParams] = useSearchParams()
  const [category, setCategory] = useState('Todos')
  const [onlyOpen, setOnlyOpen] = useState(false)
  const [search, setSearch] = useState(searchParams.get('q') || '')

  const filtered = useMemo(() => {
    return foodTrucks.filter(ft => {
      const q = search.toLowerCase()
      if (q && !ft.name.toLowerCase().includes(q) && !ft.category.toLowerCase().includes(q) && !ft.description.toLowerCase().includes(q)) return false
      if (category !== 'Todos' && ft.category !== category) return false
      if (onlyOpen && !ft.isOpen) return false
      return true
    })
  }, [foodTrucks, search, category, onlyOpen])

  const openCount = foodTrucks.filter(f => f.isOpen).length

  return (
    <>
      {/* Hero — only show to non-logged-in or client users on home */}
      {(!currentUser || currentUser.type === 'client') && !searchParams.get('q') && (
        <section
          className="relative overflow-hidden"
          style={{ background: 'linear-gradient(135deg, #172033 0%, #1e2d40 50%, #0f1923 100%)' }}
        >
          {/* Decorative orange glow */}
          <div
            className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-20 blur-3xl pointer-events-none"
            style={{ background: 'var(--primary)' }}
          />
          <div
            className="absolute bottom-0 left-1/4 w-64 h-64 rounded-full opacity-10 blur-2xl pointer-events-none"
            style={{ background: 'var(--primary)' }}
          />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24 relative z-10">
            <div className="max-w-2xl">
              <div
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium mb-6"
                style={{ background: 'rgba(249,115,22,0.15)', color: '#FB923C', border: '1px solid rgba(249,115,22,0.3)' }}
              >
                <span>{openCount} food truck{openCount !== 1 ? 's' : ''} aberto{openCount !== 1 ? 's' : ''} agora</span>
              </div>

              <h1
                className="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-tight mb-4"
                style={{ fontFamily: 'Plus Jakarta Sans, sans-serif' }}
              >
                Seu próximo{' '}
                <span style={{ color: 'var(--primary)' }}>sabor</span>
                <br />começa aqui.
              </h1>

              <p className="text-lg mb-8 leading-relaxed" style={{ color: '#94A3B8' }}>
                Encontre food trucks, escolha seus pratos, faça seu pedido e retire onde quiser.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="#discovery"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-bold text-white transition-all hover:opacity-90"
                  style={{ background: 'var(--primary)' }}
                >
                  Explorar Food Trucks
                  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path d="m9 18 6-6-6-6" />
                  </svg>
                </a>
                <Link
                  to="/register/food-truck"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-medium transition-all hover:opacity-90"
                  style={{ background: 'rgba(255,255,255,0.08)', color: 'white', border: '1px solid rgba(255,255,255,0.15)' }}
                >
                  Quero cadastrar meu Food Truck
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Discovery section */}
      <section id="discovery" className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        {/* Section header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-bold" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
              Explore os Food Trucks
            </h2>
            <p className="text-sm mt-0.5" style={{ color: 'var(--text-muted)' }}>
              {filtered.length} food truck{filtered.length !== 1 ? 's' : ''} encontrado{filtered.length !== 1 ? 's' : ''}
            </p>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm cursor-pointer" style={{ color: 'var(--text)' }}>
              <div
                onClick={() => setOnlyOpen(o => !o)}
                className="relative w-10 h-5 rounded-full transition-colors cursor-pointer"
                style={{ background: onlyOpen ? 'var(--primary)' : 'var(--border)' }}
              >
                <div
                  className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform"
                  style={{ transform: onlyOpen ? 'translateX(1.25rem)' : 'translateX(0.125rem)', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }}
                />
              </div>
              Apenas abertos
            </label>

            {/* Search */}
            <div className="relative">
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: 'var(--text-muted)' }} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Buscar..."
                className="pl-8 pr-3 py-1.5 rounded-full text-sm outline-none w-40"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)' }}
              />
            </div>
          </div>
        </div>

        {/* Category chips */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className="flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all"
              style={{
                background: category === cat ? 'var(--primary)' : 'var(--surface)',
                color: category === cat ? 'white' : 'var(--text-muted)',
                border: '1px solid',
                borderColor: category === cat ? 'var(--primary)' : 'var(--border)',
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Nenhum food truck encontrado</h3>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Tente ajustar os filtros ou a busca.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(ft => (
              <FoodTruckCard key={ft.id} ft={ft} />
            ))}
          </div>
        )}
      </section>
    </>
  )
}
