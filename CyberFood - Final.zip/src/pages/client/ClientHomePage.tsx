import { Link } from 'react-router-dom'
import { useApp } from '../../context/AppContext'
import FoodTruckCard from '../../components/FoodTruckCard'

export default function ClientHomePage() {
  const { currentUser, foodTrucks, isFavorite, getClientOrders, products } = useApp()
  if (!currentUser) return null

  const firstName = currentUser.name.split(' ')[0]
  const myOrders = getClientOrders(currentUser.id)
  const favFts = foodTrucks.filter(ft => isFavorite(ft.id))
  const lastOrder = myOrders.sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0]

  // Recommendations: products ordered 3+ times
  const productCounts: Record<string, number> = {}
  myOrders.forEach(order => {
    order.items.forEach(item => {
      productCounts[item.productId] = (productCounts[item.productId] || 0) + item.quantity
    })
  })
  const recommended = Object.entries(productCounts)
    .filter(([, count]) => count >= 3)
    .map(([pid]) => products.find(p => p.id === pid))
    .filter(Boolean)

  const openFts = foodTrucks.filter(ft => ft.isOpen).slice(0, 4)

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Greeting */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-black mb-1" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
          Olá, {firstName}!
        </h1>
        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>O que você quer pedir hoje?</p>
      </div>

      {/* Recommendations */}
      {recommended.length > 0 && (
        <section className="mb-10">
          <h2 className="text-lg font-bold mb-3" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
            Seus favoritos estão aqui!
          </h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {recommended.map(product => product && (
              <div
                key={product.id}
                className="flex-shrink-0 w-44 rounded-xl overflow-hidden"
                style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}
              >
                <div className="h-24 overflow-hidden" style={{ background: 'var(--surface)' }}>
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-3">
                  <p className="text-sm font-semibold leading-tight" style={{ color: 'var(--text)' }}>{product.name}</p>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--primary)' }}>
                    R$ {product.price.toFixed(2).replace('.', ',')}
                  </p>
                  <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                    Você já pediu {productCounts[product.id]}x
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Last order */}
      {lastOrder && (
        <section className="mb-10">
          <h2 className="text-lg font-bold mb-3" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Seu último pedido</h2>
          <Link to={`/client/order/${lastOrder.id}`}>
            <div
              className="flex items-center justify-between p-4 rounded-xl transition-all hover:shadow-md"
              style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}
            >
              <div>
                <p className="font-semibold text-sm" style={{ color: 'var(--text)' }}>{lastOrder.foodTruckName}</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                  {lastOrder.items.map(i => i.name).join(', ')}
                </p>
                <p className="text-xs mt-1 font-medium" style={{ color: 'var(--text-muted)' }}>
                  {new Date(lastOrder.createdAt).toLocaleDateString('pt-BR')}
                </p>
              </div>
              <div className="text-right">
                <OrderStatusBadge status={lastOrder.status} />
                <p className="text-sm font-bold mt-1" style={{ color: 'var(--text)' }}>
                  R$ {lastOrder.total.toFixed(2).replace('.', ',')}
                </p>
              </div>
            </div>
          </Link>
        </section>
      )}

      {/* Favorites */}
      {favFts.length > 0 && (
        <section className="mb-10">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Seus favoritos</h2>
            <Link to="/client/favorites" className="text-sm font-medium" style={{ color: 'var(--primary)' }}>Ver todos</Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {favFts.slice(0, 4).map(ft => <FoodTruckCard key={ft.id} ft={ft} />)}
          </div>
        </section>
      )}

      {/* Explore */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
            {openFts.length > 0 ? 'Abertos agora' : 'Explore Food Trucks'}
          </h2>
          <Link to="/" className="text-sm font-medium" style={{ color: 'var(--primary)' }}>Ver todos</Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {(openFts.length > 0 ? openFts : foodTrucks.slice(0, 4)).map(ft => (
            <FoodTruckCard key={ft.id} ft={ft} />
          ))}
        </div>
      </section>
    </div>
  )
}

export function OrderStatusBadge({ status }: { status: string }) {
  const cfg: Record<string, { bg: string; color: string }> = {
    'Novo': { bg: 'var(--warning-soft)', color: 'var(--warning)' },
    'Aceito': { bg: '#EFF6FF', color: '#2563EB' },
    'Preparando': { bg: '#FEF9C3', color: '#CA8A04' },
    'Pronto para retirada': { bg: 'var(--success-soft)', color: 'var(--success)' },
    'Retirado': { bg: 'var(--surface)', color: 'var(--text-muted)' },
  }
  const c = cfg[status] || cfg['Novo']
  return (
    <span className="inline-block px-2 py-0.5 rounded-full text-xs font-semibold" style={{ background: c.bg, color: c.color }}>
      {status}
    </span>
  )
}
