import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../../context/AppContext'

export default function FeedbackPage() {
  const { currentUser, submitFeedback } = useApp()
  const navigate = useNavigate()
  const [type, setType] = useState<'Reclamação' | 'Sugestão' | 'Elogio'>('Sugestão')
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [sent, setSent] = useState(false)

  if (!currentUser) return null

  const handle = (e: React.FormEvent) => {
    e.preventDefault()
    submitFeedback({ clientId: currentUser.id, type, subject, message })
    setSent(true)
  }

  const baseInput = 'w-full px-4 py-2.5 rounded-xl text-sm outline-none transition-all'
  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--surface)' }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6" /></svg>
        </button>
        <h1 className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Reclamações e Sugestões</h1>
      </div>

      {sent ? (
        <div className="text-center py-16">
          <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text)' }}>Obrigado pelo seu feedback!</h2>
          <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>Sua mensagem foi enviada com sucesso.</p>
          <button onClick={() => navigate(-1)} className="px-5 py-2.5 rounded-full text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
            Voltar
          </button>
        </div>
      ) : (
        <form onSubmit={handle} className="space-y-4">
          <div>
            <p className="text-sm font-medium mb-2" style={{ color: 'var(--text)' }}>Tipo</p>
            <div className="flex gap-2">
              {(['Reclamação', 'Sugestão', 'Elogio'] as const).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className="flex-1 py-2 rounded-xl text-sm font-medium transition-all"
                  style={{
                    background: type === t ? 'var(--primary)' : 'var(--surface)',
                    color: type === t ? 'white' : 'var(--text-muted)',
                    border: '1.5px solid',
                    borderColor: type === t ? 'var(--primary)' : 'var(--border)',
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>Assunto</label>
            <input required value={subject} onChange={e => setSubject(e.target.value)} className={baseInput} style={inputStyle} placeholder="Resumo do feedback" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>Mensagem</label>
            <textarea required value={message} onChange={e => setMessage(e.target.value)} rows={5} className={baseInput} style={{ ...inputStyle, resize: 'none' }} placeholder="Descreva em detalhes..." />
          </div>
          <button type="submit" className="w-full py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90" style={{ background: 'var(--primary)' }}>
            Enviar
          </button>
        </form>
      )}
    </div>
  )
}
