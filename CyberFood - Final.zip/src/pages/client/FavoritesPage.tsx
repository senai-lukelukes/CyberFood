import { useApp } from '../../context/AppContext'
import FoodTruckCard from '../../components/FoodTruckCard'
import { Link } from 'react-router-dom'

export default function FavoritesPage() {
  const { currentUser, foodTrucks, isFavorite } = useApp()
  if (!currentUser) return null

  const favFts = foodTrucks.filter(ft => isFavorite(ft.id))

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Favoritos</h1>

      {favFts.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Você ainda não tem favoritos</h3>
          <p className="text-sm mb-5" style={{ color: 'var(--text-muted)' }}>Toque no coração nos cards para salvar seus food trucks favoritos.</p>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-white font-bold text-sm" style={{ background: 'var(--primary)' }}>
            Explorar Food Trucks
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {favFts.map(ft => <FoodTruckCard key={ft.id} ft={ft} />)}
        </div>
      )}
    </div>
  )
}
