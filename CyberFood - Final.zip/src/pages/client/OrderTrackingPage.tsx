import { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { useApp } from '../../context/AppContext'
import { OrderStatusBadge } from './ClientHomePage'

const STEPS = ['Novo', 'Aceito', 'Preparando', 'Pronto para retirada', 'Retirado'] as const

const STEP_ICONS: Record<typeof STEPS[number], number> = {
  'Novo': 1,
  'Aceito': 2,
  'Preparando': 3,
  'Pronto para retirada': 4,
  'Retirado': 5,
}

const STEP_LABELS = {
  'Novo': 'Pedido recebido',
  'Aceito': 'Pedido aceito',
  'Preparando': 'Em preparo',
  'Pronto para retirada': 'Pronto para retirada!',
  'Retirado': 'Pedido retirado',
}

export default function OrderTrackingPage() {
  const { id } = useParams<{ id: string }>()
  const { getOrderById, addReview, currentUser, getFoodTruckReviews } = useApp()
  const navigate = useNavigate()

  const order = getOrderById(id!)
  const [showReview, setShowReview] = useState(false)
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')
  const [reviewed, setReviewed] = useState(false)

  if (!order) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <p style={{ color: 'var(--text-muted)' }}>Pedido não encontrado.</p>
        <Link to="/client/orders" className="text-sm font-medium" style={{ color: 'var(--primary)' }}>Ver pedidos</Link>
      </div>
    )
  }

  const currentStepIdx = STEPS.indexOf(order.status as typeof STEPS[number])
  const alreadyReviewed = getFoodTruckReviews(order.foodTruckId).some(r => r.orderId === order.id)

  const handleReview = () => {
    addReview(order.foodTruckId, order.id, rating, comment)
    setReviewed(true)
    setShowReview(false)
  }

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/client/orders')} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--surface)' }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6" /></svg>
        </button>
        <div>
          <h1 className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
            Pedido #{order.id.slice(-6).toUpperCase()}
          </h1>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {new Date(order.createdAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
      </div>

      {/* FT info */}
      <div className="p-4 rounded-xl mb-6 flex items-center justify-between" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div>
          <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{order.foodTruckName}</p>
          <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Retirada no local</p>
        </div>
        <OrderStatusBadge status={order.status} />
      </div>

      {/* Timeline */}
      <div className="mb-6">
        <p className="text-sm font-bold mb-4" style={{ color: 'var(--text)' }}>Acompanhe seu pedido</p>
        <div className="space-y-0">
          {STEPS.map((step, i) => {
            const done = i < currentStepIdx
            const current = i === currentStepIdx
            const upcoming = i > currentStepIdx
            return (
              <div key={step} className="flex gap-3">
                {/* Indicator */}
                <div className="flex flex-col items-center">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 transition-all"
                    style={{
                      background: done ? 'var(--success)' : current ? 'var(--primary)' : 'var(--surface)',
                      color: done || current ? 'white' : 'var(--text-muted)',
                      border: upcoming ? '2px solid var(--border)' : 'none',
                    }}
                  >
                    {done ? '✓' : STEP_ICONS[step]}
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className="w-0.5 h-6 mt-1" style={{ background: done ? 'var(--success)' : 'var(--border)' }} />
                  )}
                </div>
                {/* Label */}
                <div className="pb-6 pt-1">
                  <p className={`text-sm font-semibold ${upcoming ? 'opacity-40' : ''}`} style={{ color: current ? 'var(--primary)' : 'var(--text)' }}>
                    {STEP_LABELS[step]}
                  </p>
                  {current && step === 'Pronto para retirada' && (
                    <p className="text-xs mt-0.5 font-medium" style={{ color: 'var(--success)' }}>
                      Dirija-se ao food truck para retirar!
                    </p>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Items */}
      <div className="rounded-xl overflow-hidden mb-5" style={{ border: '1px solid var(--border)' }}>
        <div className="px-4 py-3 border-b" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
          <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>Itens do pedido</p>
        </div>
        {order.items.map(item => (
          <div key={item.productId} className="flex justify-between px-4 py-3 border-b text-sm" style={{ background: 'var(--card)', borderColor: 'var(--border)', color: 'var(--text)' }}>
            <span>{item.quantity}x {item.name}</span>
            <span className="font-medium">R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}</span>
          </div>
        ))}
        <div className="flex justify-between px-4 py-3" style={{ background: 'var(--card)' }}>
          <span className="text-sm font-bold" style={{ color: 'var(--text)' }}>Total</span>
          <span className="text-sm font-bold" style={{ color: 'var(--primary)' }}>R$ {order.total.toFixed(2).replace('.', ',')}</span>
        </div>
      </div>

      {/* Payment */}
      <div className="flex justify-between text-sm px-4 py-3 rounded-xl mb-5" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
        <span>Pagamento</span>
        <span style={{ color: 'var(--text)' }}>{order.paymentMethod}</span>
      </div>

      {/* Review */}
      {order.status === 'Retirado' && !alreadyReviewed && !reviewed && (
        <button
          onClick={() => setShowReview(true)}
          className="w-full py-3 rounded-xl text-sm font-bold transition-all hover:opacity-90"
          style={{ background: 'var(--primary-soft)', color: 'var(--primary-dark)', border: '1.5px solid var(--primary)' }}
        >
          Avaliar {order.foodTruckName}
        </button>
      )}
      {reviewed && (
        <div className="p-4 rounded-xl text-center text-sm font-medium" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}>
          ✓ Avaliação enviada! Obrigado pelo feedback.
        </div>
      )}

      {/* Review modal */}
      {showReview && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-2xl p-6" style={{ background: 'var(--card)', boxShadow: 'var(--shadow-lg)' }}>
            <h3 className="text-base font-bold mb-1" style={{ color: 'var(--text)' }}>Avaliar {order.foodTruckName}</h3>
            <p className="text-xs mb-4" style={{ color: 'var(--text-muted)' }}>Como foi sua experiência?</p>
            <div className="flex gap-2 justify-center mb-4">
              {[1, 2, 3, 4, 5].map(s => (
                <button key={s} onClick={() => setRating(s)}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill={s <= rating ? '#F59E0B' : 'none'} stroke="#F59E0B" strokeWidth="2">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                </button>
              ))}
            </div>
            <textarea
              value={comment}
              onChange={e => setComment(e.target.value)}
              placeholder="Comentário (opcional)"
              rows={3}
              className="w-full px-3 py-2 rounded-xl text-sm outline-none mb-4"
              style={{ background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)', resize: 'none' }}
            />
            <div className="flex gap-3">
              <button onClick={() => setShowReview(false)} className="flex-1 py-2.5 rounded-xl text-sm" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
              <button onClick={handleReview} className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>Enviar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
