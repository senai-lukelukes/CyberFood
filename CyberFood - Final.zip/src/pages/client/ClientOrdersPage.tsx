import { Link } from 'react-router-dom'
import { useApp } from '../../context/AppContext'
import { OrderStatusBadge } from './ClientHomePage'

export default function ClientOrdersPage() {
  const { currentUser, getClientOrders } = useApp()
  if (!currentUser) return null

  const orders = getClientOrders(currentUser.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Meus Pedidos</h1>

      {orders.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Você ainda não fez nenhum pedido</h3>
          <p className="text-sm mb-5" style={{ color: 'var(--text-muted)' }}>Explore os food trucks e faça seu primeiro pedido!</p>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-white font-bold text-sm" style={{ background: 'var(--primary)' }}>
            Explorar Food Trucks
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map(order => (
            <Link key={order.id} to={`/client/order/${order.id}`}>
              <div className="flex items-center gap-4 p-4 rounded-xl transition-all hover:shadow-md" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-semibold text-sm" style={{ color: 'var(--text)' }}>{order.foodTruckName}</p>
                    <OrderStatusBadge status={order.status} />
                  </div>
                  <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
                    {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                  </p>
                  <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                    {new Date(order.createdAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}
                    {' · '}{order.paymentMethod}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-bold" style={{ color: 'var(--primary)' }}>
                    R$ {order.total.toFixed(2).replace('.', ',')}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {order.items.reduce((s, i) => s + i.quantity, 0)} item{order.items.reduce((s, i) => s + i.quantity, 0) !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
