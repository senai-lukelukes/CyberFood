import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../../context/AppContext'
import type { PaymentMethod } from '../../lib/types'

const ALL_PAYMENT_METHODS: { id: PaymentMethod; label: string; desc: string }[] = [
  { id: 'PIX', label: 'PIX', desc: 'Pagamento instantâneo' },
  { id: 'Cartão de crédito', label: 'Cartão de crédito', desc: 'Parcelamento disponível' },
  { id: 'Cartão de débito', label: 'Cartão de débito', desc: 'Débito na hora' },
  { id: 'Dinheiro na retirada', label: 'Dinheiro', desc: 'Pague na retirada' },
]

export default function CheckoutPage() {
  const { cart, placeOrder, foodTrucks } = useApp()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)

  const ft = foodTrucks.find(f => f.id === cart.foodTruckId)
  const total = cart.items.reduce((s, i) => s + i.finalPrice * i.quantity, 0)

  const acceptedPayments = ft?.acceptedPayments || ALL_PAYMENT_METHODS.map(m => m.id)
  const availableMethods = ALL_PAYMENT_METHODS.filter(m => acceptedPayments.includes(m.id))

  const [payment, setPayment] = useState<PaymentMethod>(() => availableMethods[0]?.id || 'PIX')

  useEffect(() => {
    if (availableMethods.length > 0 && !availableMethods.some(m => m.id === payment)) {
      setPayment(availableMethods[0].id)
    }
  }, [availableMethods.length])

  useEffect(() => {
    if (cart.items.length === 0) navigate('/client/cart', { replace: true })
  }, [cart.items.length, navigate])

  if (cart.items.length === 0) return null

  const handleConfirm = () => {
    setLoading(true)
    const order = placeOrder(payment)
    setLoading(false)
    if (order) navigate(`/client/order/${order.id}`)
  }

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--surface)' }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6" /></svg>
        </button>
        <h1 className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Finalizar Pedido</h1>
      </div>

      {/* Pickup notice */}
      <div className="p-4 rounded-xl mb-5 flex items-center gap-3" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, color: 'var(--primary)' }}>
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" /><circle cx="12" cy="10" r="3" />
        </svg>
        <div>
          <p className="text-sm font-bold" style={{ color: 'var(--text)' }}>Retirada no Food Truck</p>
          {ft && <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{ft.location}</p>}
          <p className="text-xs mt-0.5 font-medium" style={{ color: 'var(--warning)' }}>Não há entrega — retire no local</p>
        </div>
      </div>

      {/* Order summary */}
      <div className="rounded-xl overflow-hidden mb-5" style={{ border: '1px solid var(--border)' }}>
        <div className="px-4 py-3 border-b" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
          <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{ft?.name}</p>
        </div>
        {cart.items.map(item => (
          <div key={item.cartItemId} className="px-4 py-3 border-b" style={{ background: 'var(--card)', borderColor: 'var(--border)' }}>
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: 'var(--primary)' }}>
                  {item.quantity}
                </span>
                <div>
                  <span className="text-sm" style={{ color: 'var(--text)' }}>{item.name}</span>
                  {item.addons.length > 0 && (
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                      + {item.addons.map(a => a.name).join(', ')}
                    </p>
                  )}
                </div>
              </div>
              <span className="text-sm font-medium flex-shrink-0" style={{ color: 'var(--text)' }}>
                R$ {(item.finalPrice * item.quantity).toFixed(2).replace('.', ',')}
              </span>
            </div>
          </div>
        ))}
        {/* Order notes */}
        {cart.notes && (
          <div className="px-4 py-3 border-b" style={{ background: 'var(--card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'var(--text-muted)' }}>Observações</p>
            <p className="text-sm" style={{ color: 'var(--text)' }}>{cart.notes}</p>
          </div>
        )}
        <div className="flex justify-between px-4 py-3" style={{ background: 'var(--card)' }}>
          <span className="font-bold text-sm" style={{ color: 'var(--text)' }}>Total</span>
          <span className="font-bold text-sm" style={{ color: 'var(--primary)' }}>
            R$ {total.toFixed(2).replace('.', ',')}
          </span>
        </div>
      </div>

      {/* Payment */}
      <div className="mb-6">
        <p className="text-sm font-bold mb-3" style={{ color: 'var(--text)' }}>Forma de pagamento</p>
        {availableMethods.length === 0 ? (
          <p className="text-sm p-3 rounded-xl" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
            Entre em contato com o food truck para definir a forma de pagamento.
          </p>
        ) : (
          <div className="space-y-2">
            {availableMethods.map(m => (
              <label
                key={m.id}
                className="flex items-center gap-3 p-4 rounded-xl cursor-pointer transition-all"
                style={{ background: 'var(--card)', border: `2px solid ${payment === m.id ? 'var(--primary)' : 'var(--border)'}` }}
              >
                <input type="radio" name="payment" value={m.id} checked={payment === m.id} onChange={() => setPayment(m.id)} className="sr-only" />
                <div className="flex-1">
                  <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{m.label}</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{m.desc}</p>
                </div>
                <div className="w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all" style={{ borderColor: payment === m.id ? 'var(--primary)' : 'var(--border)' }}>
                  {payment === m.id && <div className="w-2 h-2 rounded-full" style={{ background: 'var(--primary)' }} />}
                </div>
              </label>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={handleConfirm}
        disabled={loading || availableMethods.length === 0}
        className="w-full py-3 rounded-xl font-bold text-white text-sm transition-all hover:opacity-90 disabled:opacity-50"
        style={{ background: 'var(--primary)' }}
      >
        {loading ? 'Confirmando...' : `Confirmar pedido • R$ ${total.toFixed(2).replace('.', ',')}`}
      </button>
    </div>
  )
}
