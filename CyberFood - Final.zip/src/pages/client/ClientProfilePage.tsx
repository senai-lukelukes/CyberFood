import { useApp } from '../../context/AppContext'
import { useNavigate } from 'react-router-dom'
import { OrderStatusBadge } from './ClientHomePage'

export default function ClientProfilePage() {
  const { currentUser, getClientOrders, favorites, logout } = useApp()
  const navigate = useNavigate()
  if (!currentUser) return null

  const orders = getClientOrders(currentUser.id)
  const favCount = favorites.filter(f => f.clientId === currentUser.id).length
  const totalSpent = orders.reduce((s, o) => s + o.total, 0)
  const lastOrder = orders.sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0]

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Perfil</h1>

      {/* Avatar + info */}
      <div className="flex items-center gap-4 p-5 rounded-2xl mb-6" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black text-white" style={{ background: 'var(--primary)' }}>
          {currentUser.name[0]?.toUpperCase()}
        </div>
        <div>
          <h2 className="text-lg font-bold" style={{ color: 'var(--text)' }}>{currentUser.name}</h2>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{currentUser.email}</p>
          <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            Membro desde {new Date(currentUser.createdAt).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: 'Pedidos', value: orders.length },
          { label: 'Favoritos', value: favCount },
          { label: 'Total gasto', value: `R$${totalSpent.toFixed(0)}` },
        ].map(stat => (
          <div key={stat.label} className="p-4 rounded-xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <p className="text-xl font-black" style={{ color: 'var(--primary)' }}>{stat.value}</p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Last order */}
      {lastOrder && (
        <div className="mb-6">
          <p className="text-sm font-bold mb-2" style={{ color: 'var(--text)' }}>Último pedido</p>
          <div className="flex items-center justify-between p-4 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div>
              <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{lastOrder.foodTruckName}</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                {new Date(lastOrder.createdAt).toLocaleDateString('pt-BR')}
              </p>
            </div>
            <div className="text-right">
              <OrderStatusBadge status={lastOrder.status} />
              <p className="text-sm font-bold mt-1" style={{ color: 'var(--text)' }}>R$ {lastOrder.total.toFixed(2).replace('.', ',')}</p>
            </div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="space-y-2">
        <MenuBtn icon="" label="Meus Pedidos" onClick={() => navigate('/client/orders')} />
        <MenuBtn icon="" label="Favoritos" onClick={() => navigate('/client/favorites')} />
        <MenuBtn icon="" label="Reclamações e Sugestões" onClick={() => navigate('/client/feedback')} />
        <div className="border-t my-3" style={{ borderColor: 'var(--border)' }} />
        <MenuBtn icon="" label="Sair" onClick={() => { logout(); navigate('/') }} danger />
      </div>
    </div>
  )
}

function MenuBtn({ icon, label, onClick, danger = false }: { icon: string; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 p-4 rounded-xl text-sm font-medium text-left transition-all hover:opacity-80"
      style={{ background: 'var(--card)', border: '1px solid var(--border)', color: danger ? 'var(--error)' : 'var(--text)' }}
    >
      {icon && <span>{icon}</span>}
      {label}
    </button>
  )
}
