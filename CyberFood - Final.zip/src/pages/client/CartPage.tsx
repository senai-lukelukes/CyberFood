import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../../context/AppContext'

export default function CartPage() {
  const { cart, removeFromCart, updateCartQty, updateCartNotes, foodTrucks } = useApp()
  const navigate = useNavigate()

  const ft = foodTrucks.find(f => f.id === cart.foodTruckId)
  const total = cart.items.reduce((s, i) => s + i.finalPrice * i.quantity, 0)

  if (cart.items.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-20 text-center">
        <h2 className="text-xl font-bold mb-2" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Seu carrinho está vazio</h2>
        <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>Explore os food trucks e adicione itens ao carrinho.</p>
        <Link to="/" className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-white font-bold text-sm" style={{ background: 'var(--primary)' }}>
          Explorar Food Trucks
        </Link>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--surface)' }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6" /></svg>
        </button>
        <h1 className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Carrinho</h1>
      </div>

      {/* FT info */}
      {ft && (
        <div className="flex items-center gap-3 p-3 rounded-xl mb-5" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
          <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0" style={{ background: 'var(--border)' }}>
            <img src={ft.image} alt={ft.name} className="w-full h-full object-cover" />
          </div>
          <div>
            <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{ft.name}</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{ft.location}</p>
          </div>
        </div>
      )}

      {/* Items */}
      <div className="space-y-3 mb-5">
        {cart.items.map(item => (
          <div key={item.cartItemId} className="p-3 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0" style={{ background: 'var(--surface)' }}>
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm" style={{ color: 'var(--text)' }}>{item.name}</p>
                {item.addons.length > 0 && (
                  <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    + {item.addons.map(a => a.name).join(', ')}
                  </p>
                )}
                <p className="text-sm font-bold mt-0.5" style={{ color: 'var(--primary)' }}>
                  R$ {(item.finalPrice * item.quantity).toFixed(2).replace('.', ',')}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => updateCartQty(item.cartItemId, item.quantity - 1)}
                  className="w-7 h-7 rounded-lg text-sm font-bold flex items-center justify-center transition-all hover:opacity-90"
                  style={{ background: item.quantity === 1 ? 'var(--error-soft)' : 'var(--surface)', color: item.quantity === 1 ? 'var(--error)' : 'var(--text)' }}
                >
                  {item.quantity === 1 ? '×' : '−'}
                </button>
                <span className="w-6 text-center text-sm font-bold" style={{ color: 'var(--text)' }}>{item.quantity}</span>
                <button
                  onClick={() => updateCartQty(item.cartItemId, item.quantity + 1)}
                  className="w-7 h-7 rounded-lg text-sm font-bold flex items-center justify-center transition-all hover:opacity-90 text-white"
                  style={{ background: 'var(--primary)' }}
                >
                  +
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Order notes */}
      <div className="mb-5">
        <label className="block text-xs font-semibold mb-1.5 uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>
          Observações do pedido
        </label>
        <textarea
          value={cart.notes}
          onChange={e => updateCartNotes(e.target.value)}
          maxLength={300}
          rows={2}
          className="w-full px-3 py-2.5 rounded-xl text-sm outline-none"
          style={{ background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)', resize: 'none' }}
          placeholder="Ex: sem cebola, bem passado, sem glúten..."
        />
        <p className="text-right text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{cart.notes.length}/300</p>
      </div>

      {/* Pickup notice */}
      <div className="p-3 rounded-xl mb-4 text-sm flex items-center gap-2" style={{ background: 'var(--surface)', color: 'var(--text-muted)', border: '1px solid var(--border)' }}>
        <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, color: 'var(--primary)' }}>
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" /><circle cx="12" cy="10" r="3" />
        </svg>
        <span><strong style={{ color: 'var(--text)' }}>Retirada no local</strong>{ft ? ` — ${ft.location}` : ' — não há entrega'}</span>
      </div>

      {/* Summary */}
      <div className="p-4 rounded-xl mb-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div className="flex justify-between text-sm mb-2" style={{ color: 'var(--text-muted)' }}>
          <span>Subtotal</span>
          <span>R$ {total.toFixed(2).replace('.', ',')}</span>
        </div>
        <div className="border-t pt-3 flex justify-between" style={{ borderColor: 'var(--border)' }}>
          <span className="font-bold" style={{ color: 'var(--text)' }}>Total</span>
          <span className="font-bold text-lg" style={{ color: 'var(--primary)' }}>R$ {total.toFixed(2).replace('.', ',')}</span>
        </div>
      </div>

      <button
        onClick={() => navigate('/client/checkout')}
        className="w-full py-3 rounded-xl font-bold text-white text-sm transition-all hover:opacity-90"
        style={{ background: 'var(--primary)' }}
      >
        Ir para o pagamento
      </button>
    </div>
  )
}
