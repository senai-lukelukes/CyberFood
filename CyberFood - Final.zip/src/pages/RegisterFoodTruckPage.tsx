import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import type { OperatingHours, DayKey } from '../lib/types'
import { maskCNPJ, validateCNPJ, maskPhone, validateEmail, validatePassword } from '../lib/validators'

const DAYS: { key: DayKey; label: string }[] = [
  { key: 'seg', label: 'Segunda' }, { key: 'ter', label: 'Terça' }, { key: 'qua', label: 'Quarta' },
  { key: 'qui', label: 'Quinta' }, { key: 'sex', label: 'Sexta' }, { key: 'sab', label: 'Sábado' }, { key: 'dom', label: 'Domingo' },
]

const CATEGORIES = ['Hambúrgueres', 'Mexicana', 'Pizza', 'Asiática', 'Brasileira', 'Sobremesas', 'Frutos do mar', 'Vegetariana', 'Bebidas', 'Outros']

const defaultHours = (): OperatingHours => ({
  seg: { open: true, start: '10:00', end: '20:00' },
  ter: { open: true, start: '10:00', end: '20:00' },
  qua: { open: true, start: '10:00', end: '20:00' },
  qui: { open: true, start: '10:00', end: '20:00' },
  sex: { open: true, start: '10:00', end: '22:00' },
  sab: { open: true, start: '11:00', end: '22:00' },
  dom: { open: false, start: '11:00', end: '18:00' },
})

type Step = 'ft-info' | 'responsible' | 'hours' | 'account'
const STEPS: Step[] = ['ft-info', 'responsible', 'hours', 'account']
const STEP_LABELS: Record<Step, string> = {
  'ft-info': 'Dados do Food Truck',
  responsible: 'Responsável',
  hours: 'Horários',
  account: 'Acesso',
}

function FieldRow({ label, error, hint, children }: { label: string; error?: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>{label}</label>
      {children}
      {error && <p className="text-xs mt-1 font-medium" style={{ color: 'var(--error)' }}>{error}</p>}
      {!error && hint && <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{hint}</p>}
    </div>
  )
}

export default function RegisterFoodTruckPage() {
  const navigate = useNavigate()
  const { registerFoodTruck } = useApp()

  const [step, setStep] = useState<Step>('ft-info')
  const [submitError, setSubmitError] = useState('')

  // FT Info
  const [ftName, setFtName] = useState('')
  const [cnpj, setCnpj] = useState('')
  const [category, setCategory] = useState('Hambúrgueres')
  const [description, setDescription] = useState('')

  // Responsible
  const [ownerName, setOwnerName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')

  // Hours
  const [hours, setHours] = useState<OperatingHours>(defaultHours())

  // Account
  const [password, setPassword] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [showPw, setShowPw] = useState(false)

  // Field-level errors
  const [errors, setErrors] = useState<Record<string, string>>({})

  const inputBase = 'w-full px-3 py-2.5 rounded-xl text-sm outline-none transition-all'
  const inputStyle = (field: string) => ({
    background: 'var(--surface)',
    border: `1.5px solid ${errors[field] ? 'var(--error)' : 'var(--border)'}`,
    color: 'var(--text)',
  })

  const setErr = (field: string, msg: string) => setErrors(e => ({ ...e, [field]: msg }))
  const clearErr = (field: string) => setErrors(e => { const n = { ...e }; delete n[field]; return n })

  const stepIdx = STEPS.indexOf(step)

  const validateFtInfo = () => {
    const e: Record<string, string> = {}
    if (!ftName.trim()) e.ftName = 'Informe o nome do food truck.'
    else if (ftName.length > 60) e.ftName = 'Máximo 60 caracteres.'
    if (!cnpj.trim()) e.cnpj = 'Informe o CNPJ.'
    else if (!validateCNPJ(cnpj)) e.cnpj = 'CNPJ inválido. Verifique os dígitos.'
    if (description.length > 500) e.description = 'Máximo 500 caracteres.'
    return e
  }

  const validateResponsible = () => {
    const e: Record<string, string> = {}
    if (!ownerName.trim()) e.ownerName = 'Informe o nome do responsável.'
    else if (ownerName.length > 100) e.ownerName = 'Máximo 100 caracteres.'
    if (!email.trim()) e.email = 'Informe o e-mail.'
    else if (!validateEmail(email)) e.email = 'E-mail inválido.'
    if (phone && phone.replace(/\D/g, '').length < 10) e.phone = 'Telefone incompleto.'
    return e
  }

  const validateAccount = () => {
    const e: Record<string, string> = {}
    const pwErr = validatePassword(password)
    if (pwErr) e.password = pwErr
    if (!password) e.password = 'Informe uma senha.'
    if (password !== confirmPw) e.confirmPw = 'As senhas não coincidem.'
    return e
  }

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitError('')

    if (step === 'ft-info') {
      const errs = validateFtInfo()
      setErrors(errs)
      if (Object.keys(errs).length > 0) return
      setStep('responsible')
    } else if (step === 'responsible') {
      const errs = validateResponsible()
      setErrors(errs)
      if (Object.keys(errs).length > 0) return
      setStep('hours')
    } else if (step === 'hours') {
      setStep('account')
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitError('')
    const errs = validateAccount()
    setErrors(errs)
    if (Object.keys(errs).length > 0) return

    const result = registerFoodTruck(ownerName.trim(), email.trim().toLowerCase(), password, {
      name: ftName.trim(),
      cnpj,
      description: description.trim(),
      category,
      phone,
      hours,
    })
    if (!result.ok) { setSubmitError(result.error || 'Erro ao cadastrar.'); return }
    navigate('/manage')
  }

  const updateDay = (key: DayKey, field: 'open' | 'start' | 'end', value: boolean | string) => {
    setHours(h => ({ ...h, [key]: { ...h[key], [field]: value } }))
  }

  const inputStyle2 = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-6">
        <Link to="/" className="inline-flex items-center gap-1 text-sm font-medium mb-4" style={{ color: 'var(--primary)' }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
            <path d="m15 18-6-6 6-6" />
          </svg>
          Voltar
        </Link>
        <h1 className="text-2xl font-black mb-1" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
          Cadastrar Food Truck
        </h1>
        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Leve seu food truck para o CyberFood — comece grátis</p>
      </div>

      {/* Progress bar */}
      <div className="flex gap-2 mb-2">
        {STEPS.map((s, i) => (
          <div key={s} className="flex-1 h-1.5 rounded-full transition-all" style={{ background: i <= stepIdx ? 'var(--primary)' : 'var(--border)' }} />
        ))}
      </div>
      <div className="flex justify-between mb-7">
        {STEPS.map((s, i) => (
          <span key={s} className="text-[10px] font-medium" style={{ color: i <= stepIdx ? 'var(--primary)' : 'var(--text-muted)' }}>
            {STEP_LABELS[s]}
          </span>
        ))}
      </div>

      {submitError && (
        <div className="mb-5 px-4 py-3 rounded-xl text-sm font-medium" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
          {submitError}
        </div>
      )}

      {/* Step 1: FT Info */}
      {step === 'ft-info' && (
        <form onSubmit={handleNext} className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Dados do Food Truck</h2>

          <FieldRow label="Nome do Food Truck *" error={errors.ftName}>
            <div className="relative">
              <input
                required
                value={ftName}
                onChange={e => { setFtName(e.target.value); clearErr('ftName') }}
                maxLength={60}
                className={inputBase}
                style={inputStyle('ftName')}
                placeholder="Ex: Sabor da Praça"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs" style={{ color: 'var(--text-muted)' }}>{ftName.length}/60</span>
            </div>
          </FieldRow>

          <FieldRow label="CNPJ *" error={errors.cnpj} hint="Apenas números — formatação automática">
            <input
              required
              value={cnpj}
              onChange={e => { setCnpj(maskCNPJ(e.target.value)); clearErr('cnpj') }}
              className={inputBase}
              style={inputStyle('cnpj')}
              placeholder="00.000.000/0000-00"
              inputMode="numeric"
            />
          </FieldRow>

          <FieldRow label="Categoria *">
            <select value={category} onChange={e => setCategory(e.target.value)} className={inputBase} style={inputStyle2}>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </FieldRow>

          <FieldRow label="Descrição" error={errors.description}>
            <div className="relative">
              <textarea
                value={description}
                onChange={e => { setDescription(e.target.value); clearErr('description') }}
                rows={3}
                maxLength={500}
                className={inputBase}
                style={{ ...inputStyle('description'), resize: 'none' }}
                placeholder="Descreva seu food truck para atrair clientes..."
              />
              <span className="absolute bottom-2 right-3 text-xs" style={{ color: 'var(--text-muted)' }}>{description.length}/500</span>
            </div>
          </FieldRow>

          <button type="submit" className="w-full py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90" style={{ background: 'var(--primary)' }}>
            Próximo
          </button>
        </form>
      )}

      {/* Step 2: Responsible */}
      {step === 'responsible' && (
        <form onSubmit={handleNext} className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Dados do Responsável</h2>

          <FieldRow label="Nome completo *" error={errors.ownerName}>
            <div className="relative">
              <input
                required
                value={ownerName}
                onChange={e => { setOwnerName(e.target.value); clearErr('ownerName') }}
                maxLength={100}
                className={inputBase}
                style={inputStyle('ownerName')}
                placeholder="Seu nome completo"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs" style={{ color: 'var(--text-muted)' }}>{ownerName.length}/100</span>
            </div>
          </FieldRow>

          <FieldRow label="E-mail *" error={errors.email}>
            <input
              required
              type="email"
              value={email}
              onChange={e => { setEmail(e.target.value); clearErr('email') }}
              maxLength={254}
              className={inputBase}
              style={inputStyle('email')}
              placeholder="seu@email.com"
              inputMode="email"
              autoComplete="email"
            />
          </FieldRow>

          <FieldRow label="Telefone" error={errors.phone} hint="Formato: (11) 99999-9999">
            <input
              value={phone}
              onChange={e => { setPhone(maskPhone(e.target.value)); clearErr('phone') }}
              className={inputBase}
              style={inputStyle('phone')}
              placeholder="(11) 99999-9999"
              inputMode="tel"
            />
          </FieldRow>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setStep('ft-info')}
              className="flex-1 py-3 rounded-xl text-sm font-medium"
              style={{ background: 'var(--surface)', color: 'var(--text)' }}
            >
              Voltar
            </button>
            <button type="submit" className="flex-1 py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90" style={{ background: 'var(--primary)' }}>
              Próximo
            </button>
          </div>
        </form>
      )}

      {/* Step 3: Hours */}
      {step === 'hours' && (
        <form onSubmit={handleNext} className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Horários de Funcionamento</h2>
          <div className="space-y-2">
            {DAYS.map(({ key, label }) => (
              <div key={key} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                <div
                  onClick={() => updateDay(key, 'open', !hours[key].open)}
                  className="relative w-9 h-5 rounded-full flex-shrink-0 cursor-pointer transition-colors"
                  style={{ background: hours[key].open ? 'var(--primary)' : 'var(--border)' }}
                >
                  <div
                    className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform"
                    style={{ transform: hours[key].open ? 'translateX(1.125rem)' : 'translateX(0.125rem)', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }}
                  />
                </div>
                <span className="w-16 text-sm font-medium flex-shrink-0" style={{ color: 'var(--text)' }}>{label}</span>
                {hours[key].open ? (
                  <div className="flex items-center gap-2 flex-1">
                    <input
                      type="time"
                      value={hours[key].start}
                      onChange={e => updateDay(key, 'start', e.target.value)}
                      className="flex-1 px-2 py-1 rounded-lg text-sm outline-none"
                      style={inputStyle2}
                    />
                    <span className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>até</span>
                    <input
                      type="time"
                      value={hours[key].end}
                      onChange={e => updateDay(key, 'end', e.target.value)}
                      className="flex-1 px-2 py-1 rounded-lg text-sm outline-none"
                      style={inputStyle2}
                    />
                  </div>
                ) : (
                  <span className="text-sm flex-1" style={{ color: 'var(--text-muted)' }}>Fechado</span>
                )}
              </div>
            ))}
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setStep('responsible')}
              className="flex-1 py-3 rounded-xl text-sm font-medium"
              style={{ background: 'var(--surface)', color: 'var(--text)' }}
            >
              Voltar
            </button>
            <button type="submit" className="flex-1 py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90" style={{ background: 'var(--primary)' }}>
              Próximo
            </button>
          </div>
        </form>
      )}

      {/* Step 4: Account */}
      {step === 'account' && (
        <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Dados de Acesso</h2>

          <FieldRow label="Senha *" error={errors.password} hint="8 a 72 caracteres, sem espaços no início ou fim">
            <div className="relative">
              <input
                required
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={e => { setPassword(e.target.value); clearErr('password') }}
                className={inputBase}
                style={{ ...inputStyle('password'), paddingRight: '2.5rem' }}
                placeholder="Mínimo 8 caracteres"
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowPw(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2"
                style={{ color: 'var(--text-muted)' }}
              >
                <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
                  {showPw ? (
                    <><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></>
                  ) : (
                    <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>
                  )}
                </svg>
              </button>
            </div>
          </FieldRow>

          <FieldRow label="Confirmar senha *" error={errors.confirmPw}>
            <input
              required
              type={showPw ? 'text' : 'password'}
              value={confirmPw}
              onChange={e => { setConfirmPw(e.target.value); clearErr('confirmPw') }}
              className={inputBase}
              style={inputStyle('confirmPw')}
              placeholder="Repita a senha"
              autoComplete="new-password"
            />
          </FieldRow>

          {/* Summary */}
          <div className="p-4 rounded-xl space-y-1 text-xs" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <p className="font-semibold mb-2" style={{ color: 'var(--text-muted)' }}>Resumo do cadastro</p>
            <p style={{ color: 'var(--text)' }}><span style={{ color: 'var(--text-muted)' }}>Food Truck:</span> {ftName}</p>
            <p style={{ color: 'var(--text)' }}><span style={{ color: 'var(--text-muted)' }}>CNPJ:</span> {cnpj}</p>
            <p style={{ color: 'var(--text)' }}><span style={{ color: 'var(--text-muted)' }}>Responsável:</span> {ownerName}</p>
            <p style={{ color: 'var(--text)' }}><span style={{ color: 'var(--text-muted)' }}>E-mail:</span> {email}</p>
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setStep('hours')}
              className="flex-1 py-3 rounded-xl text-sm font-medium"
              style={{ background: 'var(--surface)', color: 'var(--text)' }}
            >
              Voltar
            </button>
            <button type="submit" className="flex-1 py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90" style={{ background: 'var(--primary)' }}>
              Criar Food Truck
            </button>
          </div>
        </form>
      )}

      <p className="text-center text-xs mt-6" style={{ color: 'var(--text-muted)' }}>
        Já tem uma conta?{' '}
        <button type="button" className="font-medium" style={{ color: 'var(--primary)' }} onClick={() => navigate('/')}>
          Fazer login
        </button>
      </p>
    </div>
  )
}
