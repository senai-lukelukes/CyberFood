import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { storage } from '../lib/storage'
import type { Product, ProductAddon, CartAddon, Promotion } from '../lib/types'

function Stars({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24" fill={i <= Math.round(rating) ? '#F59E0B' : 'none'} stroke="#F59E0B" strokeWidth="2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      ))}
    </span>
  )
}

function computePromoPrice(product: Product, promo: Promotion): number {
  if (promo.discountType === 'percentage') {
    return Math.max(0, product.price * (1 - promo.discountValue / 100))
  }
  return Math.max(0, product.price - promo.discountValue)
}

function buildCartItemId(productId: string, addons: CartAddon[]): string {
  const addonKey = addons.map(a => a.addonId).sort().join(',')
  return addonKey ? `${productId}:${addonKey}` : productId
}

function ProductModal({
  product,
  promo,
  onAdd,
  onClose,
}: {
  product: Product
  promo: Promotion | null
  onAdd: (addons: CartAddon[]) => void
  onClose: () => void
}) {
  const availableAddons = (product.addons || []).filter(a => a.available)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const basePrice = promo ? computePromoPrice(product, promo) : product.price

  const toggleAddon = (addonId: string) => {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(addonId)) next.delete(addonId)
      else next.add(addonId)
      return next
    })
  }

  const selectedAddons: CartAddon[] = availableAddons
    .filter(a => selected.has(a.id))
    .map((a: ProductAddon) => ({ addonId: a.id, name: a.name, price: a.price }))

  const totalPrice = basePrice + selectedAddons.reduce((s, a) => s + a.price, 0)

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.55)' }}>
      <div className="w-full max-w-md rounded-2xl overflow-hidden" style={{ background: 'var(--card)', boxShadow: 'var(--shadow-lg)', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
        {product.image && (
          <div className="h-44 overflow-hidden flex-shrink-0">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </div>
        )}
        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-3">
            <h3 className="text-lg font-black mb-1" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>{product.name}</h3>
            <p className="text-sm mb-2" style={{ color: 'var(--text-muted)' }}>{product.description}</p>
            <div className="flex items-center gap-3">
              {promo ? (
                <>
                  <span className="text-sm line-through" style={{ color: 'var(--text-muted)' }}>R$ {product.price.toFixed(2).replace('.', ',')}</span>
                  <span className="text-xl font-black" style={{ color: 'var(--error)' }}>R$ {basePrice.toFixed(2).replace('.', ',')}</span>
                  <span className="text-xs px-1.5 py-0.5 rounded font-bold" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
                    {promo.discountType === 'percentage' ? `-${promo.discountValue}%` : `-R$${promo.discountValue.toFixed(2)}`}
                  </span>
                </>
              ) : (
                <span className="text-xl font-black" style={{ color: 'var(--primary)' }}>R$ {basePrice.toFixed(2).replace('.', ',')}</span>
              )}
            </div>
          </div>
          {product.ingredients.length > 0 && (
            <div className="mb-4 p-3 rounded-xl" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
              <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'var(--text-muted)' }}>Ingredientes</p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{product.ingredients.join(' · ')}</p>
            </div>
          )}
          {availableAddons.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: 'var(--text-muted)' }}>Adicionais</p>
              <div className="space-y-2">
                {availableAddons.map((addon: ProductAddon) => (
                  <label
                    key={addon.id}
                    className="flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all"
                    style={{ background: selected.has(addon.id) ? 'rgba(249,115,22,0.08)' : 'var(--surface)', border: `1.5px solid ${selected.has(addon.id) ? 'var(--primary)' : 'var(--border)'}` }}
                    onClick={() => toggleAddon(addon.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0 transition-all" style={{ background: selected.has(addon.id) ? 'var(--primary)' : 'transparent', border: `2px solid ${selected.has(addon.id) ? 'var(--primary)' : 'var(--border)'}` }}>
                        {selected.has(addon.id) && <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                      </div>
                      <span className="text-sm font-medium" style={{ color: 'var(--text)' }}>{addon.name}</span>
                    </div>
                    <span className="text-sm font-semibold" style={{ color: 'var(--primary)' }}>+R$ {addon.price.toFixed(2).replace('.', ',')}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="flex-shrink-0 p-4 border-t" style={{ borderColor: 'var(--border)' }}>
          <div className="flex gap-3">
            <button onClick={onClose} className="flex-1 py-3 rounded-xl text-sm font-medium" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
            <button onClick={() => onAdd(selectedAddons)} className="flex-1 py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90" style={{ background: 'var(--primary)' }}>
              Adicionar · R$ {totalPrice.toFixed(2).replace('.', ',')}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function FoodTruckPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const {
    foodTrucks, getFoodTruckProducts, getFoodTruckReviews,
    currentUser, openAuthModal, addToCart, clearCart, cart,
    isFavorite, toggleFavorite, getActivePromotionsForFoodTruck,
  } = useApp()

  const ft = foodTrucks.find(f => f.id === id)
  const [cartConflict, setCartConflict] = useState<{ product: Product; addons: CartAddon[] } | null>(null)
  const [addedId, setAddedId] = useState<string | null>(null)
  const [customizeProduct, setCustomizeProduct] = useState<{ product: Product; promo: Promotion | null } | null>(null)

  if (!ft) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text)' }}>Food truck não encontrado</h2>
        <button onClick={() => navigate('/')} className="text-sm font-medium" style={{ color: 'var(--primary)' }}>← Voltar</button>
      </div>
    )
  }

  const products = getFoodTruckProducts(ft.id).filter(p => p.available)
  const reviews = getFoodTruckReviews(ft.id)
  const fav = isFavorite(ft.id)
  const activePromos = getActivePromotionsForFoodTruck(ft.id)
  const getPromoForProduct = (productId: string): Promotion | null => activePromos.find(p => p.productId === productId) || null

  const categories = [...new Set(products.map(p => p.category))]

  const doAdd = (product: Product, addons: CartAddon[]) => {
    const promo = getPromoForProduct(product.id)
    const basePrice = promo ? computePromoPrice(product, promo) : product.price
    const finalPrice = basePrice + addons.reduce((s, a) => s + a.price, 0)
    const cartItemId = buildCartItemId(product.id, addons)
    const result = addToCart(
      { cartItemId, productId: product.id, name: product.name, price: basePrice, quantity: 1, image: product.image, addons, finalPrice },
      ft.id, ft.name
    )
    if (result === 'conflict') {
      setCartConflict({ product, addons })
    } else {
      setAddedId(product.id)
      setTimeout(() => setAddedId(null), 1500)
    }
  }

  const handleAdd = (product: Product) => {
    if (!currentUser) {
      const promo = getPromoForProduct(product.id)
      const basePrice = promo ? computePromoPrice(product, promo) : product.price
      storage.savePendingCartAdd({
        item: { cartItemId: product.id, productId: product.id, name: product.name, price: basePrice, quantity: 1, image: product.image, addons: [], finalPrice: basePrice },
        ftId: ft.id, ftName: ft.name,
      })
      openAuthModal('login', `/food-truck/${ft.id}`)
      return
    }
    if (!ft.isOpen) return

    const availableAddons = (product.addons || []).filter(a => a.available)
    if (availableAddons.length > 0) {
      setCustomizeProduct({ product, promo: getPromoForProduct(product.id) })
    } else {
      doAdd(product, [])
    }
  }

  const handleConflictContinue = () => {
    if (!cartConflict) return
    const { product, addons } = cartConflict
    clearCart()
    setCartConflict(null)
    doAdd(product, addons)
  }

  const DAY_LABELS = { seg: 'Segunda', ter: 'Terça', qua: 'Quarta', qui: 'Quinta', sex: 'Sexta', sab: 'Sábado', dom: 'Domingo' }
  const cartTotal = cart.items.reduce((s, i) => s + i.finalPrice * i.quantity, 0)

  return (
    <>
      {/* Cart conflict modal */}
      {cartConflict && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-2xl p-6" style={{ background: 'var(--card)', boxShadow: 'var(--shadow-lg)' }}>
            <h3 className="text-base font-bold mb-2" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
              Seu carrinho possui itens de outro food truck
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
              Deseja limpar o carrinho e começar um novo pedido em <strong>{ft.name}</strong>?
            </p>
            <div className="flex gap-3">
              <button onClick={() => setCartConflict(null)} className="flex-1 py-2.5 rounded-xl text-sm font-medium" style={{ background: 'var(--surface)', color: 'var(--text)' }}>
                Cancelar
              </button>
              <button onClick={handleConflictContinue} className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
                Continuar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product customization modal */}
      {customizeProduct && (
        <ProductModal
          product={customizeProduct.product}
          promo={customizeProduct.promo}
          onAdd={(addons) => { setCustomizeProduct(null); doAdd(customizeProduct.product, addons) }}
          onClose={() => setCustomizeProduct(null)}
        />
      )}

      {/* Hero banner */}
      <div className="relative h-56 sm:h-72 overflow-hidden" style={{ background: 'var(--surface)' }}>
        <img src={ft.image} alt={ft.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 60%)' }} />
        <button
          onClick={() => navigate(-1)}
          className="absolute top-4 left-4 w-9 h-9 rounded-xl flex items-center justify-center"
          style={{ background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)' }}
        >
          <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6" /></svg>
        </button>
        <button
          onClick={() => {
            if (!currentUser) { openAuthModal('login', `/food-truck/${ft.id}`); return }
            toggleFavorite(ft.id)
          }}
          className="absolute top-4 right-4 w-9 h-9 rounded-xl flex items-center justify-center"
          style={{ background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)' }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill={fav ? '#EF4444' : 'none'} stroke={fav ? '#EF4444' : '#64748B'} strokeWidth="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
          </svg>
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        {/* Info */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h1 className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>{ft.name}</h1>
              <span
                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold"
                style={{ background: ft.isOpen ? 'var(--success-soft)' : 'var(--surface)', color: ft.isOpen ? 'var(--success)' : 'var(--text-muted)' }}
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: ft.isOpen ? 'var(--success)' : 'var(--text-muted)' }} />
                {ft.isOpen ? 'Aberto' : 'Fechado'}
              </span>
            </div>
            <p className="text-sm mb-3" style={{ color: 'var(--text-muted)' }}>{ft.description}</p>
            <div className="flex flex-wrap items-center gap-4 text-sm" style={{ color: 'var(--text-muted)' }}>
              <span className="flex items-center gap-1">
                <Stars rating={ft.avgRating} size={13} />
                <strong style={{ color: 'var(--text)' }}>{ft.avgRating > 0 ? ft.avgRating.toFixed(1) : '—'}</strong>
                {ft.totalReviews > 0 && `(${ft.totalReviews} avaliações)`}
              </span>
              <span>{ft.prepTime}</span>
              <span>{ft.location}</span>
              <span>{ft.phone}</span>
            </div>
          </div>
          <div
            className="text-xs rounded-xl p-3 flex-shrink-0"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
          >
            <p className="font-semibold mb-1" style={{ color: 'var(--text)' }}>Horários</p>
            {Object.entries(ft.hours).map(([day, sched]) => (
              <div key={day} className="flex justify-between gap-4">
                <span style={{ color: 'var(--text-muted)' }}>{DAY_LABELS[day as keyof typeof DAY_LABELS]}</span>
                <span style={{ color: sched.open ? 'var(--text)' : 'var(--text-muted)' }}>
                  {sched.open ? `${sched.start} – ${sched.end}` : 'Fechado'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Closed notice */}
        {!ft.isOpen && (
          <div className="mb-6 px-4 py-3 rounded-xl flex items-center gap-3 text-sm font-medium" style={{ background: 'var(--warning-soft)', color: 'var(--warning)' }}>
            Este food truck está fechado no momento. Você pode visualizar o cardápio mas não realizar pedidos.
          </div>
        )}

        {/* Pickup info */}
        <div className="mb-4 px-4 py-3 rounded-xl flex items-center gap-3 text-sm" style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
          <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, color: 'var(--primary)' }}>
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" /><circle cx="12" cy="10" r="3" />
          </svg>
          <span><strong style={{ color: 'var(--text)' }}>Retirada no local:</strong> {ft.location}</span>
        </div>

        {/* Payment methods */}
        {ft.acceptedPayments && ft.acceptedPayments.length > 0 && (
          <div className="mb-6 px-4 py-3 rounded-xl text-sm" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <span className="font-semibold" style={{ color: 'var(--text)' }}>Pagamentos aceitos:</span>
            <span className="ml-2" style={{ color: 'var(--text-muted)' }}>{ft.acceptedPayments.join(' · ')}</span>
          </div>
        )}

        {/* Active promotions banner */}
        {activePromos.length > 0 && (
          <div className="mb-5 px-4 py-3 rounded-xl flex items-center gap-2 text-sm font-medium" style={{ background: 'var(--error-soft)', color: 'var(--error)', border: '1px solid rgba(220,38,38,0.15)' }}>
            <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
              <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" /><line x1="7" y1="7" x2="7.01" y2="7" />
            </svg>
            {activePromos.length === 1 ? '1 promoção ativa' : `${activePromos.length} promoções ativas`} — confira os destaques no cardápio
          </div>
        )}

        {/* Menu */}
        {products.length === 0 ? (
          <div className="text-center py-12">
            <p className="font-semibold" style={{ color: 'var(--text)' }}>Cardápio ainda não disponível</p>
          </div>
        ) : (
          <>
            <h2 className="text-xl font-bold mb-4" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Cardápio</h2>
            {categories.map(cat => (
              <div key={cat} className="mb-6">
                <h3 className="text-sm font-bold uppercase tracking-wider mb-3" style={{ color: 'var(--text-muted)' }}>{cat}</h3>
                <div className="space-y-3">
                  {products.filter(p => p.category === cat).map(product => {
                    const promo = getPromoForProduct(product.id)
                    const promoPrice = promo ? computePromoPrice(product, promo) : null
                    const inCartQty = cart.items.filter(i => i.productId === product.id).reduce((s, i) => s + i.quantity, 0)
                    const justAdded = addedId === product.id
                    const hasAddons = (product.addons || []).filter(a => a.available).length > 0
                    return (
                      <div
                        key={product.id}
                        className="flex gap-3 rounded-xl p-3 transition-all"
                        style={{ background: 'var(--card)', border: `1px solid ${promo ? 'rgba(220,38,38,0.2)' : 'var(--border)'}`, boxShadow: 'var(--shadow-sm)' }}
                      >
                        <div className="flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden relative" style={{ background: 'var(--surface)' }}>
                          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                          {promo && (
                            <div className="absolute top-1 left-1 px-1 py-0.5 rounded text-white font-bold" style={{ background: 'var(--error)', fontSize: '9px', lineHeight: 1 }}>
                              {promo.discountType === 'percentage' ? `-${promo.discountValue}%` : `-R$${promo.discountValue}`}
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-sm" style={{ color: 'var(--text)' }}>{product.name}</p>
                              <p className="text-xs mt-0.5 line-clamp-2" style={{ color: 'var(--text-muted)' }}>{product.description}</p>
                              <div className="flex items-center gap-2 mt-1">
                                {promoPrice !== null ? (
                                  <>
                                    <span className="text-xs line-through" style={{ color: 'var(--text-muted)' }}>R$ {product.price.toFixed(2).replace('.', ',')}</span>
                                    <span className="text-sm font-bold" style={{ color: 'var(--error)' }}>R$ {promoPrice.toFixed(2).replace('.', ',')}</span>
                                  </>
                                ) : (
                                  <span className="text-sm font-bold" style={{ color: 'var(--primary)' }}>R$ {product.price.toFixed(2).replace('.', ',')}</span>
                                )}
                                {hasAddons && <span className="text-xs" style={{ color: 'var(--text-muted)' }}>+ adicionais</span>}
                              </div>
                            </div>
                            <button
                              onClick={() => handleAdd(product)}
                              disabled={!ft.isOpen}
                              className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold text-white transition-all hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
                              style={{ background: justAdded ? 'var(--success)' : 'var(--primary)' }}
                              aria-label={`Adicionar ${product.name}`}
                            >
                              {justAdded ? (
                                <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
                              ) : inCartQty > 0 ? `+${inCartQty}` : '+'}
                            </button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </>
        )}

        {/* Reviews */}
        {reviews.length > 0 && (
          <div className="mt-8">
            <h2 className="text-xl font-bold mb-4" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Avaliações</h2>
            <div className="space-y-3">
              {reviews.slice(0, 5).map(r => (
                <div key={r.id} className="p-4 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full text-white text-xs font-bold flex items-center justify-center" style={{ background: 'var(--primary)' }}>
                        {r.clientName[0]?.toUpperCase()}
                      </div>
                      <span className="font-medium text-sm" style={{ color: 'var(--text)' }}>{r.clientName}</span>
                    </div>
                    <Stars rating={r.rating} size={12} />
                  </div>
                  {r.comment && <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{r.comment}</p>}
                  <p className="text-xs mt-1" style={{ color: 'var(--border)' }}>
                    {new Date(r.createdAt).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Floating cart button */}
        {cart.foodTruckId === ft.id && cart.items.length > 0 && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
            <button
              onClick={() => navigate('/client/cart')}
              className="flex items-center gap-3 px-6 py-3 rounded-full text-white font-bold text-sm shadow-lg transition-all hover:opacity-90"
              style={{ background: 'var(--primary)', boxShadow: '0 8px 24px rgba(249,115,22,0.4)' }}
            >
              <span className="w-5 h-5 rounded-full bg-white text-xs font-black flex items-center justify-center" style={{ color: 'var(--primary)' }}>
                {cart.items.reduce((s, i) => s + i.quantity, 0)}
              </span>
              Ver carrinho
              <span>R$ {cartTotal.toFixed(2).replace('.', ',')}</span>
            </button>
          </div>
        )}
      </div>
    </>
  )
}
