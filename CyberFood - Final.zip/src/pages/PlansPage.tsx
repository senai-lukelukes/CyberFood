import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'

type PlanFeature = { label: string; free: boolean; essential: boolean; professional: boolean }

const FEATURES: PlanFeature[] = [
  { label: 'Perfil do food truck', free: true, essential: true, professional: true },
  { label: 'Cardápio de produtos', free: true, essential: true, professional: true },
  { label: 'Recebimento de pedidos', free: true, essential: true, professional: true },
  { label: 'Gestão básica de pedidos', free: true, essential: true, professional: true },
  { label: 'Controle de estoque', free: false, essential: true, professional: true },
  { label: 'Reabastecimento', free: false, essential: true, professional: true },
  { label: 'Gestão de clientes', free: false, essential: true, professional: true },
  { label: 'Promoções e descontos', free: false, essential: true, professional: true },
  { label: 'Histórico de ações', free: false, essential: true, professional: true },
  { label: 'Relatórios básicos', free: false, essential: true, professional: true },
  { label: 'Previsão de demanda', free: false, essential: false, professional: true },
  { label: 'Relatórios avançados', free: false, essential: false, professional: true },
  { label: 'Análise de vendas detalhada', free: false, essential: false, professional: true },
]

const PLANS = [
  {
    id: 'free',
    name: 'Gratuito',
    price: 'R$ 0',
    period: '/mês',
    desc: 'Para quem está começando',
    color: 'var(--border)',
    highlight: false,
    cta: 'Começar grátis',
  },
  {
    id: 'essential',
    name: 'Essencial',
    price: 'R$ 29,90',
    period: '/mês',
    desc: 'Para operações em crescimento',
    color: 'var(--primary)',
    highlight: true,
    cta: 'Assinar Essencial',
  },
  {
    id: 'professional',
    name: 'Profissional',
    price: 'R$ 59,90',
    period: '/mês',
    desc: 'Para negócios consolidados',
    color: '#7C3AED',
    highlight: false,
    cta: 'Assinar Profissional',
  },
] as const

function CheckIcon({ active }: { active: boolean }) {
  if (!active) return (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" style={{ color: 'var(--border)' }}>
      <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
    </svg>
  )
  return (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24" style={{ color: 'var(--success)' }}>
      <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export default function PlansPage() {
  const { currentUser } = useApp()

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
      {/* Header */}
      <div className="text-center mb-10">
        <h1
          className="text-3xl font-black mb-3"
          style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
        >
          Planos para food trucks
        </h1>
        <p className="text-base max-w-lg mx-auto" style={{ color: 'var(--text-muted)' }}>
          Escolha o plano ideal para a sua operação. Clientes nunca pagam — apenas os proprietários de food trucks têm planos.
        </p>
      </div>

      {/* Pricing cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {PLANS.map(plan => (
          <div
            key={plan.id}
            className="rounded-2xl p-6 flex flex-col relative"
            style={{
              background: 'var(--card)',
              border: `2px solid ${plan.highlight ? plan.color : 'var(--border)'}`,
              boxShadow: plan.highlight ? `0 0 0 4px ${plan.color}18` : 'var(--shadow-sm)',
            }}
          >
            {plan.highlight && (
              <div
                className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-xs font-bold text-white"
                style={{ background: plan.color }}
              >
                Mais popular
              </div>
            )}
            <div className="mb-4">
              <h2 className="text-base font-bold mb-1" style={{ color: plan.color }}>{plan.name}</h2>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{plan.desc}</p>
            </div>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-3xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
                {plan.price}
              </span>
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>{plan.period}</span>
            </div>
            <ul className="space-y-2 flex-1 mb-6">
              {FEATURES.filter(f => f[plan.id as keyof PlanFeature]).map(f => (
                <li key={f.label} className="flex items-center gap-2 text-sm" style={{ color: 'var(--text)' }}>
                  <CheckIcon active />
                  {f.label}
                </li>
              ))}
            </ul>
            {currentUser?.type === 'owner' ? (
              <Link
                to="/manage/plans"
                className="w-full py-2.5 rounded-xl text-sm font-bold text-center block transition-all hover:opacity-90"
                style={{
                  background: plan.highlight ? plan.color : 'var(--surface)',
                  color: plan.highlight ? 'white' : 'var(--text)',
                  border: plan.highlight ? 'none' : '1.5px solid var(--border)',
                }}
              >
                {plan.cta}
              </Link>
            ) : (
              <Link
                to="/register/food-truck"
                className="w-full py-2.5 rounded-xl text-sm font-bold text-center block transition-all hover:opacity-90"
                style={{
                  background: plan.highlight ? plan.color : 'var(--surface)',
                  color: plan.highlight ? 'white' : 'var(--text)',
                  border: plan.highlight ? 'none' : '1.5px solid var(--border)',
                }}
              >
                {plan.cta}
              </Link>
            )}
          </div>
        ))}
      </div>

      {/* Comparison table */}
      <div>
        <h2 className="text-xl font-bold mb-5 text-center" style={{ color: 'var(--text)' }}>
          Comparação completa
        </h2>
        <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
          {/* Table header */}
          <div className="grid grid-cols-4 px-5 py-3 text-xs font-bold uppercase tracking-wider" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
            <div>Recurso</div>
            <div className="text-center">Gratuito</div>
            <div className="text-center" style={{ color: 'var(--primary)' }}>Essencial</div>
            <div className="text-center" style={{ color: '#7C3AED' }}>Profissional</div>
          </div>
          {FEATURES.map((f, i) => (
            <div
              key={f.label}
              className="grid grid-cols-4 px-5 py-3 text-sm items-center"
              style={{
                background: i % 2 === 0 ? 'var(--card)' : 'var(--surface)',
                borderTop: '1px solid var(--border)',
                color: 'var(--text)',
              }}
            >
              <div>{f.label}</div>
              <div className="flex justify-center"><CheckIcon active={f.free} /></div>
              <div className="flex justify-center"><CheckIcon active={f.essential} /></div>
              <div className="flex justify-center"><CheckIcon active={f.professional} /></div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer note */}
      <p className="text-center text-xs mt-8" style={{ color: 'var(--text-muted)' }}>
        Clientes da plataforma nunca pagam nenhuma taxa. Os planos são exclusivos para proprietários de food trucks.
        Você pode alterar seu plano a qualquer momento.
      </p>
    </div>
  )
}
