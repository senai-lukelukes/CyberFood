import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import { Field } from './ProductsPage'

export default function RestockingPage() {
  const { getMyFoodTruck, getFoodTruckInventory, getFoodTruckRestocks, restock } = useApp()
  const ft = getMyFoodTruck()
  if (!ft) return null

  const inventory = getFoodTruckInventory(ft.id)
  const restocks = getFoodTruckRestocks(ft.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  const [selectedId, setSelectedId] = useState('')
  const [qty, setQty] = useState('')
  const [note, setNote] = useState('')
  const [expiresAt, setExpiresAt] = useState('')
  const [restockedAt, setRestockedAt] = useState(new Date().toISOString().slice(0, 10))
  const [lotLabel, setLotLabel] = useState('')
  const [done, setDone] = useState(false)

  const selectedItem = inventory.find(i => i.id === selectedId)
  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  const todayStr = new Date().toISOString().slice(0, 10)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedItem || !qty || !expiresAt) return
    restock(ft.id, selectedId, parseInt(qty), note, expiresAt, restockedAt || undefined, lotLabel || undefined)
    setDone(true)
    setTimeout(() => {
      setDone(false); setSelectedId(''); setQty(''); setNote(''); setExpiresAt('')
      setRestockedAt(new Date().toISOString().slice(0, 10)); setLotLabel('')
    }, 2000)
  }

  return (
    <div>
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Reabastecimento</h1>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Form */}
        <div className="rounded-2xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <h2 className="text-base font-bold mb-4" style={{ color: 'var(--text)' }}>Registrar reabastecimento</h2>

          {inventory.length === 0 ? (
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Adicione itens ao estoque primeiro.</p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <Field label="Item do estoque">
                <select required value={selectedId} onChange={e => setSelectedId(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle}>
                  <option value="">Selecione um item...</option>
                  {inventory.map(i => (
                    <option key={i.id} value={i.id}>{i.name} (atual: {i.quantity} {i.unit})</option>
                  ))}
                </select>
              </Field>

              {selectedItem && (
                <div className="p-3 rounded-xl text-sm" style={{ background: 'var(--surface)' }}>
                  <p style={{ color: 'var(--text-muted)' }}>Quantidade atual: <strong style={{ color: 'var(--text)' }}>{selectedItem.quantity} {selectedItem.unit}</strong></p>
                  <p style={{ color: 'var(--text-muted)' }}>Máximo: <strong style={{ color: 'var(--text)' }}>{selectedItem.maxStock} {selectedItem.unit}</strong></p>
                </div>
              )}

              <Field label={`Quantidade a adicionar${selectedItem ? ` (${selectedItem.unit})` : ''}`}>
                <input type="number" min="1" required value={qty} onChange={e => setQty(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle} placeholder="Ex: 10" />
              </Field>

              {selectedItem && qty && (
                <div className="p-3 rounded-xl text-sm font-medium" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}>
                  Nova quantidade: {selectedItem.quantity + parseInt(qty || '0')} {selectedItem.unit}
                </div>
              )}

              <Field label="Data de entrada">
                <input type="date" max={todayStr} value={restockedAt} onChange={e => setRestockedAt(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle} />
              </Field>

              <Field label="Data de validade (vencimento) *">
                <input type="date" required min={todayStr} value={expiresAt} onChange={e => setExpiresAt(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle} />
              </Field>

              <Field label="Observação (opcional)">
                <input value={note} onChange={e => setNote(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle} placeholder="Ex: Compra do fornecedor X" />
              </Field>

              <Field label="Código do lote (opcional)">
                <input value={lotLabel} onChange={e => setLotLabel(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle} placeholder="Ex: LT-2024-001" />
              </Field>

              {done ? (
                <div className="py-3 rounded-xl text-sm font-bold text-center" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}>
                  ✓ Reabastecimento registrado!
                </div>
              ) : (
                <button type="submit" className="w-full py-3 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
                  Confirmar reabastecimento
                </button>
              )}
            </form>
          )}
        </div>

        {/* History */}
        <div>
          <h2 className="text-base font-bold mb-3" style={{ color: 'var(--text)' }}>Histórico de reabastecimentos</h2>
          {restocks.length === 0 ? (
            <div className="p-6 rounded-xl text-center text-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
              Nenhum reabastecimento registrado.
            </div>
          ) : (
            <div className="space-y-2">
              {restocks.map(r => (
                <div key={r.id} className="p-3 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{r.itemName}</p>
                      {r.note && <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{r.note}</p>}
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold" style={{ color: 'var(--success)' }}>+{r.addedQty}</span>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>→ {r.newQty}</p>
                    </div>
                  </div>
                  <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                    {new Date(r.createdAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </p>
                  {r.expiresAt && (
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                      Validade: {new Date(r.expiresAt).toLocaleDateString('pt-BR')}
                    </p>
                  )}
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    Lote: {(r as any).lotLabel || '—'}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
