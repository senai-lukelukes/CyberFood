import { useMemo } from 'react'
import { useApp } from '../../context/AppContext'
import { PlanGate } from '../../components/ui/PlanGate'

type ForecastRow = {
  id: string
  name: string
  unit: string
  currentQty: number
  avgDailyConsumption: number
  daysRemaining: number | null
}

type StatusLevel = 'Estavel' | 'Atencao' | 'Baixo' | 'Esgotado'

function getStatus(daysRemaining: number | null, currentQty: number): StatusLevel {
  if (currentQty <= 0) return 'Esgotado'
  if (daysRemaining !== null && daysRemaining <= 0) return 'Esgotado'
  if (daysRemaining === null) return 'Estavel'
  if (daysRemaining > 14) return 'Estavel'
  if (daysRemaining > 7) return 'Atencao'
  return 'Baixo'
}

const STATUS_DISPLAY: Record<StatusLevel, string> = {
  Estavel: 'Estavel',
  Atencao: 'Atencao',
  Baixo: 'Baixo',
  Esgotado: 'Esgotado',
}

function StatusBadge({ status }: { status: StatusLevel }) {
  const styles: Record<StatusLevel, { bg: string; color: string }> = {
    Estavel: { bg: 'var(--success-soft)', color: 'var(--success)' },
    Atencao: { bg: 'var(--warning-soft)', color: 'var(--warning)' },
    Baixo: { bg: 'var(--error-soft)', color: 'var(--error)' },
    Esgotado: { bg: 'var(--error-soft)', color: 'var(--error)' },
  }
  const s = styles[status]
  return (
    <span
      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: s.bg, color: s.color }}
    >
      {STATUS_DISPLAY[status]}
    </span>
  )
}

function ForecastingContent() {
  const { getMyFoodTruck, getFoodTruckOrders, getFoodTruckInventory, getFoodTruckProducts } = useApp()
  const ft = getMyFoodTruck()

  const { rows, hasEnoughData } = useMemo(() => {
    if (!ft) return { rows: [], hasEnoughData: false }

    const inventory = getFoodTruckInventory(ft.id)
    const products = getFoodTruckProducts(ft.id)
    const orders = getFoodTruckOrders(ft.id)

    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
    const cutoff = thirtyDaysAgo.toISOString()

    const completedOrders = orders.filter(
      (o) => o.status === 'Retirado' && o.createdAt >= cutoff
    )

    if (completedOrders.length === 0) {
      return { rows: [], hasEnoughData: false }
    }

    const productMap = new Map(products.map((p) => [p.id, p]))

    const totalConsumed: Record<string, number> = {}
    for (const order of completedOrders) {
      for (const orderItem of order.items) {
        const product = productMap.get(orderItem.productId)
        if (!product?.recipe?.length) continue
        for (const ingredient of product.recipe) {
          const consumed = ingredient.quantity * orderItem.quantity
          totalConsumed[ingredient.inventoryItemId] =
            (totalConsumed[ingredient.inventoryItemId] || 0) + consumed
        }
      }
    }

    const forecastRows: ForecastRow[] = inventory.map((item) => {
      const total = totalConsumed[item.id]
      if (!total) {
        return {
          id: item.id,
          name: item.name,
          unit: item.unit,
          currentQty: item.quantity,
          avgDailyConsumption: 0,
          daysRemaining: null,
        }
      }
      const avgDaily = total / 30
      const daysRemaining = avgDaily > 0 ? item.quantity / avgDaily : null
      return {
        id: item.id,
        name: item.name,
        unit: item.unit,
        currentQty: item.quantity,
        avgDailyConsumption: avgDaily,
        daysRemaining,
      }
    })

    forecastRows.sort((a, b) => {
      if (a.avgDailyConsumption === 0 && b.avgDailyConsumption !== 0) return 1
      if (a.avgDailyConsumption !== 0 && b.avgDailyConsumption === 0) return -1
      if (a.daysRemaining === null && b.daysRemaining !== null) return 1
      if (a.daysRemaining !== null && b.daysRemaining === null) return -1
      if (a.daysRemaining === null && b.daysRemaining === null) return 0
      return (a.daysRemaining as number) - (b.daysRemaining as number)
    })

    return { rows: forecastRows, hasEnoughData: true }
  }, [ft, getFoodTruckOrders, getFoodTruckInventory, getFoodTruckProducts])

  if (!ft) return null

  return (
    <div>
      <div className="mb-6">
        <h1
          className="text-2xl font-black mb-1"
          style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
        >
          Previsao de Estoque
        </h1>
        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
          Baseado nos ultimos 30 dias de pedidos concluidos
        </p>
      </div>

      {!hasEnoughData ? (
        <div
          className="rounded-2xl p-10 text-center"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
            style={{ background: 'var(--primary-soft)' }}
          >
            <svg
              width="24"
              height="24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ color: 'var(--primary)' }}
            >
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
          </div>
          <h3 className="text-base font-bold mb-2" style={{ color: 'var(--text)' }}>
            Dados insuficientes
          </h3>
          <p
            className="text-sm leading-relaxed max-w-xs mx-auto"
            style={{ color: 'var(--text-muted)' }}
          >
            Nao ha pedidos concluidos suficientes para gerar previsoes. Complete mais pedidos para
            ver analises de consumo.
          </p>
        </div>
      ) : (
        <div
          className="rounded-2xl overflow-hidden"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          {/* Desktop table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)', background: 'var(--surface)' }}>
                  {['Ingrediente', 'Estoque atual', 'Consumo medio/dia', 'Dias restantes', 'Status'].map(
                    (col) => (
                      <th
                        key={col}
                        className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider"
                        style={{ color: 'var(--text-muted)' }}
                      >
                        {col}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, idx) => {
                  const status = getStatus(row.daysRemaining, row.currentQty)
                  return (
                    <tr
                      key={row.id}
                      style={{
                        borderBottom:
                          idx < rows.length - 1 ? '1px solid var(--border)' : undefined,
                      }}
                    >
                      <td className="px-4 py-3 font-medium" style={{ color: 'var(--text)' }}>
                        {row.name}
                      </td>
                      <td className="px-4 py-3" style={{ color: 'var(--text)' }}>
                        {row.currentQty % 1 === 0
                          ? row.currentQty
                          : row.currentQty.toFixed(2)}{' '}
                        {row.unit}
                      </td>
                      <td className="px-4 py-3" style={{ color: 'var(--text-muted)' }}>
                        {row.avgDailyConsumption === 0
                          ? '—'
                          : `${row.avgDailyConsumption.toFixed(2)} ${row.unit}`}
                      </td>
                      <td className="px-4 py-3 font-semibold" style={{ color: 'var(--text)' }}>
                        {row.daysRemaining === null
                          ? '—'
                          : row.daysRemaining <= 0
                          ? '0 dias'
                          : `${Math.floor(row.daysRemaining)} dias`}
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={status} />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="sm:hidden">
            {rows.map((row, idx) => {
              const status = getStatus(row.daysRemaining, row.currentQty)
              return (
                <div
                  key={row.id}
                  className="p-4 space-y-2"
                  style={
                    idx < rows.length - 1 ? { borderBottom: '1px solid var(--border)' } : undefined
                  }
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm" style={{ color: 'var(--text)' }}>
                      {row.name}
                    </span>
                    <StatusBadge status={status} />
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <p className="font-medium mb-0.5" style={{ color: 'var(--text-muted)' }}>
                        Estoque
                      </p>
                      <p style={{ color: 'var(--text)' }}>
                        {row.currentQty % 1 === 0
                          ? row.currentQty
                          : row.currentQty.toFixed(2)}{' '}
                        {row.unit}
                      </p>
                    </div>
                    <div>
                      <p className="font-medium mb-0.5" style={{ color: 'var(--text-muted)' }}>
                        Consumo/dia
                      </p>
                      <p style={{ color: 'var(--text)' }}>
                        {row.avgDailyConsumption === 0
                          ? '—'
                          : `${row.avgDailyConsumption.toFixed(2)} ${row.unit}`}
                      </p>
                    </div>
                    <div>
                      <p className="font-medium mb-0.5" style={{ color: 'var(--text-muted)' }}>
                        Dias rest.
                      </p>
                      <p style={{ color: 'var(--text)' }}>
                        {row.daysRemaining === null
                          ? '—'
                          : row.daysRemaining <= 0
                          ? '0'
                          : Math.floor(row.daysRemaining)}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      <p className="text-xs mt-4 text-center" style={{ color: 'var(--text-muted)' }}>
        Previsoes baseadas no consumo historico. Resultados podem variar conforme a demanda.
      </p>
    </div>
  )
}

export default function ForecastingPage() {
  return (
    <PlanGate requiredPlan="professional" featureName="Previsao de Estoque">
      <ForecastingContent />
    </PlanGate>
  )
}
