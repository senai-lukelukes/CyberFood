import { useState } from 'react'
import { useApp } from '../../context/AppContext'

export default function CustomersPage() {
  const { getMyFoodTruck, getFoodTruckOrders, getFoodTruckReviews } = useApp()
  const ft = getMyFoodTruck()
  const [selected, setSelected] = useState<string | null>(null)
  if (!ft) return null

  const orders = getFoodTruckOrders(ft.id)
  const reviews = getFoodTruckReviews(ft.id)

  const customerMap: Record<string, { id: string; name: string; orders: typeof orders; totalSpent: number }> = {}
  orders.forEach(o => {
    if (!customerMap[o.clientId]) {
      customerMap[o.clientId] = { id: o.clientId, name: o.clientName, orders: [], totalSpent: 0 }
    }
    customerMap[o.clientId].orders.push(o)
    customerMap[o.clientId].totalSpent += o.total
  })

  const customers = Object.values(customerMap).sort((a, b) => a.name.localeCompare(b.name))
  const selectedCustomer = selected ? customerMap[selected] : null
  const selectedReviews = selected ? reviews.filter(r => r.clientId === selected) : []

  return (
    <div>
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Clientes</h1>

      {customers.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Nenhum cliente ainda</h3>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Quando os clientes fizerem pedidos, eles aparecerão aqui.</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-4">
          {/* List */}
          <div className="space-y-2">
            {customers.map(c => (
              <button
                key={c.id}
                onClick={() => setSelected(selected === c.id ? null : c.id)}
                className="w-full flex items-center gap-3 p-4 rounded-xl text-left transition-all hover:opacity-80"
                style={{
                  background: selected === c.id ? 'var(--primary-soft)' : 'var(--card)',
                  border: `1px solid ${selected === c.id ? 'var(--primary)' : 'var(--border)'}`,
                }}
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0" style={{ background: 'var(--primary)' }}>
                  {c.name[0]?.toUpperCase()}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm" style={{ color: 'var(--text)' }}>{c.name}</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{c.orders.length} pedido{c.orders.length !== 1 ? 's' : ''}</p>
                </div>
                <p className="text-sm font-bold flex-shrink-0" style={{ color: 'var(--primary)' }}>
                  R$ {c.totalSpent.toFixed(2).replace('.', ',')}
                </p>
              </button>
            ))}
          </div>

          {/* Detail */}
          {selectedCustomer && (
            <div className="rounded-2xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold text-white" style={{ background: 'var(--primary)' }}>
                  {selectedCustomer.name[0]?.toUpperCase()}
                </div>
                <div>
                  <p className="font-bold" style={{ color: 'var(--text)' }}>{selectedCustomer.name}</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    {selectedCustomer.orders.length} pedido{selectedCustomer.orders.length !== 1 ? 's' : ''} · R$ {selectedCustomer.totalSpent.toFixed(2).replace('.', ',')} gastos
                  </p>
                </div>
              </div>

              <h3 className="text-xs font-bold uppercase tracking-wider mb-2" style={{ color: 'var(--text-muted)' }}>Últimos pedidos</h3>
              <div className="space-y-2 mb-4">
                {selectedCustomer.orders.slice(0, 5).map(o => (
                  <div key={o.id} className="flex justify-between text-sm py-2 border-b" style={{ borderColor: 'var(--border)' }}>
                    <span style={{ color: 'var(--text-muted)' }}>{new Date(o.createdAt).toLocaleDateString('pt-BR')}</span>
                    <span style={{ color: 'var(--text)' }}>R$ {o.total.toFixed(2).replace('.', ',')}</span>
                    <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{o.status}</span>
                  </div>
                ))}
              </div>

              {selectedReviews.length > 0 && (
                <>
                  <h3 className="text-xs font-bold uppercase tracking-wider mb-2" style={{ color: 'var(--text-muted)' }}>Avaliações</h3>
                  {selectedReviews.map(r => (
                    <div key={r.id} className="text-sm py-2 border-b" style={{ borderColor: 'var(--border)' }}>
                      <div className="flex items-center gap-1 mb-1">
                        {[1,2,3,4,5].map(s => (
                          <svg key={s} width="12" height="12" viewBox="0 0 24 24" fill={s <= r.rating ? '#F59E0B' : 'none'} stroke="#F59E0B" strokeWidth="2">
                            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                          </svg>
                        ))}
                      </div>
                      {r.comment && <p style={{ color: 'var(--text-muted)' }}>{r.comment}</p>}
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
