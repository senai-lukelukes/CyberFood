import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import type { InventoryItem, InventoryCategory, InventoryBatch, DisposalRecord } from '../../lib/types'
import { ConfirmModal, Field } from './ProductsPage'
import { PlanGate } from '../../components/ui/PlanGate'

const CATEGORIES: InventoryCategory[] = ['Carnes', 'Laticínios', 'Vegetais', 'Perecíveis', 'Bebidas', 'Outros']
const UNITS = ['kg', 'g', 'L', 'ml', 'un', 'cx', 'pct']

function stockStatus(item: InventoryItem): { label: string; color: string; bg: string } {
  const pct = item.maxStock > 0 ? item.quantity / item.maxStock : 1
  if (pct <= 0.2) return { label: 'Baixo', color: 'var(--error)', bg: 'var(--error-soft)' }
  if (pct <= 0.5) return { label: 'Médio', color: 'var(--warning)', bg: 'var(--warning-soft)' }
  return { label: 'Alto', color: 'var(--success)', bg: 'var(--success-soft)' }
}

const EMPTY_ITEM: Omit<InventoryItem, 'id' | 'foodTruckId'> = {
  name: '', category: 'Outros', quantity: 0, unit: 'kg', minStock: 0, maxStock: 100,
}

function getExpiryStatus(batches: InventoryBatch[], inventoryItemId: string): { daysUntil: number; expired: boolean } | null {
  const itemBatches = batches.filter(b => b.inventoryItemId === inventoryItemId && b.remainingQty > 0)
  if (!itemBatches.length) return null
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  let earliest: Date | null = null
  for (const b of itemBatches) {
    const d = new Date(b.expiresAt)
    if (!earliest || d < earliest) earliest = d
  }
  if (!earliest) return null
  const diffMs = earliest.getTime() - today.getTime()
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24))
  return { daysUntil: days, expired: days < 0 }
}

const DISPOSAL_REASONS = ['Vencimento', 'Avaria', 'Excesso', 'Outro']

export default function InventoryPage() {
  const { getMyFoodTruck, getFoodTruckInventory, getFoodTruckBatches, createInventoryItem, updateInventoryItem, deleteInventoryItem, registerDisposal } = useApp()
  const ft = getMyFoodTruck()
  const [modal, setModal] = useState<'create' | InventoryItem | null>(null)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [filterCat, setFilterCat] = useState<InventoryCategory | 'Todos'>('Todos')
  const [disposalItem, setDisposalItem] = useState<InventoryItem | null>(null)

  if (!ft) return null
  const inventory = getFoodTruckInventory(ft.id)
  const batches = getFoodTruckBatches(ft.id)

  const filtered = filterCat === 'Todos' ? inventory : inventory.filter(i => i.category === filterCat)

  const handleSave = (data: typeof EMPTY_ITEM) => {
    if (modal === 'create') {
      createInventoryItem({ ...data, foodTruckId: ft.id })
    } else if (modal) {
      updateInventoryItem((modal as InventoryItem).id, data)
    }
    setModal(null)
  }

  const lowCount = inventory.filter(i => stockStatus(i).label === 'Baixo').length

  // Expiry alert counts
  const expiryStatuses = inventory.map(i => getExpiryStatus(batches, i.id))
  const nearCount = expiryStatuses.filter(s => s && !s.expired && s.daysUntil <= 5).length
  const expiredCount = expiryStatuses.filter(s => s && s.expired).length

  return (
    <PlanGate requiredPlan="essential" featureName="Controle de Estoque">
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Estoque</h1>
          {lowCount > 0 && <p className="text-xs mt-0.5 font-medium" style={{ color: 'var(--error)' }}>{lowCount} item{lowCount !== 1 ? 's' : ''} com estoque baixo</p>}
          {nearCount > 0 && <p className="text-xs mt-0.5 font-medium" style={{ color: 'var(--warning)' }}>{nearCount} lote{nearCount !== 1 ? 's' : ''} próximo{nearCount !== 1 ? 's' : ''} do vencimento</p>}
          {expiredCount > 0 && <p className="text-xs mt-0.5 font-medium" style={{ color: 'var(--error)' }}>{expiredCount} lote{expiredCount !== 1 ? 's' : ''} vencido{expiredCount !== 1 ? 's' : ''}</p>}
        </div>
        <button onClick={() => setModal('create')} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
          + Novo item
        </button>
      </div>

      {/* Category filter */}
      <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
        {(['Todos', ...CATEGORIES] as const).map(cat => (
          <button key={cat} onClick={() => setFilterCat(cat as typeof filterCat)} className="flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all"
            style={{ background: filterCat === cat ? 'var(--primary)' : 'var(--surface)', color: filterCat === cat ? 'white' : 'var(--text-muted)', border: '1px solid', borderColor: filterCat === cat ? 'var(--primary)' : 'var(--border)' }}>
            {cat}
          </button>
        ))}
      </div>

      {inventory.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: 'var(--primary-soft)' }}>
            <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}>
              <path d="M21 8v13H3V8"/><path d="M23 3H1v5h22V3z"/><line x1="10" y1="12" x2="14" y2="12"/>
            </svg>
          </div>
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Seu estoque está vazio</h3>
          <p className="text-sm mb-5" style={{ color: 'var(--text-muted)' }}>Adicione ingredientes e insumos do seu food truck.</p>
          <button onClick={() => setModal('create')} className="px-5 py-2.5 rounded-full text-white font-bold text-sm" style={{ background: 'var(--primary)' }}>Adicionar item</button>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(item => {
            const status = stockStatus(item)
            const pct = item.maxStock > 0 ? Math.min(100, Math.round(item.quantity / item.maxStock * 100)) : 0
            const expiry = getExpiryStatus(batches, item.id)
            return (
              <div key={item.id} className="p-4 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-sm" style={{ color: 'var(--text)' }}>{item.name}</p>
                      <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: status.bg, color: status.color }}>
                        {status.label}
                      </span>
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{item.category}</p>
                    {expiry && expiry.expired && (
                      <span className="inline-block text-xs px-2 py-0.5 rounded-full font-semibold mt-1" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
                        Lote vencido
                      </span>
                    )}
                    {expiry && !expiry.expired && expiry.daysUntil <= 5 && (
                      <span className="inline-block text-xs px-2 py-0.5 rounded-full font-semibold mt-1" style={{ background: 'var(--warning-soft)', color: 'var(--warning)' }}>
                        Lote vence em {expiry.daysUntil} dia{expiry.daysUntil !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold" style={{ color: 'var(--text)' }}>{item.quantity} {item.unit}</p>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Máx: {item.maxStock} {item.unit}</p>
                  </div>
                </div>
                {/* Progress bar */}
                <div className="h-1.5 rounded-full mb-2" style={{ background: 'var(--border)' }}>
                  <div className="h-1.5 rounded-full transition-all" style={{ width: `${pct}%`, background: status.color }} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{pct}% disponível</span>
                  <div className="flex gap-2">
                    <button onClick={() => setDisposalItem(item)} className="text-xs font-medium px-2 py-1 rounded-lg" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>Registrar descarte</button>
                    <button onClick={() => setModal(item)} className="text-xs font-medium px-2 py-1 rounded-lg" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>Editar</button>
                    <button onClick={() => setDeleteConfirm(item.id)} className="text-xs font-medium px-2 py-1 rounded-lg" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>Remover</button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {deleteConfirm && (
        <ConfirmModal title="Remover item?" desc="Este item será removido do estoque permanentemente." onConfirm={() => { deleteInventoryItem(deleteConfirm); setDeleteConfirm(null) }} onCancel={() => setDeleteConfirm(null)} />
      )}

      {modal !== null && (
        <InventoryModal item={modal === 'create' ? null : modal as InventoryItem} onSave={handleSave} onClose={() => setModal(null)} />
      )}

      {disposalItem && (
        <DisposalModal
          item={disposalItem}
          foodTruckId={ft.id}
          onSave={(data) => { registerDisposal(data); setDisposalItem(null) }}
          onClose={() => setDisposalItem(null)}
        />
      )}
    </div>
    </PlanGate>
  )
}

function DisposalModal({ item, foodTruckId, onSave, onClose }: {
  item: InventoryItem
  foodTruckId: string
  onSave: (data: Omit<DisposalRecord, 'id' | 'createdAt'>) => void
  onClose: () => void
}) {
  const [qty, setQty] = useState(1)
  const [reason, setReason] = useState(DISPOSAL_REASONS[0])
  const [estimatedValue, setEstimatedValue] = useState('')
  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }
  const baseInput = 'w-full px-3 py-2.5 rounded-xl text-sm outline-none'

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave({
      foodTruckId,
      inventoryItemId: item.id,
      itemName: item.name,
      quantity: qty,
      unit: item.unit,
      reason,
      estimatedValue: estimatedValue ? parseFloat(estimatedValue) : undefined,
    })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-sm rounded-2xl p-6" style={{ background: 'var(--card)' }}>
        <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text)' }}>Registrar descarte</h3>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="px-3 py-2 rounded-lg text-sm font-medium" style={{ background: 'var(--surface)', color: 'var(--text)' }}>
            {item.name}
          </div>
          <Field label={`Quantidade (${item.unit})`}>
            <input type="number" min="0.01" step="0.01" required value={qty} onChange={e => setQty(parseFloat(e.target.value) || 0)} className={baseInput} style={inputStyle} />
          </Field>
          <Field label="Motivo">
            <select value={reason} onChange={e => setReason(e.target.value)} className={baseInput} style={inputStyle}>
              {DISPOSAL_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </Field>
          <Field label="Valor estimado (R$) — opcional">
            <input type="number" min="0" step="0.01" value={estimatedValue} onChange={e => setEstimatedValue(e.target.value)} className={baseInput} style={inputStyle} placeholder="0,00" />
          </Field>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
            <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--error)' }}>Confirmar descarte</button>
          </div>
        </form>
      </div>
    </div>
  )
}

function InventoryModal({ item, onSave, onClose }: { item: InventoryItem | null; onSave: (d: typeof EMPTY_ITEM) => void; onClose: () => void }) {
  const [form, setForm] = useState<typeof EMPTY_ITEM>(
    item ? { name: item.name, category: item.category, quantity: item.quantity, unit: item.unit, minStock: item.minStock, maxStock: item.maxStock } : EMPTY_ITEM
  )
  const baseInput = 'w-full px-3 py-2.5 rounded-xl text-sm outline-none'
  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-md rounded-2xl p-6" style={{ background: 'var(--card)' }}>
        <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text)' }}>{item ? 'Editar item' : 'Novo item de estoque'}</h3>
        <form onSubmit={e => { e.preventDefault(); onSave(form) }} className="space-y-3">
          <Field label="Nome do item"><input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={baseInput} style={inputStyle} placeholder="Ex: Queijo Cheddar" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Categoria">
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as InventoryCategory }))} className={baseInput} style={inputStyle}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Unidade">
              <select value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} className={baseInput} style={inputStyle}>
                {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </Field>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Qtd. atual"><input type="number" min="0" step="1" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: Math.max(0, Math.floor(+e.target.value)) }))} className={baseInput} style={inputStyle} /></Field>
            <Field label="Mínimo"><input type="number" min="0" step="1" value={form.minStock} onChange={e => setForm(f => ({ ...f, minStock: Math.max(0, Math.floor(+e.target.value)) }))} className={baseInput} style={inputStyle} /></Field>
            <Field label="Máximo *"><input type="number" min="1" step="1" required value={form.maxStock} onChange={e => setForm(f => ({ ...f, maxStock: Math.max(1, Math.floor(+e.target.value)) }))} className={baseInput} style={inputStyle} /></Field>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
            <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>Salvar</button>
          </div>
        </form>
      </div>
    </div>
  )
}
