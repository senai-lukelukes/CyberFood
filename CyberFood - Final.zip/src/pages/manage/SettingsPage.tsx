import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useApp } from '../../context/AppContext'
import type { OperatingHours, DayKey, PaymentMethod } from '../../lib/types'
import { Field } from './ProductsPage'

const PLAN_LABELS = { free: 'Gratuito', essential: 'Essencial', professional: 'Profissional' }
const PLAN_PRICES = { free: 'R$ 0/mês', essential: 'R$ 29,90/mês', professional: 'R$ 59,90/mês' }
const PLAN_COLOR = { free: 'var(--text-muted)', essential: 'var(--primary)', professional: '#7C3AED' }

const DAYS: { key: DayKey; label: string }[] = [
  { key: 'seg', label: 'Segunda' }, { key: 'ter', label: 'Terça' }, { key: 'qua', label: 'Quarta' },
  { key: 'qui', label: 'Quinta' }, { key: 'sex', label: 'Sexta' }, { key: 'sab', label: 'Sábado' }, { key: 'dom', label: 'Domingo' },
]

const CATEGORIES = ['Hambúrgueres', 'Mexicana', 'Pizza', 'Asiática', 'Brasileira', 'Sobremesas', 'Frutos do mar', 'Vegetariana', 'Bebidas', 'Outros']

export default function SettingsPage() {
  const { getMyFoodTruck, updateFoodTruck, deleteFoodTruck, logout } = useApp()
  const ft = getMyFoodTruck()
  const navigate = useNavigate()
  const [tab, setTab] = useState<'info' | 'hours' | 'payments' | 'plan' | 'danger'>('info')
  const [saved, setSaved] = useState(false)
  const [deleteInput, setDeleteInput] = useState('')
  const [showDeleteModal, setShowDeleteModal] = useState(false)

  if (!ft) return null

  const [info, setInfo] = useState({ name: ft.name, description: ft.description, category: ft.category, phone: ft.phone, location: ft.location, image: ft.image })
  const [hours, setHours] = useState<OperatingHours>(ft.hours)
  const [selectedPayments, setSelectedPayments] = useState<PaymentMethod[]>(ft.acceptedPayments || ['PIX', 'Dinheiro na retirada'])

  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }
  const baseInput = 'w-full px-3 py-2.5 rounded-xl text-sm outline-none'

  const handleSaveInfo = (e: React.FormEvent) => {
    e.preventDefault()
    updateFoodTruck(ft.id, info)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleSaveHours = (e: React.FormEvent) => {
    e.preventDefault()
    updateFoodTruck(ft.id, { hours })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleSavePayments = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedPayments.length === 0) return
    updateFoodTruck(ft.id, { acceptedPayments: selectedPayments })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const togglePayment = (method: PaymentMethod) => {
    setSelectedPayments(prev =>
      prev.includes(method) ? prev.filter(m => m !== method) : [...prev, method]
    )
  }

  const handleDelete = () => {
    if (deleteInput !== ft.name) return
    deleteFoodTruck(ft.id)
    logout()
    navigate('/')
  }

  const updateDay = (key: DayKey, field: 'open' | 'start' | 'end', value: boolean | string) => {
    setHours(h => ({ ...h, [key]: { ...h[key], [field]: value } }))
  }

  const PAYMENT_METHODS: { id: PaymentMethod; label: string; desc: string }[] = [
    { id: 'PIX', label: 'PIX', desc: 'Pagamento instantâneo via Pix' },
    { id: 'Cartão de crédito', label: 'Cartão de crédito', desc: 'Pagamento com cartão de crédito' },
    { id: 'Cartão de débito', label: 'Cartão de débito', desc: 'Pagamento com cartão de débito' },
    { id: 'Dinheiro na retirada', label: 'Dinheiro', desc: 'Pagamento em dinheiro na retirada' },
  ]

  const TABS = [
    { id: 'info', label: 'Informações' },
    { id: 'hours', label: 'Horários' },
    { id: 'payments', label: 'Pagamentos' },
    { id: 'plan', label: 'Plano' },
    { id: 'danger', label: 'Perigo' },
  ] as const

  return (
    <div>
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Configurações</h1>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl mb-6" style={{ background: 'var(--surface)' }}>
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="flex-1 py-2 rounded-lg text-sm font-medium transition-all"
            style={{
              background: tab === t.id ? 'var(--card)' : 'transparent',
              color: t.id === 'danger' ? 'var(--error)' : tab === t.id ? 'var(--text)' : 'var(--text-muted)',
              boxShadow: tab === t.id ? 'var(--shadow-sm)' : 'none',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {saved && (
        <div className="mb-4 px-4 py-3 rounded-xl text-sm font-medium" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}>
          ✓ Alterações salvas com sucesso!
        </div>
      )}

      {/* Info tab */}
      {tab === 'info' && (
        <form onSubmit={handleSaveInfo} className="space-y-4 max-w-lg">
          <Field label="Nome do Food Truck">
            <input required value={info.name} onChange={e => setInfo(i => ({ ...i, name: e.target.value }))} className={baseInput} style={inputStyle} />
          </Field>
          <Field label="Descrição">
            <textarea value={info.description} onChange={e => setInfo(i => ({ ...i, description: e.target.value }))} rows={3} className={baseInput} style={{ ...inputStyle, resize: 'none' }} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Categoria">
              <select value={info.category} onChange={e => setInfo(i => ({ ...i, category: e.target.value }))} className={baseInput} style={inputStyle}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Telefone">
              <input value={info.phone} onChange={e => setInfo(i => ({ ...i, phone: e.target.value }))} className={baseInput} style={inputStyle} />
            </Field>
          </div>
          <Field label="Localização">
            <input value={info.location} onChange={e => setInfo(i => ({ ...i, location: e.target.value }))} className={baseInput} style={inputStyle} />
          </Field>
          <Field label="URL da imagem">
            <input value={info.image} onChange={e => setInfo(i => ({ ...i, image: e.target.value }))} className={baseInput} style={inputStyle} />
          </Field>
          <button type="submit" className="px-6 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
            Salvar alterações
          </button>
        </form>
      )}

      {/* Hours tab */}
      {tab === 'hours' && (
        <form onSubmit={handleSaveHours} className="space-y-3 max-w-lg">
          {DAYS.map(({ key, label }) => (
            <div key={key} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
              <div onClick={() => updateDay(key, 'open', !hours[key].open)} className="relative w-9 h-5 rounded-full flex-shrink-0 cursor-pointer transition-colors" style={{ background: hours[key].open ? 'var(--primary)' : 'var(--border)' }}>
                <div className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform" style={{ transform: hours[key].open ? 'translateX(1.125rem)' : 'translateX(0.125rem)' }} />
              </div>
              <span className="w-16 text-sm font-medium flex-shrink-0" style={{ color: 'var(--text)' }}>{label}</span>
              {hours[key].open ? (
                <div className="flex items-center gap-2 flex-1">
                  <input type="time" value={hours[key].start} onChange={e => updateDay(key, 'start', e.target.value)} className="flex-1 px-2 py-1 rounded-lg text-sm outline-none" style={inputStyle} />
                  <span className="text-xs" style={{ color: 'var(--text-muted)' }}>até</span>
                  <input type="time" value={hours[key].end} onChange={e => updateDay(key, 'end', e.target.value)} className="flex-1 px-2 py-1 rounded-lg text-sm outline-none" style={inputStyle} />
                </div>
              ) : (
                <span className="text-sm flex-1" style={{ color: 'var(--text-muted)' }}>Fechado</span>
              )}
            </div>
          ))}
          <button type="submit" className="px-6 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
            Salvar horários
          </button>
        </form>
      )}

      {/* Payments tab */}
      {tab === 'payments' && (
        <form onSubmit={handleSavePayments} className="space-y-4 max-w-lg">
          <div className="mb-2">
            <h2 className="text-base font-bold mb-1" style={{ color: 'var(--text)' }}>Métodos de pagamento aceitos</h2>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Configure quais formas de pagamento os clientes poderão usar ao fazer pedidos.</p>
          </div>
          <div className="space-y-3">
            {PAYMENT_METHODS.map(({ id, label, desc }) => (
              <div
                key={id}
                className="flex items-center gap-3 p-3 rounded-xl cursor-pointer"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
                onClick={() => togglePayment(id)}
              >
                <div
                  className="relative w-9 h-5 rounded-full flex-shrink-0 transition-colors"
                  style={{ background: selectedPayments.includes(id) ? 'var(--primary)' : 'var(--border)' }}
                >
                  <div
                    className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform"
                    style={{ transform: selectedPayments.includes(id) ? 'translateX(1.125rem)' : 'translateX(0.125rem)' }}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>{label}</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{desc}</p>
                </div>
              </div>
            ))}
          </div>
          {selectedPayments.length === 0 && (
            <p className="text-sm font-medium" style={{ color: 'var(--error)' }}>Selecione ao menos um método de pagamento</p>
          )}
          <button
            type="submit"
            disabled={selectedPayments.length === 0}
            className="px-6 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-40"
            style={{ background: 'var(--primary)' }}
          >
            Salvar pagamentos
          </button>
        </form>
      )}

      {/* Plan tab */}
      {tab === 'plan' && (
        <div className="max-w-lg">
          <div className="p-5 rounded-2xl mb-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: 'var(--text-muted)' }}>Plano atual</p>
            <p className="text-2xl font-black mb-1" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: PLAN_COLOR[ft.subscriptionPlan] }}>
              {PLAN_LABELS[ft.subscriptionPlan]}
            </p>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{PLAN_PRICES[ft.subscriptionPlan]}</p>
          </div>
          <Link
            to="/manage/plans"
            className="w-full block text-center py-3 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90"
            style={{ background: 'var(--primary)' }}
          >
            Gerenciar plano
          </Link>
        </div>
      )}

      {/* Danger tab */}
      {tab === 'danger' && (
        <div className="max-w-lg">
          <div className="p-5 rounded-2xl" style={{ border: '2px solid var(--error)', background: 'var(--error-soft)' }}>
            <h2 className="text-base font-bold mb-1" style={{ color: 'var(--error)' }}>Excluir Food Truck</h2>
            <p className="text-sm mb-3" style={{ color: 'var(--error)' }}>
              Esta ação é irreversível. Ao excluir seu food truck, ele será removido permanentemente da plataforma, incluindo todos os dados de produtos, estoque, pedidos e histórico.
            </p>
            <button onClick={() => setShowDeleteModal(true)} className="px-5 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--error)' }}>
              Excluir Food Truck permanentemente
            </button>
          </div>
        </div>
      )}

      {/* Delete confirm modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-2xl p-6" style={{ background: 'var(--card)' }}>
            <h3 className="text-base font-bold mb-2" style={{ color: 'var(--error)' }}>Excluir Food Truck</h3>
            <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
              Para confirmar, digite o nome do seu food truck: <strong style={{ color: 'var(--text)' }}>{ft.name}</strong>
            </p>
            <input
              value={deleteInput}
              onChange={e => setDeleteInput(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl text-sm outline-none mb-4"
              style={{ background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }}
              placeholder={ft.name}
            />
            <div className="flex gap-3">
              <button onClick={() => { setShowDeleteModal(false); setDeleteInput('') }} className="flex-1 py-2.5 rounded-xl text-sm" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
              <button
                onClick={handleDelete}
                disabled={deleteInput !== ft.name}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-40"
                style={{ background: 'var(--error)' }}
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
