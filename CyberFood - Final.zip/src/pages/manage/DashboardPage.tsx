import { useApp } from '../../context/AppContext'
import { useNavigate } from 'react-router-dom'
import { OrderStatusBadge } from '../client/ClientHomePage'

function StatCard({ icon, label, value, sub, color = 'var(--primary)' }: { icon: React.ReactNode; label: string; value: string | number; sub?: string; color?: string }) {
  return (
    <div className="p-5 rounded-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>{label}</p>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${color}18` }}>
          <span style={{ color }}>{icon}</span>
        </div>
      </div>
      <p className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>{value}</p>
      {sub && <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{sub}</p>}
    </div>
  )
}

function ActionCard({ icon, title, desc, onClick }: { icon: React.ReactNode; title: string; desc: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-4 p-4 rounded-xl text-left transition-all hover:opacity-90"
      style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}
    >
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'var(--primary-soft)' }}>
        {icon}
      </div>
      <div>
        <p className="text-sm font-bold" style={{ color: 'var(--text)' }}>{title}</p>
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{desc}</p>
      </div>
    </button>
  )
}

const PLAN_LABELS = { free: 'Gratuito', essential: 'Essencial', professional: 'Profissional' }

export default function DashboardPage() {
  const { getMyFoodTruck, getFoodTruckOrders, getFoodTruckProducts, getFoodTruckInventory, toggleFoodTruckOpen } = useApp()
  const navigate = useNavigate()
  const ft = getMyFoodTruck()

  if (!ft) return null

  const orders = getFoodTruckOrders(ft.id)
  const products = getFoodTruckProducts(ft.id)
  const inventory = getFoodTruckInventory(ft.id)

  const todayStr = new Date().toISOString().split('T')[0]
  const todayOrders = orders.filter(o => o.createdAt.startsWith(todayStr))
  const todayRevenue = todayOrders.reduce((s, o) => s + o.total, 0)
  const activeOrders = orders.filter(o => !['Retirado'].includes(o.status))
  const lowStockItems = inventory.filter(i => i.quantity <= i.maxStock * 0.2)

  const recentOrders = [...orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5)

  const productSales: Record<string, { name: string; qty: number }> = {}
  orders.filter(o => o.status === 'Retirado').forEach(o => {
    o.items.forEach(item => {
      if (!productSales[item.productId]) productSales[item.productId] = { name: item.name, qty: 0 }
      productSales[item.productId].qty += item.quantity
    })
  })
  const topProducts = Object.values(productSales).sort((a, b) => b.qty - a.qty).slice(0, 3)
  const isEmpty = products.length === 0 && orders.length === 0

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>{ft.name}</h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--text-muted)' }}>Dashboard de operações</p>
        </div>
        <button
          onClick={() => toggleFoodTruckOpen(ft.id)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-90"
          style={{
            background: ft.isOpen ? 'var(--error-soft)' : 'var(--success-soft)',
            color: ft.isOpen ? 'var(--error)' : 'var(--success)',
            border: `1.5px solid ${ft.isOpen ? 'var(--error)' : 'var(--success)'}`,
          }}
        >
          <span className="w-2 h-2 rounded-full" style={{ background: ft.isOpen ? 'var(--error)' : 'var(--success)' }} />
          {ft.isOpen ? 'Fechar Food Truck' : 'Abrir Food Truck'}
        </button>
      </div>

      {/* Plan banner (free plan only) */}
      {ft.subscriptionPlan === 'free' && (
        <div
          className="mb-6 p-4 rounded-xl flex items-center justify-between gap-4"
          style={{ background: 'var(--primary-soft)', border: '1px solid var(--primary)' }}
        >
          <div>
            <p className="text-sm font-bold" style={{ color: 'var(--primary-dark)' }}>
              Plano {PLAN_LABELS[ft.subscriptionPlan]}
            </p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--primary-dark)' }}>
              Desbloqueie estoque, promoções e relatórios com o plano Essencial.
            </p>
          </div>
          <button
            onClick={() => navigate('/manage/plans')}
            className="flex-shrink-0 px-4 py-2 rounded-lg text-xs font-bold text-white transition-all hover:opacity-90"
            style={{ background: 'var(--primary)' }}
          >
            Ver planos
          </button>
        </div>
      )}
      {ft.subscriptionPlan !== 'free' && (
        <div
          className="mb-6 p-3 rounded-xl flex items-center justify-between gap-4"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
        >
          <p className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>
            Plano ativo: <span style={{ color: 'var(--text)', fontWeight: 600 }}>{PLAN_LABELS[ft.subscriptionPlan]}</span>
          </p>
          <button onClick={() => navigate('/manage/plans')} className="text-xs font-medium" style={{ color: 'var(--primary)' }}>
            Gerenciar
          </button>
        </div>
      )}

      {isEmpty ? (
        <div className="text-center py-12">
          <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text)' }}>Bem-vindo ao CyberFood!</h2>
          <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>Seu food truck está pronto para começar. Complete os passos abaixo.</p>
          <div className="max-w-sm mx-auto space-y-3">
            <ActionCard
              icon={<svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>}
              title="Adicionar primeiro produto"
              desc="Crie o cardápio do seu food truck"
              onClick={() => navigate('/manage/products')}
            />
            <ActionCard
              icon={<svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}><path d="M21 8v13H3V8"/><path d="M23 3H1v5h22V3z"/><line x1="10" y1="12" x2="14" y2="12"/></svg>}
              title="Configurar estoque"
              desc="Gerencie seus ingredientes e insumos"
              onClick={() => navigate('/manage/inventory')}
            />
            <ActionCard
              icon={<svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
              title="Configurar horários"
              desc="Defina os horários de funcionamento"
              onClick={() => navigate('/manage/settings')}
            />
          </div>
        </div>
      ) : (
        <>
          {/* Low stock alert */}
          {lowStockItems.length > 0 && (
            <div className="mb-6 p-4 rounded-xl flex items-start gap-3" style={{ background: 'var(--warning-soft)', border: '1px solid var(--warning)' }}>
              <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" className="flex-shrink-0 mt-0.5" style={{ color: 'var(--warning)' }}>
                <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
              </svg>
              <div>
                <p className="text-sm font-bold" style={{ color: 'var(--warning)' }}>Estoque baixo ({lowStockItems.length} item{lowStockItems.length !== 1 ? 's' : ''})</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--warning)' }}>{lowStockItems.map(i => i.name).join(', ')}</p>
                <button onClick={() => navigate('/manage/restocking')} className="text-xs font-bold mt-1 underline" style={{ color: 'var(--warning)' }}>
                  Reabastecer agora
                </button>
              </div>
            </div>
          )}

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              icon={<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>}
              label="Pedidos hoje"
              value={todayOrders.length}
              sub={`${activeOrders.length} ativo${activeOrders.length !== 1 ? 's' : ''}`}
            />
            <StatCard
              icon={<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>}
              label="Faturamento"
              value={`R$ ${todayRevenue.toFixed(2).replace('.', ',')}`}
              sub="Hoje"
              color="var(--success)"
            />
            <StatCard
              icon={<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>}
              label="Produtos"
              value={products.length}
              sub={`${products.filter(p => p.available).length} disponíveis`}
              color="#7C3AED"
            />
            <StatCard
              icon={<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8v13H3V8"/><path d="M23 3H1v5h22V3z"/></svg>}
              label="Estoque baixo"
              value={lowStockItems.length}
              sub="Itens críticos"
              color={lowStockItems.length > 0 ? 'var(--error)' : 'var(--success)'}
            />
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Recent orders */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-base font-bold" style={{ color: 'var(--text)' }}>Pedidos recentes</h2>
                <button onClick={() => navigate('/manage/orders')} className="text-xs font-medium" style={{ color: 'var(--primary)' }}>Ver todos</button>
              </div>
              {recentOrders.length === 0 ? (
                <div className="p-6 rounded-xl text-center text-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
                  Você ainda não recebeu pedidos.
                </div>
              ) : (
                <div className="space-y-2">
                  {recentOrders.map(order => (
                    <div key={order.id} className="flex items-center justify-between p-3 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                      <div>
                        <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>#{order.id.slice(-6).toUpperCase()} · {order.clientName}</p>
                        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>R$ {order.total.toFixed(2).replace('.', ',')}</p>
                      </div>
                      <OrderStatusBadge status={order.status} />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Top products */}
            <div>
              <h2 className="text-base font-bold mb-3" style={{ color: 'var(--text)' }}>Produtos mais vendidos</h2>
              {topProducts.length === 0 ? (
                <div className="p-6 rounded-xl text-center text-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
                  Dados insuficientes para ranking.
                </div>
              ) : (
                <div className="space-y-2">
                  {topProducts.map((p, i) => (
                    <div key={p.name} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                      <span className="w-7 h-7 rounded-full text-xs font-black flex items-center justify-center text-white" style={{ background: 'var(--primary)' }}>{i + 1}</span>
                      <p className="flex-1 text-sm font-medium" style={{ color: 'var(--text)' }}>{p.name}</p>
                      <p className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{p.qty} vendido{p.qty !== 1 ? 's' : ''}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
