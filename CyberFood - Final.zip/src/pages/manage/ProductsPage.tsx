import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import type { Product, ProductIngredient, ProductAddon } from '../../lib/types'
import { uid } from '../../lib/storage'
import { PlanGate } from '../../components/ui/PlanGate'

const CATEGORIES = ['Hambúrgueres', 'Acompanhamentos', 'Bebidas', 'Sobremesas', 'Entradas', 'Pratos principais', 'Tacos', 'Burritos', 'Nachos', 'Pizzas', 'Massas', 'Noodles', 'Outros']

const EMPTY: Omit<Product, 'id' | 'foodTruckId' | 'createdAt'> = {
  name: '', description: '', price: 0, image: '', category: 'Pratos principais', ingredients: [], recipe: [], addons: [], available: true,
}

export default function ProductsPage() {
  const { getMyFoodTruck, getFoodTruckProducts, createProduct, updateProduct, deleteProduct, getFoodTruckInventory } = useApp()
  const ft = getMyFoodTruck()
  const [modal, setModal] = useState<'create' | Product | null>(null)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  if (!ft) return null
  const products = getFoodTruckProducts(ft.id)
  const inventory = getFoodTruckInventory(ft.id)

  const handleSave = (data: typeof EMPTY) => {
    if (modal === 'create') {
      createProduct({ ...data, foodTruckId: ft.id })
    } else if (modal) {
      updateProduct((modal as Product).id, data)
    }
    setModal(null)
  }

  const handleDelete = (id: string) => {
    deleteProduct(id)
    setDeleteConfirm(null)
  }

  const categories = [...new Set(products.map(p => p.category))]

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Produtos</h1>
        <button
          onClick={() => setModal('create')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90"
          style={{ background: 'var(--primary)' }}
        >
          + Novo produto
        </button>
      </div>

      {products.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: 'var(--primary-soft)' }}>
            <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}>
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>
            </svg>
          </div>
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Você ainda não possui produtos</h3>
          <p className="text-sm mb-5" style={{ color: 'var(--text-muted)' }}>Adicione produtos para montar o cardápio do seu food truck.</p>
          <button onClick={() => setModal('create')} className="px-5 py-2.5 rounded-full text-white font-bold text-sm" style={{ background: 'var(--primary)' }}>
            Adicionar produto
          </button>
        </div>
      ) : (
        <>
          {categories.map(cat => (
            <div key={cat} className="mb-6">
              <h2 className="text-sm font-bold uppercase tracking-wider mb-3" style={{ color: 'var(--text-muted)' }}>{cat}</h2>
              <div className="space-y-2">
                {products.filter(p => p.category === cat).map(product => (
                  <div key={product.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0" style={{ background: 'var(--surface)' }}>
                      {product.image && <img src={product.image} alt={product.name} className="w-full h-full object-cover" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm" style={{ color: 'var(--text)' }}>{product.name}</p>
                        <span
                          className="text-xs px-2 py-0.5 rounded-full font-medium"
                          style={{ background: product.available ? 'var(--success-soft)' : 'var(--error-soft)', color: product.available ? 'var(--success)' : 'var(--error)' }}
                        >
                          {product.available ? 'Disponível' : 'Indisponível'}
                        </span>
                      </div>
                      <p className="text-xs truncate mt-0.5" style={{ color: 'var(--text-muted)' }}>{product.description}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-bold text-sm" style={{ color: 'var(--primary)' }}>R$ {product.price.toFixed(2).replace('.', ',')}</p>
                      <div className="flex gap-1 mt-1 justify-end">
                        <button
                          onClick={() => setModal(product)}
                          className="px-2 py-1 rounded-lg text-xs font-medium transition-all hover:opacity-80"
                          style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}
                        >
                          Editar
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(product.id)}
                          className="px-2 py-1 rounded-lg text-xs font-medium transition-all hover:opacity-80"
                          style={{ background: 'var(--error-soft)', color: 'var(--error)' }}
                        >
                          Excluir
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </>
      )}

      {/* Delete confirm */}
      {deleteConfirm && (
        <ConfirmModal
          title="Excluir produto?"
          desc="Este produto será removido do cardápio permanentemente."
          onConfirm={() => handleDelete(deleteConfirm)}
          onCancel={() => setDeleteConfirm(null)}
        />
      )}

      {/* Product modal */}
      {modal !== null && (
        <ProductModal
          product={modal === 'create' ? null : modal as Product}
          onSave={handleSave}
          onClose={() => setModal(null)}
          categories={CATEGORIES}
          inventory={inventory}
        />
      )}
    </div>
  )
}

function ProductModal({ product, onSave, onClose, categories, inventory }: {
  product: Product | null
  onSave: (data: typeof EMPTY) => void
  onClose: () => void
  categories: string[]
  inventory: import('../../lib/types').InventoryItem[]
}) {
  const [form, setForm] = useState<typeof EMPTY>(
    product
      ? { name: product.name, description: product.description, price: product.price, image: product.image, category: product.category, ingredients: product.ingredients, recipe: product.recipe || [], addons: product.addons || [], available: product.available }
      : EMPTY
  )
  const [ing, setIng] = useState(product?.ingredients.join(', ') || '')

  const baseInput = 'w-full px-3 py-2.5 rounded-xl text-sm outline-none transition-all'
  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  const [formError, setFormError] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setFormError('')
    if (!form.name.trim()) { setFormError('Informe o nome do produto.'); return }
    if (form.name.length > 80) { setFormError('O nome deve ter no máximo 80 caracteres.'); return }
    if (form.description.length > 500) { setFormError('A descrição deve ter no máximo 500 caracteres.'); return }
    if (form.price <= 0) { setFormError('O preço deve ser maior que zero.'); return }
    if (form.price > 9999) { setFormError('Preço fora do intervalo permitido.'); return }
    onSave({ ...form, name: form.name.trim(), ingredients: ing.split(',').map(s => s.trim()).filter(Boolean) })
  }

  // Recipe helpers
  const addRecipeRow = () => {
    if (!inventory.length) return
    const first = inventory[0]
    setForm(f => ({ ...f, recipe: [...f.recipe, { inventoryItemId: first.id, inventoryItemName: first.name, quantity: 1, unit: first.unit }] }))
  }
  const updateRecipeRow = (idx: number, patch: Partial<ProductIngredient>) => {
    setForm(f => ({
      ...f,
      recipe: f.recipe.map((r, i) => {
        if (i !== idx) return r
        const updated = { ...r, ...patch }
        if (patch.inventoryItemId) {
          const inv = inventory.find(it => it.id === patch.inventoryItemId)
          if (inv) { updated.inventoryItemName = inv.name; updated.unit = inv.unit }
        }
        return updated
      }),
    }))
  }
  const removeRecipeRow = (idx: number) => setForm(f => ({ ...f, recipe: f.recipe.filter((_, i) => i !== idx) }))

  // Addon helpers
  const addAddon = () => {
    const newAddon: ProductAddon = { id: uid(), name: '', price: 0, available: true }
    setForm(f => ({ ...f, addons: [...f.addons, newAddon] }))
  }
  const updateAddon = (idx: number, patch: Partial<ProductAddon>) => {
    setForm(f => ({ ...f, addons: f.addons.map((a, i) => i === idx ? { ...a, ...patch } : a) }))
  }
  const removeAddon = (idx: number) => setForm(f => ({ ...f, addons: f.addons.filter((_, i) => i !== idx) }))

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-md rounded-2xl p-6 max-h-[90vh] overflow-y-auto" style={{ background: 'var(--card)' }}>
        <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text)' }}>
          {product ? 'Editar produto' : 'Novo produto'}
        </h3>
        {formError && (
          <div className="mb-3 px-3 py-2 rounded-lg text-xs font-medium" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>{formError}</div>
        )}
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Nome *">
            <div className="relative">
              <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} maxLength={80} className={baseInput} style={inputStyle} placeholder="Nome do produto" />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs" style={{ color: 'var(--text-muted)' }}>{form.name.length}/80</span>
            </div>
          </Field>
          <Field label="Descrição">
            <div className="relative">
              <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} maxLength={500} className={baseInput} style={{ ...inputStyle, resize: 'none', paddingBottom: '1.5rem' }} placeholder="Descreva o produto..." />
              <span className="absolute bottom-2 right-3 text-xs" style={{ color: 'var(--text-muted)' }}>{form.description.length}/500</span>
            </div>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Preço (R$) *">
              <input type="number" min="0.01" max="9999" step="0.01" required value={form.price || ''} onChange={e => setForm(f => ({ ...f, price: parseFloat(e.target.value) || 0 }))} className={baseInput} style={inputStyle} placeholder="0,00" />
            </Field>
            <Field label="Categoria">
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} className={baseInput} style={inputStyle}>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
          </div>
          <Field label="URL da imagem">
            <input value={form.image} onChange={e => setForm(f => ({ ...f, image: e.target.value }))} className={baseInput} style={inputStyle} placeholder="https://..." />
          </Field>
          <Field label="Ingredientes (separados por vírgula)">
            <input value={ing} onChange={e => setIng(e.target.value)} className={baseInput} style={inputStyle} placeholder="Tomate, queijo, alface..." />
          </Field>
          <label className="flex items-center gap-2 cursor-pointer">
            <div
              onClick={() => setForm(f => ({ ...f, available: !f.available }))}
              className="relative w-10 h-5 rounded-full cursor-pointer transition-colors"
              style={{ background: form.available ? 'var(--primary)' : 'var(--border)' }}
            >
              <div className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform" style={{ transform: form.available ? 'translateX(1.25rem)' : 'translateX(0.125rem)' }} />
            </div>
            <span className="text-sm font-medium" style={{ color: 'var(--text)' }}>Disponível no cardápio</span>
          </label>

          {/* Recipe editor — Essencial+ */}
          <PlanGate requiredPlan="essential" featureName="Receita vinculada ao estoque">
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Receita (ingredientes do estoque)</span>
                {inventory.length > 0 && (
                  <button type="button" onClick={addRecipeRow} className="text-xs font-bold px-2 py-1 rounded-lg" style={{ background: 'var(--primary-soft)', color: 'var(--primary)' }}>
                    + Adicionar ingrediente
                  </button>
                )}
              </div>
              {inventory.length === 0 && (
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Adicione itens ao estoque para vincular ingredientes.</p>
              )}
              {form.recipe.length > 0 && (
                <div className="space-y-2">
                  {form.recipe.map((row, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <select
                        value={row.inventoryItemId}
                        onChange={e => updateRecipeRow(idx, { inventoryItemId: e.target.value })}
                        className="flex-1 px-2 py-1.5 rounded-lg text-xs outline-none"
                        style={inputStyle}
                      >
                        {inventory.map(it => <option key={it.id} value={it.id}>{it.name}</option>)}
                      </select>
                      <input
                        type="number"
                        min="0.01"
                        step="0.01"
                        value={row.quantity || ''}
                        onChange={e => updateRecipeRow(idx, { quantity: parseFloat(e.target.value) || 0 })}
                        className="w-16 px-2 py-1.5 rounded-lg text-xs outline-none"
                        style={inputStyle}
                        placeholder="Qtd"
                      />
                      <span className="text-xs w-8 flex-shrink-0" style={{ color: 'var(--text-muted)' }}>{row.unit}</span>
                      <button type="button" onClick={() => removeRecipeRow(idx)} className="text-xs px-2 py-1 rounded-lg flex-shrink-0" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
                        Rem.
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </PlanGate>

          {/* Addon manager — Essencial+ */}
          <PlanGate requiredPlan="essential" featureName="Adicionais do produto">
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Adicionais</span>
                <button type="button" onClick={addAddon} className="text-xs font-bold px-2 py-1 rounded-lg" style={{ background: 'var(--primary-soft)', color: 'var(--primary)' }}>
                  + Adicionar adicional
                </button>
              </div>
              {form.addons.length > 0 && (
                <div className="space-y-2">
                  {form.addons.map((addon, idx) => (
                    <div key={addon.id} className="p-2 rounded-xl space-y-2" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                      <div className="flex items-center gap-2">
                        <input
                          value={addon.name}
                          onChange={e => updateAddon(idx, { name: e.target.value })}
                          className="flex-1 px-2 py-1.5 rounded-lg text-xs outline-none"
                          style={inputStyle}
                          placeholder="Nome do adicional"
                        />
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={addon.price || ''}
                          onChange={e => updateAddon(idx, { price: parseFloat(e.target.value) || 0 })}
                          className="w-20 px-2 py-1.5 rounded-lg text-xs outline-none"
                          style={inputStyle}
                          placeholder="R$ 0,00"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        {inventory.length > 0 && (
                          <select
                            value={addon.inventoryItemId || ''}
                            onChange={e => updateAddon(idx, { inventoryItemId: e.target.value || undefined })}
                            className="flex-1 px-2 py-1.5 rounded-lg text-xs outline-none"
                            style={inputStyle}
                          >
                            <option value="">Sem vínculo com estoque</option>
                            {inventory.map(it => <option key={it.id} value={it.id}>{it.name}</option>)}
                          </select>
                        )}
                        {addon.inventoryItemId && (
                          <input
                            type="number"
                            min="0.01"
                            step="0.01"
                            value={addon.consumeQty || ''}
                            onChange={e => updateAddon(idx, { consumeQty: parseFloat(e.target.value) || undefined })}
                            className="w-16 px-2 py-1.5 rounded-lg text-xs outline-none"
                            style={inputStyle}
                            placeholder="Qtd"
                          />
                        )}
                        <label className="flex items-center gap-1 cursor-pointer flex-shrink-0">
                          <div
                            onClick={() => updateAddon(idx, { available: !addon.available })}
                            className="relative w-8 h-4 rounded-full cursor-pointer transition-colors"
                            style={{ background: addon.available ? 'var(--primary)' : 'var(--border)' }}
                          >
                            <div className="absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform" style={{ transform: addon.available ? 'translateX(1rem)' : 'translateX(0.125rem)' }} />
                          </div>
                          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Ativo</span>
                        </label>
                        <button type="button" onClick={() => removeAddon(idx)} className="text-xs px-2 py-1 rounded-lg flex-shrink-0" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
                          Excluir
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </PlanGate>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm font-medium" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
            <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>Salvar</button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>{label}</label>
      {children}
    </div>
  )
}

function ConfirmModal({ title, desc, onConfirm, onCancel }: { title: string; desc: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-xs rounded-2xl p-6" style={{ background: 'var(--card)' }}>
        <h3 className="text-base font-bold mb-2" style={{ color: 'var(--text)' }}>{title}</h3>
        <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>{desc}</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 py-2.5 rounded-xl text-sm" style={{ background: 'var(--surface)', color: 'var(--text)' }}>Cancelar</button>
          <button onClick={onConfirm} className="flex-1 py-2.5 rounded-xl text-sm font-bold" style={{ background: 'var(--error)', color: 'white' }}>Excluir</button>
        </div>
      </div>
    </div>
  )
}

export { ConfirmModal, Field }
