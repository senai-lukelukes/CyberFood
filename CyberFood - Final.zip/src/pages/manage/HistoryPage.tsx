import { useState } from 'react'
import { useApp } from '../../context/AppContext'

const CATEGORIES = [
  { id: 'all', label: 'Todos', actions: [] as string[] },
  { id: 'orders', label: 'Pedidos', actions: ['Pedido atualizado', 'Estoque consumido'] },
  { id: 'products', label: 'Produtos', actions: ['Produto criado', 'Produto editado', 'Produto excluído'] },
  { id: 'inventory', label: 'Estoque', actions: ['Estoque alterado', 'Reabastecimento realizado', 'Descarte registrado'] },
  { id: 'promotions', label: 'Promoções', actions: ['Promoção criada', 'Promoção editada', 'Promoção excluída'] },
  { id: 'settings', label: 'Configurações', actions: ['Configuração alterada', 'Food Truck aberto', 'Food Truck fechado', 'Food Truck criado', 'Conta criada'] },
]

const CATEGORY_COLORS: Record<string, string> = {
  orders: '#3B82F6',
  products: 'var(--primary)',
  inventory: '#22C55E',
  promotions: '#EF4444',
  settings: '#94A3B8',
}

function getCategoryForAction(action: string): string {
  for (const cat of CATEGORIES) {
    if (cat.id !== 'all' && cat.actions.includes(action)) return cat.id
  }
  return 'settings'
}

export default function HistoryPage() {
  const { getMyFoodTruck, getFoodTruckAuditLogs } = useApp()
  const ft = getMyFoodTruck()
  const [activeCategory, setActiveCategory] = useState('all')

  if (!ft) return null

  const logs = getFoodTruckAuditLogs(ft.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  const getCount = (catId: string) => {
    if (catId === 'all') return logs.length
    const cat = CATEGORIES.find(c => c.id === catId)
    if (!cat) return 0
    return logs.filter(l => cat.actions.includes(l.action)).length
  }

  const filteredLogs = activeCategory === 'all'
    ? logs
    : logs.filter(l => {
        const cat = CATEGORIES.find(c => c.id === activeCategory)
        return cat ? cat.actions.includes(l.action) : false
      })

  return (
    <div>
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Histórico</h1>

      {/* Category filter pills */}
      <div className="flex flex-wrap gap-2 mb-6">
        {CATEGORIES.map(cat => {
          const count = getCount(cat.id)
          const isActive = activeCategory === cat.id
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-all"
              style={{
                background: isActive ? 'var(--primary)' : 'var(--surface)',
                color: isActive ? '#fff' : 'var(--text-muted)',
                border: isActive ? '1.5px solid var(--primary)' : '1.5px solid var(--border)',
              }}
            >
              {cat.label}
              {cat.id !== 'all' && (
                <span
                  className="text-xs px-1.5 py-0.5 rounded-full font-semibold"
                  style={{
                    background: isActive ? 'rgba(255,255,255,0.25)' : 'var(--border)',
                    color: isActive ? '#fff' : 'var(--text-muted)',
                  }}
                >
                  {count}
                </span>
              )}
            </button>
          )
        })}
      </div>

      {filteredLogs.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>
            {activeCategory === 'all' ? 'Nenhuma ação registrada' : 'Nenhuma ação registrada nesta categoria.'}
          </h3>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>As ações realizadas no sistema serão registradas aqui.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredLogs.map(log => {
            const catId = getCategoryForAction(log.action)
            const dotColor = CATEGORY_COLORS[catId] || '#94A3B8'
            return (
              <div key={log.id} className="flex gap-3 p-4 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div className="flex-shrink-0 mt-1.5">
                  <span className="w-2.5 h-2.5 rounded-full block" style={{ background: dotColor }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{log.action}</p>
                    <p className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
                      {new Date(log.createdAt).toLocaleString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{log.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
