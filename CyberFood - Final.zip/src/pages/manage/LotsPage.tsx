import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import { PlanGate } from '../../components/ui/PlanGate'
import type { InventoryBatch, InventoryItem, DisposalRecord } from '../../lib/types'

function getLotStatus(batch: InventoryBatch): { label: string; color: string; bg: string } {
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const expires = new Date(batch.expiresAt)
  const diffDays = Math.floor((expires.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

  if (batch.remainingQty <= 0) return { label: 'Esgotado', color: 'var(--text-muted)', bg: 'var(--surface)' }
  if (diffDays < 0) return { label: 'Vencido', color: 'var(--error)', bg: 'var(--error-soft)' }
  if (diffDays === 0) return { label: 'Vence hoje', color: 'var(--error)', bg: 'var(--error-soft)' }
  if (diffDays <= 5) return { label: `Vence em ${diffDays}d`, color: 'var(--warning)', bg: 'var(--warning-soft)' }
  return { label: 'Válido', color: 'var(--success)', bg: 'var(--success-soft)' }
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

function lotDisplayLabel(batch: InventoryBatch) {
  return batch.lotLabel || 'Lote #' + batch.id.slice(-6).toUpperCase()
}

type DisposalModalProps = {
  batch: InventoryBatch
  item: InventoryItem
  foodTruckId: string
  onClose: () => void
  onConfirm: (data: Omit<DisposalRecord, 'id' | 'createdAt'>) => void
}

function DisposalModal({ batch, item, foodTruckId, onClose, onConfirm }: DisposalModalProps) {
  const [qty, setQty] = useState('')
  const [reason, setReason] = useState('Vencimento')
  const [estimatedValue, setEstimatedValue] = useState('')
  const [done, setDone] = useState(false)

  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const q = parseFloat(qty)
    if (!q || q <= 0) return
    onConfirm({
      foodTruckId,
      inventoryItemId: item.id,
      itemName: item.name,
      batchId: batch.id,
      quantity: q,
      unit: item.unit,
      reason,
      estimatedValue: estimatedValue ? parseFloat(estimatedValue) : undefined,
    })
    setDone(true)
    setTimeout(onClose, 1200)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-md rounded-2xl p-6" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-bold" style={{ color: 'var(--text)' }}>Registrar descarte</h2>
          <button onClick={onClose} className="p-1 rounded-lg" style={{ color: 'var(--text-muted)' }}>
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <div className="p-3 rounded-xl mb-4 text-sm" style={{ background: 'var(--surface)' }}>
          <p style={{ color: 'var(--text)' }}><strong>{item.name}</strong></p>
          <p style={{ color: 'var(--text-muted)' }}>{lotDisplayLabel(batch)} — disponível: {batch.remainingQty} {item.unit}</p>
        </div>

        {done ? (
          <div className="py-4 text-center text-sm font-bold rounded-xl" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}>
            Descarte registrado com sucesso.
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-muted)' }}>
                Quantidade ({item.unit}) *
              </label>
              <input
                type="number" min="0.01" step="0.01" max={batch.remainingQty} required
                value={qty} onChange={e => setQty(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl text-sm outline-none"
                style={inputStyle}
                placeholder={`Máx: ${batch.remainingQty}`}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-muted)' }}>Motivo *</label>
              <select value={reason} onChange={e => setReason(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm outline-none" style={inputStyle}>
                <option>Vencimento</option>
                <option>Avaria</option>
                <option>Excesso</option>
                <option>Outro</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-muted)' }}>Valor estimado (R$) — opcional</label>
              <input
                type="number" min="0" step="0.01"
                value={estimatedValue} onChange={e => setEstimatedValue(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl text-sm outline-none"
                style={inputStyle}
                placeholder="Ex: 15.00"
              />
            </div>

            <div className="flex gap-3 pt-1">
              <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm font-semibold" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
                Cancelar
              </button>
              <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--error)' }}>
                Confirmar descarte
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}

type StatusFilter = 'all' | 'valid' | 'expiring' | 'expired' | 'depleted'

export default function LotsPage() {
  const { getMyFoodTruck, getFoodTruckInventory, getFoodTruckBatches, registerDisposal } = useApp()
  const ft = getMyFoodTruck()
  if (!ft) return null

  const inventory = getFoodTruckInventory(ft.id)
  const batches = getFoodTruckBatches(ft.id)

  const [ingredientFilter, setIngredientFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [disposalBatch, setDisposalBatch] = useState<InventoryBatch | null>(null)

  const today = new Date(); today.setHours(0, 0, 0, 0)

  function matchesStatus(batch: InventoryBatch, filter: StatusFilter) {
    if (filter === 'all') return true
    const status = getLotStatus(batch)
    if (filter === 'valid') return status.label === 'Válido'
    if (filter === 'expiring') return status.label.startsWith('Vence em')
    if (filter === 'expired') return status.label === 'Vencido' || status.label === 'Vence hoje'
    if (filter === 'depleted') return status.label === 'Esgotado'
    return true
  }

  const filteredBatches = batches.filter(b => {
    const nameMatch = ingredientFilter === 'all' || b.itemName === ingredientFilter
    return nameMatch && matchesStatus(b, statusFilter)
  })

  // Group by ingredient
  const grouped: Record<string, InventoryBatch[]> = {}
  for (const b of filteredBatches) {
    if (!grouped[b.itemName]) grouped[b.itemName] = []
    grouped[b.itemName].push(b)
  }
  // Sort each group by expiry (FEFO)
  for (const key of Object.keys(grouped)) {
    grouped[key].sort((a, b) => a.expiresAt.localeCompare(b.expiresAt))
  }

  const ingredientNames = [...new Set(batches.map(b => b.itemName))].sort()

  // Summary stats
  const validLots = batches.filter(b => getLotStatus(b).label === 'Válido').length
  const expiringLots = batches.filter(b => getLotStatus(b).label.startsWith('Vence em')).length
  const expiredWithStock = batches.filter(b => {
    const s = getLotStatus(b)
    return (s.label === 'Vencido' || s.label === 'Vence hoje') && b.remainingQty > 0
  }).length

  const disposalItem = disposalBatch ? inventory.find(i => i.id === disposalBatch.inventoryItemId) : null

  const STATUS_PILLS: { key: StatusFilter; label: string }[] = [
    { key: 'all', label: 'Todos' },
    { key: 'valid', label: 'Válidos' },
    { key: 'expiring', label: 'Vencendo' },
    { key: 'expired', label: 'Vencidos' },
    { key: 'depleted', label: 'Esgotados' },
  ]

  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  return (
    <PlanGate requiredPlan="essential" featureName="Lotes de Estoque">
      <div>
        <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
          Lotes de Estoque
        </h1>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-5">
          <select
            value={ingredientFilter}
            onChange={e => setIngredientFilter(e.target.value)}
            className="px-3 py-2 rounded-xl text-sm outline-none"
            style={inputStyle}
          >
            <option value="all">Todos os ingredientes</option>
            {ingredientNames.map(n => <option key={n} value={n}>{n}</option>)}
          </select>

          <div className="flex items-center gap-1 flex-wrap">
            {STATUS_PILLS.map(p => (
              <button
                key={p.key}
                onClick={() => setStatusFilter(p.key)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                style={statusFilter === p.key
                  ? { background: 'var(--primary)', color: '#fff' }
                  : { background: 'var(--surface)', color: 'var(--text-muted)', border: '1px solid var(--border)' }
                }
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Summary bar */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 rounded-xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <p className="text-xl font-black" style={{ color: 'var(--success)' }}>{validLots}</p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Lotes válidos</p>
          </div>
          <div className="p-3 rounded-xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <p className="text-xl font-black" style={{ color: 'var(--warning)' }}>{expiringLots}</p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Vencendo em breve</p>
          </div>
          <div className="p-3 rounded-xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <p className="text-xl font-black" style={{ color: 'var(--error)' }}>{expiredWithStock}</p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Vencidos com estoque</p>
          </div>
        </div>

        {/* Lot groups */}
        {Object.keys(grouped).length === 0 ? (
          <div className="p-10 rounded-2xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>Nenhum lote encontrado</p>
            <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
              {statusFilter !== 'all' || ingredientFilter !== 'all'
                ? 'Tente ajustar os filtros aplicados.'
                : 'Registre um reabastecimento para criar lotes.'}
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(grouped).map(([itemName, itemBatches]) => {
              const item = inventory.find(i => i.name === itemName)
              const validAvailable = itemBatches
                .filter(b => {
                  const s = getLotStatus(b)
                  return s.label !== 'Vencido' && s.label !== 'Esgotado'
                })
                .reduce((sum, b) => sum + b.remainingQty, 0)

              return (
                <div key={itemName}>
                  {/* Group header */}
                  <div className="flex items-center justify-between mb-2 px-1">
                    <div>
                      <span className="text-sm font-bold" style={{ color: 'var(--text)' }}>{itemName}</span>
                      {item && (
                        <span className="ml-2 text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
                          {item.category}
                        </span>
                      )}
                    </div>
                    <span className="text-xs font-semibold" style={{ color: 'var(--success)' }}>
                      Disponível: {validAvailable} {item?.unit || ''}
                    </span>
                  </div>

                  <div className="space-y-2">
                    {itemBatches.map(batch => {
                      const status = getLotStatus(batch)
                      const isUrgent = status.label === 'Vencido' || status.label === 'Vence hoje'
                      const progressPct = batch.addedQty > 0 ? Math.max(0, Math.min(100, (batch.remainingQty / batch.addedQty) * 100)) : 0

                      return (
                        <div
                          key={batch.id}
                          className="p-4 rounded-xl"
                          style={{ background: 'var(--card)', border: `1px solid ${isUrgent ? 'var(--error)' : 'var(--border)'}` }}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap mb-2">
                                <span className="text-sm font-bold" style={{ color: 'var(--text)' }}>
                                  {lotDisplayLabel(batch)}
                                </span>
                                <span
                                  className="text-xs font-semibold px-2 py-0.5 rounded-full"
                                  style={{ background: status.bg, color: status.color }}
                                >
                                  {status.label}
                                </span>
                              </div>

                              <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-xs mb-3" style={{ color: 'var(--text-muted)' }}>
                                <span>Entrada: {formatDate(batch.addedAt)}</span>
                                <span>Vencimento: {formatDate(batch.expiresAt)}</span>
                                <span>Quantidade recebida: {batch.addedQty} {item?.unit || ''}</span>
                                <span>Disponível: {batch.remainingQty} {item?.unit || ''}</span>
                              </div>

                              {/* Progress bar */}
                              <div className="h-1.5 rounded-full overflow-hidden mb-2" style={{ background: 'var(--border)' }}>
                                <div
                                  className="h-full rounded-full transition-all"
                                  style={{
                                    width: `${progressPct}%`,
                                    background: progressPct > 50 ? 'var(--success)' : progressPct > 20 ? 'var(--warning)' : 'var(--error)',
                                  }}
                                />
                              </div>

                              {isUrgent && (
                                <p className="text-xs font-semibold mt-1" style={{ color: 'var(--error)' }}>
                                  {status.label === 'Vencido'
                                    ? 'Este lote está vencido. Realize o descarte imediatamente.'
                                    : 'Este lote vence hoje. Utilize ou descarte antes do fim do dia.'}
                                </p>
                              )}
                            </div>

                            {batch.remainingQty > 0 && (
                              <button
                                onClick={() => setDisposalBatch(batch)}
                                className="flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                                style={{ background: 'var(--error-soft)', color: 'var(--error)', border: '1px solid var(--error)' }}
                              >
                                Registrar descarte
                              </button>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Disposal Modal */}
        {disposalBatch && disposalItem && (
          <DisposalModal
            batch={disposalBatch}
            item={disposalItem}
            foodTruckId={ft.id}
            onClose={() => setDisposalBatch(null)}
            onConfirm={(data) => { registerDisposal(data) }}
          />
        )}
      </div>
    </PlanGate>
  )
}
