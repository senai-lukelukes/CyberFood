import { useMemo, useState } from 'react'
import { useApp } from '../../context/AppContext'
import { PlanGate } from '../../components/ui/PlanGate'
import { Field } from './ProductsPage'

type DisposalReason = 'Vencimento' | 'Avaria' | 'Excesso' | 'Outro'

const REASONS: DisposalReason[] = ['Vencimento', 'Avaria', 'Excesso', 'Outro']

const REASON_STYLES: Record<DisposalReason, { bg: string; color: string }> = {
  Vencimento: { bg: 'var(--error-soft)', color: 'var(--error)' },
  Avaria: { bg: 'var(--warning-soft)', color: 'var(--warning)' },
  Excesso: { bg: 'var(--primary-soft)', color: 'var(--primary)' },
  Outro: { bg: 'var(--surface)', color: 'var(--text-muted)' },
}

function ReasonBadge({ reason }: { reason: string }) {
  const r = reason as DisposalReason
  const style = REASON_STYLES[r] ?? REASON_STYLES['Outro']
  return (
    <span
      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: style.bg, color: style.color }}
    >
      {reason}
    </span>
  )
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  })
}

function formatCurrency(value: number): string {
  return `R$ ${value.toFixed(2).replace('.', ',')}`
}

const baseInput =
  'w-full px-3 py-2.5 rounded-xl text-sm outline-none transition-all'
const inputStyle = {
  background: 'var(--surface)',
  border: '1.5px solid var(--border)',
  color: 'var(--text)',
}

function WasteContent() {
  const { getMyFoodTruck, getFoodTruckInventory, getFoodTruckDisposals, registerDisposal } =
    useApp()
  const ft = getMyFoodTruck()

  const [inventoryItemId, setInventoryItemId] = useState('')
  const [quantity, setQuantity] = useState('')
  const [reason, setReason] = useState<DisposalReason>('Vencimento')
  const [estimatedValue, setEstimatedValue] = useState('')
  const [formError, setFormError] = useState('')
  const [successMsg, setSuccessMsg] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const inventory = useMemo(() => (ft ? getFoodTruckInventory(ft.id) : []), [ft, getFoodTruckInventory])
  const disposals = useMemo(
    () =>
      ft
        ? [...getFoodTruckDisposals(ft.id)].sort((a, b) =>
            b.createdAt.localeCompare(a.createdAt)
          )
        : [],
    [ft, getFoodTruckDisposals]
  )

  const summaryStats = useMemo(() => {
    const total = disposals.length
    const valueTotal = disposals.reduce((s, d) => s + (d.estimatedValue ?? 0), 0)

    const counts: Record<string, number> = {}
    for (const d of disposals) {
      counts[d.itemName] = (counts[d.itemName] || 0) + 1
    }
    let topItem = ''
    let topCount = 0
    for (const [name, count] of Object.entries(counts)) {
      if (count > topCount) {
        topCount = count
        topItem = name
      }
    }

    return { total, valueTotal, topItem }
  }, [disposals])

  if (!ft) return null

  const selectedItem = inventory.find((i) => i.id === inventoryItemId)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setFormError('')
    setSuccessMsg('')

    if (!inventoryItemId) {
      setFormError('Selecione um item do estoque.')
      return
    }
    const qty = parseFloat(quantity)
    if (!qty || qty <= 0) {
      setFormError('Informe uma quantidade valida (maior que zero).')
      return
    }
    if (!selectedItem) {
      setFormError('Item nao encontrado.')
      return
    }

    const estVal = estimatedValue ? parseFloat(estimatedValue) : undefined
    if (estimatedValue && (isNaN(estVal as number) || (estVal as number) < 0)) {
      setFormError('Valor estimado invalido.')
      return
    }

    setSubmitting(true)
    registerDisposal({
      foodTruckId: ft.id,
      inventoryItemId,
      itemName: selectedItem.name,
      quantity: qty,
      unit: selectedItem.unit,
      reason,
      estimatedValue: estVal,
    })

    setInventoryItemId('')
    setQuantity('')
    setReason('Vencimento')
    setEstimatedValue('')
    setSuccessMsg('Descarte registrado com sucesso.')
    setSubmitting(false)
  }

  return (
    <div>
      <div className="mb-6">
        <h1
          className="text-2xl font-black mb-1"
          style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
        >
          Controle de Descartes
        </h1>
        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
          Registre e acompanhe os descartes de estoque
        </p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div
          className="p-4 rounded-2xl"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <p
            className="text-xs font-semibold uppercase tracking-wider mb-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Total descartado
          </p>
          <p
            className="text-2xl font-black"
            style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
          >
            {summaryStats.total}
          </p>
          <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
            registros
          </p>
        </div>
        <div
          className="p-4 rounded-2xl"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <p
            className="text-xs font-semibold uppercase tracking-wider mb-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Valor estimado perdido
          </p>
          <p
            className="text-xl font-black truncate"
            style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--error)' }}
          >
            {formatCurrency(summaryStats.valueTotal)}
          </p>
        </div>
        <div
          className="p-4 rounded-2xl"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <p
            className="text-xs font-semibold uppercase tracking-wider mb-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Item mais descartado
          </p>
          <p
            className="text-sm font-bold truncate"
            style={{
              fontFamily: 'Plus Jakarta Sans, sans-serif',
              color: summaryStats.topItem ? 'var(--text)' : 'var(--text-muted)',
            }}
          >
            {summaryStats.topItem || '—'}
          </p>
        </div>
      </div>

      {/* Registration form */}
      <div
        className="rounded-2xl p-5 mb-6"
        style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
      >
        <h2
          className="text-base font-bold mb-4"
          style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
        >
          Registrar descarte
        </h2>

        {formError && (
          <div
            className="mb-3 px-3 py-2 rounded-lg text-xs font-medium"
            style={{ background: 'var(--error-soft)', color: 'var(--error)' }}
          >
            {formError}
          </div>
        )}
        {successMsg && (
          <div
            className="mb-3 px-3 py-2 rounded-lg text-xs font-medium"
            style={{ background: 'var(--success-soft)', color: 'var(--success)' }}
          >
            {successMsg}
          </div>
        )}

        {inventory.length === 0 ? (
          <p className="text-sm text-center py-4" style={{ color: 'var(--text-muted)' }}>
            Nenhum item no estoque. Adicione itens antes de registrar descartes.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <Field label="Item do estoque *">
              <select
                required
                value={inventoryItemId}
                onChange={(e) => setInventoryItemId(e.target.value)}
                className={baseInput}
                style={inputStyle}
              >
                <option value="">Selecione um item...</option>
                {inventory.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} ({item.quantity} {item.unit} disponivel)
                  </option>
                ))}
              </select>
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label={`Quantidade${selectedItem ? ` (${selectedItem.unit})` : ''} *`}>
                <input
                  type="number"
                  min="0.01"
                  step="0.01"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className={baseInput}
                  style={inputStyle}
                  placeholder="0"
                />
              </Field>
              <Field label="Motivo *">
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value as DisposalReason)}
                  className={baseInput}
                  style={inputStyle}
                >
                  {REASONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label="Valor estimado (R$) — opcional">
              <input
                type="number"
                min="0"
                step="0.01"
                value={estimatedValue}
                onChange={(e) => setEstimatedValue(e.target.value)}
                className={baseInput}
                style={inputStyle}
                placeholder="0,00"
              />
            </Field>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90 disabled:opacity-60"
              style={{ background: 'var(--primary)' }}
            >
              Registrar descarte
            </button>
          </form>
        )}
      </div>

      {/* Disposal history */}
      <div>
        <h2
          className="text-sm font-bold uppercase tracking-wider mb-3"
          style={{ color: 'var(--text-muted)' }}
        >
          Historico de descartes
        </h2>

        {disposals.length === 0 ? (
          <div
            className="rounded-2xl p-10 text-center"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
              style={{ background: 'var(--surface)' }}
            >
              <svg
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ color: 'var(--text-muted)' }}
              >
                <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2M10 11v6M14 11v6" />
              </svg>
            </div>
            <h3 className="text-base font-semibold mb-1" style={{ color: 'var(--text)' }}>
              Nenhum descarte registrado
            </h3>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
              Use o formulario acima para registrar descartes de estoque.
            </p>
          </div>
        ) : (
          <div
            className="rounded-2xl overflow-hidden"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            {/* Desktop table */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr
                    style={{
                      borderBottom: '1px solid var(--border)',
                      background: 'var(--surface)',
                    }}
                  >
                    {['Item', 'Quantidade', 'Motivo', 'Valor est.', 'Data'].map((col) => (
                      <th
                        key={col}
                        className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider"
                        style={{ color: 'var(--text-muted)' }}
                      >
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {disposals.map((d, idx) => (
                    <tr
                      key={d.id}
                      style={{
                        borderBottom:
                          idx < disposals.length - 1 ? '1px solid var(--border)' : undefined,
                      }}
                    >
                      <td className="px-4 py-3 font-medium" style={{ color: 'var(--text)' }}>
                        {d.itemName}
                      </td>
                      <td className="px-4 py-3" style={{ color: 'var(--text)' }}>
                        {d.quantity % 1 === 0 ? d.quantity : d.quantity.toFixed(2)} {d.unit}
                      </td>
                      <td className="px-4 py-3">
                        <ReasonBadge reason={d.reason} />
                      </td>
                      <td className="px-4 py-3" style={{ color: 'var(--text-muted)' }}>
                        {d.estimatedValue != null ? formatCurrency(d.estimatedValue) : '—'}
                      </td>
                      <td className="px-4 py-3" style={{ color: 'var(--text-muted)' }}>
                        {formatDate(d.createdAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="sm:hidden">
              {disposals.map((d, idx) => (
                <div
                  key={d.id}
                  className="p-4 space-y-2"
                  style={
                    idx < disposals.length - 1
                      ? { borderBottom: '1px solid var(--border)' }
                      : undefined
                  }
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm" style={{ color: 'var(--text)' }}>
                      {d.itemName}
                    </span>
                    <ReasonBadge reason={d.reason} />
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span style={{ color: 'var(--text-muted)' }}>
                      {d.quantity % 1 === 0 ? d.quantity : d.quantity.toFixed(2)} {d.unit}
                    </span>
                    <span style={{ color: 'var(--text-muted)' }}>
                      {d.estimatedValue != null
                        ? formatCurrency(d.estimatedValue)
                        : 'Sem valor est.'}{' '}
                      · {formatDate(d.createdAt)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default function WastePage() {
  return (
    <PlanGate requiredPlan="professional" featureName="Controle de Descartes">
      <WasteContent />
    </PlanGate>
  )
}
