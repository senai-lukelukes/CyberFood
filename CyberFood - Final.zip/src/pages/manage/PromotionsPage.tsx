import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import type { Promotion, DiscountType, Product } from '../../lib/types'
import { ConfirmModal, Field } from './ProductsPage'

const today = () => new Date().toISOString().slice(0, 10)

function computePromoPrice(product: Product, promo: Promotion): number {
  if (promo.discountType === 'percentage') {
    return Math.max(0, product.price * (1 - promo.discountValue / 100))
  }
  return Math.max(0, product.price - promo.discountValue)
}

function isCurrentlyActive(p: Promotion) {
  const t = today()
  return p.active && p.startDate <= t && p.endDate >= t
}
function isScheduled(p: Promotion) {
  return p.active && p.startDate > today()
}
function isExpired(p: Promotion) {
  return p.active && p.endDate < today()
}
function isDisabled(p: Promotion) {
  return !p.active
}

const TABS = [
  { id: 'active', label: 'Ativas' },
  { id: 'scheduled', label: 'Agendadas' },
  { id: 'expired', label: 'Expiradas' },
  { id: 'inactive', label: 'Inativas' },
] as const

type TabId = typeof TABS[number]['id']

function statusLabel(tab: TabId) {
  const map: Record<TabId, string> = {
    active: 'Nenhuma promoção ativa no momento.',
    scheduled: 'Nenhuma promoção agendada.',
    expired: 'Nenhuma promoção expirada.',
    inactive: 'Nenhuma promoção inativa.',
  }
  return map[tab]
}

export default function PromotionsPage() {
  const { getMyFoodTruck, getFoodTruckPromotions, getFoodTruckProducts, createPromotion, updatePromotion, deletePromotion } = useApp()
  const ft = getMyFoodTruck()
  const [tab, setTab] = useState<TabId>('active')
  const [modal, setModal] = useState<'create' | Promotion | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  if (!ft) return null

  const promotions = getFoodTruckPromotions(ft.id)
  const products = getFoodTruckProducts(ft.id)

  const filtered = promotions.filter(p => {
    if (tab === 'active') return isCurrentlyActive(p)
    if (tab === 'scheduled') return isScheduled(p)
    if (tab === 'expired') return isExpired(p)
    return isDisabled(p)
  })

  const tabCount = (t: TabId) => promotions.filter(p => {
    if (t === 'active') return isCurrentlyActive(p)
    if (t === 'scheduled') return isScheduled(p)
    if (t === 'expired') return isExpired(p)
    return isDisabled(p)
  }).length

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Promoções</h1>
        <button
          onClick={() => setModal('create')}
          className="px-4 py-2 rounded-xl text-sm font-bold text-white"
          style={{ background: 'var(--primary)' }}
        >
          + Nova promoção
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl mb-6" style={{ background: 'var(--surface)' }}>
        {TABS.map(t => {
          const count = tabCount(t.id)
          const active = tab === t.id
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all"
              style={{
                background: active ? 'var(--card)' : 'transparent',
                color: active ? 'var(--primary)' : 'var(--text-muted)',
                boxShadow: active ? 'var(--shadow-sm)' : 'none',
              }}
            >
              {t.label}
              {count > 0 && (
                <span
                  className="text-xs px-1.5 py-0.5 rounded-full font-bold"
                  style={{
                    background: active ? 'var(--primary)' : 'var(--border)',
                    color: active ? 'white' : 'var(--text-muted)',
                    fontSize: '10px',
                  }}
                >
                  {count}
                </span>
              )}
            </button>
          )
        })}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: 'var(--surface)' }}>
            <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--text-muted)' }}>
              <path d="M9 14l2 2 4-4M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
          </div>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{statusLabel(tab)}</p>
          {tab === 'active' && (
            <button onClick={() => setModal('create')} className="mt-4 px-5 py-2.5 rounded-full text-white font-bold text-sm" style={{ background: 'var(--primary)' }}>
              Criar promoção
            </button>
          )}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(promo => {
            const product = products.find(p => p.id === promo.productId)
            const promoPrice = product ? computePromoPrice(product, promo) : null
            const discountLabel = promo.discountType === 'percentage'
              ? `-${promo.discountValue}%`
              : `-R$ ${promo.discountValue.toFixed(2).replace('.', ',')}`

            return (
              <div key={promo.id} className="p-4 rounded-2xl flex flex-col gap-3" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm truncate" style={{ color: 'var(--text)' }}>{promo.name}</p>
                    {promo.description && (
                      <p className="text-xs mt-0.5 line-clamp-2" style={{ color: 'var(--text-muted)' }}>{promo.description}</p>
                    )}
                  </div>
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-semibold flex-shrink-0"
                    style={{
                      background: isCurrentlyActive(promo) ? 'var(--success-soft)' : isScheduled(promo) ? 'var(--primary-soft)' : isExpired(promo) ? 'var(--warning-soft)' : 'var(--surface)',
                      color: isCurrentlyActive(promo) ? 'var(--success)' : isScheduled(promo) ? 'var(--primary)' : isExpired(promo) ? 'var(--warning)' : 'var(--text-muted)',
                    }}
                  >
                    {isCurrentlyActive(promo) ? 'Ativa' : isScheduled(promo) ? 'Agendada' : isExpired(promo) ? 'Expirada' : 'Inativa'}
                  </span>
                </div>

                {/* Product & price */}
                {product ? (
                  <div className="p-2.5 rounded-xl" style={{ background: 'var(--surface)' }}>
                    <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Produto</p>
                    <p className="text-sm font-semibold truncate" style={{ color: 'var(--text)' }}>{product.name}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-sm line-through" style={{ color: 'var(--text-muted)' }}>
                        R$ {product.price.toFixed(2).replace('.', ',')}
                      </span>
                      {promoPrice !== null && (
                        <span className="text-base font-black" style={{ color: 'var(--primary)' }}>
                          R$ {promoPrice.toFixed(2).replace('.', ',')}
                        </span>
                      )}
                      <span className="text-xs px-1.5 py-0.5 rounded font-bold ml-auto" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
                        {discountLabel}
                      </span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs italic" style={{ color: 'var(--text-muted)' }}>Produto removido</p>
                )}

                {/* Dates & usage */}
                <div className="flex items-center justify-between text-xs" style={{ color: 'var(--text-muted)' }}>
                  <span>{new Date(promo.startDate + 'T12:00').toLocaleDateString('pt-BR')} — {new Date(promo.endDate + 'T12:00').toLocaleDateString('pt-BR')}</span>
                  <span>{promo.usageCount} uso{promo.usageCount !== 1 ? 's' : ''}</span>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-1 border-t" style={{ borderColor: 'var(--border)' }}>
                  <button
                    onClick={() => updatePromotion(promo.id, { active: !promo.active })}
                    className="flex-1 py-1.5 rounded-lg text-xs font-medium transition-all"
                    style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}
                  >
                    {promo.active ? 'Desativar' : 'Ativar'}
                  </button>
                  <button
                    onClick={() => setModal(promo)}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium"
                    style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}
                  >
                    Editar
                  </button>
                  {isDisabled(promo) || isExpired(promo) ? (
                    <button
                      onClick={() => setDeleteId(promo.id)}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium"
                      style={{ background: 'var(--error-soft)', color: 'var(--error)' }}
                    >
                      Excluir
                    </button>
                  ) : null}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {deleteId && (
        <ConfirmModal
          title="Excluir promoção?"
          desc="Esta promoção será excluída permanentemente."
          onConfirm={() => { deletePromotion(deleteId); setDeleteId(null) }}
          onCancel={() => setDeleteId(null)}
        />
      )}

      {modal !== null && (
        <PromoModal
          promo={modal === 'create' ? null : (modal as Promotion)}
          products={products}
          onSave={data => {
            if (modal === 'create') {
              createPromotion({
                foodTruckId: ft.id,
                productId: data.productId!,
                name: data.name!,
                description: data.description ?? '',
                discountType: data.discountType!,
                discountValue: data.discountValue!,
                startDate: data.startDate!,
                endDate: data.endDate!,
                active: true,
                usageCount: 0,
              })
            } else {
              updatePromotion((modal as Promotion).id, data)
            }
            setModal(null)
          }}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  )
}

type PromoForm = {
  productId: string
  name: string
  description: string
  discountType: DiscountType
  discountValue: number
  startDate: string
  endDate: string
}

function PromoModal({
  promo,
  products,
  onSave,
  onClose,
}: {
  promo: Promotion | null
  products: Product[]
  onSave: (d: Partial<Promotion>) => void
  onClose: () => void
}) {
  const t = today()
  const [form, setForm] = useState<PromoForm>({
    productId: promo?.productId || (products[0]?.id ?? ''),
    name: promo?.name || '',
    description: promo?.description || '',
    discountType: promo?.discountType || 'percentage',
    discountValue: promo?.discountValue || 10,
    startDate: promo?.startDate || t,
    endDate: promo?.endDate || t,
  })
  const [error, setError] = useState('')

  const selectedProduct = products.find(p => p.id === form.productId)
  const previewPrice = selectedProduct ? (
    form.discountType === 'percentage'
      ? Math.max(0, selectedProduct.price * (1 - form.discountValue / 100))
      : Math.max(0, selectedProduct.price - form.discountValue)
  ) : null

  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }
  const baseInput = 'w-full px-3 py-2.5 rounded-xl text-sm outline-none'

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!form.productId) { setError('Selecione um produto.'); return }
    if (form.discountValue <= 0) { setError('O desconto deve ser maior que zero.'); return }
    if (form.discountType === 'percentage' && form.discountValue > 100) { setError('Desconto percentual não pode exceder 100%.'); return }
    if (selectedProduct && form.discountType === 'fixed' && form.discountValue >= selectedProduct.price) {
      setError('O desconto fixo não pode ser igual ou maior que o preço do produto.')
      return
    }
    if (form.endDate < form.startDate) { setError('A data de fim deve ser igual ou posterior à data de início.'); return }
    onSave(form)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-md rounded-2xl p-6 overflow-y-auto max-h-[90vh]" style={{ background: 'var(--card)' }}>
        <h3 className="text-base font-bold mb-4" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
          {promo ? 'Editar promoção' : 'Nova promoção'}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Product picker */}
          <Field label="Produto *">
            {products.length === 0 ? (
              <p className="text-sm p-3 rounded-xl" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
                Cadastre produtos antes de criar promoções.
              </p>
            ) : (
              <select
                required
                value={form.productId}
                onChange={e => setForm(f => ({ ...f, productId: e.target.value }))}
                className={baseInput}
                style={inputStyle}
              >
                {products.map(p => (
                  <option key={p.id} value={p.id}>{p.name} — R$ {p.price.toFixed(2).replace('.', ',')}</option>
                ))}
              </select>
            )}
          </Field>

          <Field label="Nome da promoção *">
            <input
              required
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              className={baseInput}
              style={inputStyle}
              placeholder="Ex: Combo Família, Promoção Relâmpago"
            />
          </Field>

          <Field label="Descrição">
            <input
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              className={baseInput}
              style={inputStyle}
              placeholder="Breve descrição (opcional)"
            />
          </Field>

          {/* Discount type + value */}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tipo de desconto *">
              <select
                value={form.discountType}
                onChange={e => setForm(f => ({ ...f, discountType: e.target.value as DiscountType }))}
                className={baseInput}
                style={inputStyle}
              >
                <option value="percentage">Percentual (%)</option>
                <option value="fixed">Valor fixo (R$)</option>
              </select>
            </Field>
            <Field label={form.discountType === 'percentage' ? 'Desconto (%) *' : 'Desconto (R$) *'}>
              <input
                type="number"
                min="0.01"
                max={form.discountType === 'percentage' ? 100 : undefined}
                step={form.discountType === 'percentage' ? '1' : '0.01'}
                required
                value={form.discountValue}
                onChange={e => setForm(f => ({ ...f, discountValue: +e.target.value }))}
                className={baseInput}
                style={inputStyle}
              />
            </Field>
          </div>

          {/* Price preview */}
          {selectedProduct && previewPrice !== null && (
            <div className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--surface)' }}>
              <div className="flex-1">
                <p className="text-xs font-medium mb-0.5" style={{ color: 'var(--text-muted)' }}>Preço após desconto</p>
                <div className="flex items-center gap-2">
                  <span className="text-sm line-through" style={{ color: 'var(--text-muted)' }}>
                    R$ {selectedProduct.price.toFixed(2).replace('.', ',')}
                  </span>
                  <span className="text-base font-black" style={{ color: 'var(--primary)' }}>
                    R$ {previewPrice.toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>
              <span className="text-xs px-2 py-1 rounded-lg font-bold" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
                {form.discountType === 'percentage'
                  ? `-${form.discountValue}%`
                  : `-R$ ${form.discountValue.toFixed(2).replace('.', ',')}`}
              </span>
            </div>
          )}

          {/* Date range */}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Data de início *">
              <input
                type="date"
                required
                value={form.startDate}
                onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))}
                className={baseInput}
                style={inputStyle}
              />
            </Field>
            <Field label="Data de fim *">
              <input
                type="date"
                required
                min={form.startDate}
                value={form.endDate}
                onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))}
                className={baseInput}
                style={inputStyle}
              />
            </Field>
          </div>

          {error && (
            <p className="text-xs px-3 py-2 rounded-lg" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
              {error}
            </p>
          )}

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm font-medium" style={{ background: 'var(--surface)', color: 'var(--text)' }}>
              Cancelar
            </button>
            <button
              type="submit"
              disabled={products.length === 0}
              className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
              style={{ background: 'var(--primary)' }}
            >
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
