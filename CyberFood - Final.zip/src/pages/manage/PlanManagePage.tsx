import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import type { SubscriptionPlan } from '../../lib/types'

const PLANS: { id: SubscriptionPlan; name: string; price: string; desc: string; features: string[]; color: string }[] = [
  {
    id: 'free',
    name: 'Gratuito',
    price: 'R$ 0/mês',
    desc: 'Gestão básica para começar',
    color: 'var(--text-muted)',
    features: ['Perfil do food truck', 'Cardápio de produtos', 'Recebimento de pedidos', 'Gestão básica de pedidos'],
  },
  {
    id: 'essential',
    name: 'Essencial',
    price: 'R$ 29,90/mês',
    desc: 'Operação completa',
    color: 'var(--primary)',
    features: ['Tudo do Gratuito', 'Controle de estoque', 'Reabastecimento', 'Gestão de clientes', 'Promoções e descontos', 'Histórico de ações', 'Relatórios básicos'],
  },
  {
    id: 'professional',
    name: 'Profissional',
    price: 'R$ 59,90/mês',
    desc: 'Para negócios consolidados',
    color: '#7C3AED',
    features: ['Tudo do Essencial', 'Previsão de demanda', 'Relatórios avançados', 'Análise de vendas detalhada'],
  },
]

const PLAN_LEVEL: Record<SubscriptionPlan, number> = { free: 0, essential: 1, professional: 2 }

export default function PlanManagePage() {
  const { getMyFoodTruck, upgradePlan } = useApp()
  const ft = getMyFoodTruck()
  const [confirm, setConfirm] = useState<SubscriptionPlan | null>(null)
  const [success, setSuccess] = useState(false)

  if (!ft) return null

  const handleConfirm = () => {
    if (!confirm) return
    upgradePlan(ft.id, confirm)
    setConfirm(null)
    setSuccess(true)
    setTimeout(() => setSuccess(false), 3000)
  }

  const currentPlan = PLANS.find(p => p.id === ft.subscriptionPlan)!

  return (
    <div>
      <h1 className="text-2xl font-black mb-1" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
        Gerenciar Plano
      </h1>
      <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
        Faça upgrade ou downgrade do seu plano a qualquer momento.
      </p>

      {/* Current plan banner */}
      <div
        className="p-4 rounded-xl mb-8 flex items-center justify-between gap-4"
        style={{ background: 'var(--surface)', border: '1.5px solid var(--border)' }}
      >
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider mb-0.5" style={{ color: 'var(--text-muted)' }}>
            Plano atual
          </p>
          <p className="text-lg font-black" style={{ color: currentPlan.color, fontFamily: 'Plus Jakarta Sans, sans-serif' }}>
            {currentPlan.name}
          </p>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{currentPlan.price}</p>
        </div>
        <div
          className="px-3 py-1.5 rounded-lg text-xs font-bold"
          style={{ background: `${currentPlan.color}18`, color: currentPlan.color }}
        >
          Ativo
        </div>
      </div>

      {success && (
        <div className="mb-6 px-4 py-3 rounded-xl text-sm font-medium" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}>
          Plano alterado com sucesso!
        </div>
      )}

      {/* Plan cards */}
      <div className="grid sm:grid-cols-3 gap-4">
        {PLANS.map(plan => {
          const isCurrent = plan.id === ft.subscriptionPlan
          const isUpgrade = PLAN_LEVEL[plan.id] > PLAN_LEVEL[ft.subscriptionPlan]

          return (
            <div
              key={plan.id}
              className="p-5 rounded-2xl flex flex-col"
              style={{
                background: 'var(--card)',
                border: `2px solid ${isCurrent ? plan.color : 'var(--border)'}`,
                opacity: isCurrent ? 1 : 0.9,
              }}
            >
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <h2 className="font-bold text-sm" style={{ color: plan.color }}>{plan.name}</h2>
                  {isCurrent && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${plan.color}18`, color: plan.color }}>
                      Atual
                    </span>
                  )}
                </div>
                <p className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
                  {plan.price}
                </p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{plan.desc}</p>
              </div>

              <ul className="space-y-1.5 flex-1 mb-4">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
                    <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" className="flex-shrink-0 mt-0.5" style={{ color: 'var(--success)' }}>
                      <path d="M20 6L9 17l-5-5" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>

              {!isCurrent && (
                <button
                  onClick={() => setConfirm(plan.id)}
                  className="w-full py-2 rounded-xl text-xs font-bold transition-all hover:opacity-90"
                  style={{
                    background: isUpgrade ? plan.color : 'var(--surface)',
                    color: isUpgrade ? 'white' : 'var(--text)',
                    border: isUpgrade ? 'none' : '1.5px solid var(--border)',
                  }}
                >
                  {isUpgrade ? 'Fazer upgrade' : 'Fazer downgrade'}
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* Confirm modal */}
      {confirm !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="w-full max-w-sm rounded-2xl p-6" style={{ background: 'var(--card)' }}>
            {(() => {
              const plan = PLANS.find(p => p.id === confirm)!
              const isUpgrade = PLAN_LEVEL[confirm] > PLAN_LEVEL[ft.subscriptionPlan]
              return (
                <>
                  <h3 className="text-base font-bold mb-2" style={{ color: 'var(--text)' }}>
                    {isUpgrade ? 'Confirmar upgrade' : 'Confirmar downgrade'}
                  </h3>
                  <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>
                    Você está alterando seu plano de <strong>{currentPlan.name}</strong> para <strong>{plan.name}</strong>.
                  </p>
                  {isUpgrade ? (
                    <p className="text-sm mb-5" style={{ color: 'var(--text-muted)' }}>
                      Novo valor: <strong style={{ color: 'var(--text)' }}>{plan.price}</strong>
                    </p>
                  ) : (
                    <p className="text-sm mb-5" style={{ color: 'var(--warning)' }}>
                      Você perderá acesso a alguns recursos ao fazer downgrade.
                    </p>
                  )}
                  <div className="flex gap-3">
                    <button
                      onClick={() => setConfirm(null)}
                      className="flex-1 py-2.5 rounded-xl text-sm"
                      style={{ background: 'var(--surface)', color: 'var(--text)' }}
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={handleConfirm}
                      className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white"
                      style={{ background: isUpgrade ? plan.color : 'var(--warning)' }}
                    >
                      Confirmar
                    </button>
                  </div>
                </>
              )
            })()}
          </div>
        </div>
      )}
    </div>
  )
}
