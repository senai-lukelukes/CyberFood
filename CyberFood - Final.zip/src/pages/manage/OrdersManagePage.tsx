import { useApp } from '../../context/AppContext'
import type { OrderStatus, Order } from '../../lib/types'

const COLUMNS: { status: OrderStatus; label: string; color: string; bg: string }[] = [
  { status: 'Novo', label: 'NOVOS', color: 'var(--warning)', bg: 'var(--warning-soft)' },
  { status: 'Aceito', label: 'ACEITOS', color: '#2563EB', bg: '#EFF6FF' },
  { status: 'Preparando', label: 'EM PREPARO', color: '#CA8A04', bg: '#FEF9C3' },
  { status: 'Pronto para retirada', label: 'PRONTOS', color: 'var(--success)', bg: 'var(--success-soft)' },
  { status: 'Retirado', label: 'RETIRADOS', color: 'var(--text-muted)', bg: 'var(--surface)' },
]

const NEXT_STATUS: Record<OrderStatus, OrderStatus | null> = {
  'Novo': 'Aceito',
  'Aceito': 'Preparando',
  'Preparando': 'Pronto para retirada',
  'Pronto para retirada': 'Retirado',
  'Retirado': null,
}

const ACTION_LABELS: Partial<Record<OrderStatus, string>> = {
  'Novo': 'Aceitar',
  'Aceito': 'Iniciar preparo',
  'Preparando': 'Marcar como pronto',
  'Pronto para retirada': 'Confirmar retirada',
}

function OrderCard({ order }: { order: Order }) {
  const { updateOrderStatus } = useApp()
  const nextStatus = NEXT_STATUS[order.status]
  const actionLabel = ACTION_LABELS[order.status]

  return (
    <div className="rounded-xl p-3 mb-2" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-bold font-mono" style={{ color: 'var(--text-muted)' }}>
          #{order.id.slice(-6).toUpperCase()}
        </span>
        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
          {new Date(order.createdAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
      <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text)' }}>{order.clientName}</p>
      <div className="mb-2">
        {order.items.map(item => (
          <p key={item.productId} className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {item.quantity}x {item.name}
          </p>
        ))}
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm font-bold" style={{ color: 'var(--primary)' }}>
          R$ {order.total.toFixed(2).replace('.', ',')}
        </span>
        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{order.paymentMethod}</span>
      </div>
      {nextStatus && actionLabel && (
        <button
          onClick={() => updateOrderStatus(order.id, nextStatus)}
          className="w-full mt-2 py-1.5 rounded-lg text-xs font-bold transition-all hover:opacity-90"
          style={{ background: 'var(--primary)', color: 'white' }}
        >
          {actionLabel}
        </button>
      )}
    </div>
  )
}

export default function OrdersManagePage() {
  const { getMyFoodTruck, getFoodTruckOrders } = useApp()
  const ft = getMyFoodTruck()
  if (!ft) return null

  const allOrders = getFoodTruckOrders(ft.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  return (
    <div>
      <h1 className="text-2xl font-black mb-6" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Pedidos</h1>

      {allOrders.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text)' }}>Você ainda não recebeu pedidos</h3>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Os pedidos aparecerão aqui quando os clientes fizerem pedidos.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 overflow-x-auto">
          {COLUMNS.map(col => {
            const colOrders = allOrders.filter(o => o.status === col.status)
            return (
              <div key={col.status} className="min-w-52">
                <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg mb-3" style={{ background: col.bg }}>
                  <p className="text-xs font-black tracking-wider" style={{ color: col.color }}>{col.label}</p>
                  <span className="ml-auto w-5 h-5 rounded-full text-xs font-bold flex items-center justify-center" style={{ background: col.color, color: 'white' }}>
                    {colOrders.length}
                  </span>
                </div>
                {colOrders.map(order => <OrderCard key={order.id} order={order} />)}
                {colOrders.length === 0 && (
                  <div className="text-center py-4 text-xs rounded-xl" style={{ color: 'var(--text-muted)', background: 'var(--surface)', border: '1px dashed var(--border)' }}>
                    Nenhum pedido
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
