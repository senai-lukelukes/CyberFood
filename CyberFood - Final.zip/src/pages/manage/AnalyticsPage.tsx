import { useMemo, useState } from 'react'
import { useApp } from '../../context/AppContext'
import { PlanGate } from '../../components/ui/PlanGate'
import type { Order } from '../../lib/types'

type Period = 'this_month' | 'last_month' | 'last_30' | 'all'

const PERIOD_LABELS: Record<Period, string> = {
  this_month: 'Este mes',
  last_month: 'Mes anterior',
  last_30: 'Ultimos 30 dias',
  all: 'Tudo',
}

function getPeriodBounds(period: Period): { start: string; end: string } | null {
  const now = new Date()
  if (period === 'all') return null

  if (period === 'last_30') {
    const start = new Date(now)
    start.setDate(start.getDate() - 30)
    return { start: start.toISOString(), end: now.toISOString() }
  }

  if (period === 'this_month') {
    const start = new Date(now.getFullYear(), now.getMonth(), 1)
    return { start: start.toISOString(), end: now.toISOString() }
  }

  // last_month
  const start = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  const end = new Date(now.getFullYear(), now.getMonth(), 1)
  return { start: start.toISOString(), end: end.toISOString() }
}

function filterByPeriod(orders: Order[], period: Period): Order[] {
  const bounds = getPeriodBounds(period)
  if (!bounds) return orders
  return orders.filter((o) => o.createdAt >= bounds.start && o.createdAt < bounds.end)
}

function formatCurrency(value: number): string {
  return `R$ ${value.toFixed(2).replace('.', ',')}`
}

function formatPct(value: number): string {
  const sign = value >= 0 ? '+' : ''
  return `${sign}${value.toFixed(1)}%`
}

type Stats = {
  count: number
  revenue: number
  avgTicket: number
  itemsSold: number
  topProducts: { name: string; qty: number; revenue: number }[]
}

function computeStats(orders: Order[]): Stats {
  const completed = orders.filter((o) => o.status === 'Retirado')
  const count = completed.length
  const revenue = completed.reduce((s, o) => s + o.total, 0)
  const avgTicket = count > 0 ? revenue / count : 0
  const itemsSold = completed.reduce(
    (s, o) => s + o.items.reduce((a, i) => a + i.quantity, 0),
    0
  )

  const productMap: Record<string, { name: string; qty: number; revenue: number }> = {}
  for (const order of completed) {
    for (const item of order.items) {
      if (!productMap[item.productId]) {
        productMap[item.productId] = { name: item.name, qty: 0, revenue: 0 }
      }
      productMap[item.productId].qty += item.quantity
      productMap[item.productId].revenue += item.finalPrice * item.quantity
    }
  }
  const topProducts = Object.values(productMap).sort((a, b) => b.qty - a.qty)

  return { count, revenue, avgTicket, itemsSold, topProducts }
}

function StatCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div
      className="p-5 rounded-2xl"
      style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
    >
      <p
        className="text-xs font-semibold uppercase tracking-wider mb-2"
        style={{ color: 'var(--text-muted)' }}
      >
        {label}
      </p>
      <p
        className="text-2xl font-black"
        style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
      >
        {value}
      </p>
      {sub && (
        <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
          {sub}
        </p>
      )}
    </div>
  )
}

function AnalyticsContent() {
  const { getMyFoodTruck, getFoodTruckOrders } = useApp()
  const ft = getMyFoodTruck()
  const [period, setPeriod] = useState<Period>('this_month')

  const allOrders = useMemo(
    () => (ft ? getFoodTruckOrders(ft.id) : []),
    [ft, getFoodTruckOrders]
  )

  const periodOrders = useMemo(
    () => filterByPeriod(allOrders, period),
    [allOrders, period]
  )
  const stats = useMemo(() => computeStats(periodOrders), [periodOrders])

  const comparison = useMemo(() => {
    const now = new Date()
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString()
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString()
    const lastMonthEnd = thisMonthStart

    const thisMonth = allOrders.filter((o) => o.createdAt >= thisMonthStart)
    const lastMonth = allOrders.filter(
      (o) => o.createdAt >= lastMonthStart && o.createdAt < lastMonthEnd
    )

    const current = computeStats(thisMonth)
    const previous = computeStats(lastMonth)

    const pct = (curr: number, prev: number) =>
      prev === 0 ? (curr > 0 ? 100 : 0) : ((curr - prev) / prev) * 100

    return {
      orders: {
        current: current.count,
        previous: previous.count,
        pct: pct(current.count, previous.count),
      },
      revenue: {
        current: current.revenue,
        previous: previous.revenue,
        pct: pct(current.revenue, previous.revenue),
      },
      avgTicket: {
        current: current.avgTicket,
        previous: previous.avgTicket,
        pct: pct(current.avgTicket, previous.avgTicket),
      },
    }
  }, [allOrders])

  if (!ft) return null

  const PERIODS: Period[] = ['this_month', 'last_month', 'last_30', 'all']

  return (
    <div>
      <div className="mb-6">
        <h1
          className="text-2xl font-black mb-1"
          style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}
        >
          Analiticos de Vendas
        </h1>
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
          Apenas pedidos com status 'Retirado' sao contabilizados
        </p>
      </div>

      {/* Period tabs */}
      <div
        className="flex gap-1 p-1 rounded-xl mb-6 overflow-x-auto"
        style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
      >
        {PERIODS.map((p) => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className="flex-1 min-w-max px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap"
            style={
              period === p
                ? {
                    background: 'var(--card)',
                    color: 'var(--primary)',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                  }
                : { color: 'var(--text-muted)' }
            }
          >
            {PERIOD_LABELS[p]}
          </button>
        ))}
      </div>

      {/* Summary section header */}
      <h2
        className="text-sm font-bold uppercase tracking-wider mb-3"
        style={{ color: 'var(--text-muted)' }}
      >
        Resumo do periodo
      </h2>

      {stats.count === 0 ? (
        <div
          className="rounded-2xl p-10 text-center mb-6"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
            style={{ background: 'var(--primary-soft)' }}
          >
            <svg
              width="24"
              height="24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ color: 'var(--primary)' }}
            >
              <line x1="18" y1="20" x2="18" y2="10" />
              <line x1="12" y1="20" x2="12" y2="4" />
              <line x1="6" y1="20" x2="6" y2="14" />
            </svg>
          </div>
          <h3 className="text-base font-bold mb-1" style={{ color: 'var(--text)' }}>
            Nenhum pedido neste periodo
          </h3>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
            Nao ha pedidos concluidos no periodo selecionado.
          </p>
        </div>
      ) : (
        <>
          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard label="Total de pedidos" value={String(stats.count)} />
            <StatCard label="Receita total" value={formatCurrency(stats.revenue)} />
            <StatCard label="Ticket medio" value={formatCurrency(stats.avgTicket)} />
            <StatCard label="Itens vendidos" value={String(stats.itemsSold)} />
          </div>

          {/* Top products */}
          <h2
            className="text-sm font-bold uppercase tracking-wider mb-3"
            style={{ color: 'var(--text-muted)' }}
          >
            Produtos mais vendidos
          </h2>
          <div
            className="rounded-2xl p-5 mb-6"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            {stats.topProducts.length === 0 ? (
              <p className="text-sm text-center py-4" style={{ color: 'var(--text-muted)' }}>
                Nenhum produto vendido no periodo.
              </p>
            ) : (
              <div className="space-y-0">
                {stats.topProducts.slice(0, 10).map((product, idx) => (
                  <div
                    key={product.name}
                    className="flex items-center gap-3 py-3"
                    style={
                      idx < Math.min(stats.topProducts.length, 10) - 1
                        ? { borderBottom: '1px solid var(--border)' }
                        : undefined
                    }
                  >
                    <span
                      className="w-7 h-7 rounded-full text-xs font-black flex items-center justify-center text-white flex-shrink-0"
                      style={{ background: 'var(--primary)' }}
                    >
                      {idx + 1}
                    </span>
                    <span
                      className="flex-1 text-sm font-medium truncate"
                      style={{ color: 'var(--text)' }}
                    >
                      {product.name}
                    </span>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>
                        {product.qty} un.
                      </p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        {formatCurrency(product.revenue)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* Period comparison — always shown */}
      <h2
        className="text-sm font-bold uppercase tracking-wider mb-3"
        style={{ color: 'var(--text-muted)' }}
      >
        Comparativo de periodo
      </h2>
      <div
        className="rounded-2xl p-5"
        style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
      >
        <p className="text-xs mb-4" style={{ color: 'var(--text-muted)' }}>
          Este mes vs. mes anterior
        </p>
        <div className="space-y-0">
          {[
            {
              label: 'Pedidos',
              current: String(comparison.orders.current),
              previous: String(comparison.orders.previous),
              pct: comparison.orders.pct,
            },
            {
              label: 'Receita',
              current: formatCurrency(comparison.revenue.current),
              previous: formatCurrency(comparison.revenue.previous),
              pct: comparison.revenue.pct,
            },
            {
              label: 'Ticket medio',
              current: formatCurrency(comparison.avgTicket.current),
              previous: formatCurrency(comparison.avgTicket.previous),
              pct: comparison.avgTicket.pct,
            },
          ].map((row, idx) => {
            const positive = row.pct >= 0
            return (
              <div
                key={row.label}
                className="flex items-center justify-between py-3"
                style={idx < 2 ? { borderBottom: '1px solid var(--border)' } : undefined}
              >
                <span className="text-sm font-medium" style={{ color: 'var(--text)' }}>
                  {row.label}
                </span>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                      Anterior: {row.previous}
                    </p>
                    <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>
                      {row.current}
                    </p>
                  </div>
                  <span
                    className="flex items-center gap-0.5 text-xs font-bold px-2 py-1 rounded-lg min-w-[56px] justify-center"
                    style={{
                      background: positive ? 'var(--success-soft)' : 'var(--error-soft)',
                      color: positive ? 'var(--success)' : 'var(--error)',
                    }}
                  >
                    <svg
                      width="10"
                      height="10"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      viewBox="0 0 24 24"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      {positive ? (
                        <polyline points="18 15 12 9 6 15" />
                      ) : (
                        <polyline points="6 9 12 15 18 9" />
                      )}
                    </svg>
                    {formatPct(row.pct)}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default function AnalyticsPage() {
  return (
    <PlanGate requiredPlan="professional" featureName="Analiticos de Vendas">
      <AnalyticsContent />
    </PlanGate>
  )
}
