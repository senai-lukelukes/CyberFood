I want you to CREATE THE CYBERFOOD PROJECT FROM SCRATCH.

This is a completely new project. Do not assume there is an existing CyberFood interface, database, design system, screen, component, or previous implementation.

CyberFood is a TCC (final school project), but I want the prototype to feel like a real, polished, modern product.

IMPORTANT:
Do not create a collection of disconnected mockup screens.
Create a coherent, navigable frontend prototype where the main actions and states are connected.

==================================================
1. PRODUCT OVERVIEW
==================================================

CYBERFOOD is a platform for discovering and ordering from FOOD TRUCKS.

Think of it as a food ordering platform specialized in food trucks, with an important additional feature:

INTEGRATED FOOD TRUCK INVENTORY MANAGEMENT.

The platform has two main user types:

1. CLIENT
2. FOOD TRUCK OWNER / STAFF

The client uses CyberFood to:

- discover food trucks;
- search for food trucks and dishes;
- view menus;
- favorite food trucks;
- add products to a cart;
- place orders;
- choose a payment method;
- track the order;
- view previous orders;
- evaluate food trucks;
- send complaints, suggestions and feedback.

The food truck owner uses CyberFood to:

- manage the food truck;
- open and close the food truck;
- define operating hours;
- manage products;
- manage inventory;
- restock products;
- receive and manage orders;
- view customers;
- view evaluations;
- create promotions;
- view history of changes;
- receive low-stock alerts;
- view sales and operational information.

IMPORTANT:

CYBERFOOD DOES NOT HAVE DELIVERY.

All orders are PICKUP orders.

The customer goes to the food truck to collect the order.

Do NOT create delivery addresses or delivery management.

==================================================
2. CORE CONCEPT
==================================================

CyberFood should have two clearly different experiences:

PUBLIC / CLIENT EXPERIENCE

and

FOOD TRUCK MANAGEMENT EXPERIENCE.

They must feel like parts of the same product but have different priorities.

Client experience:
visual, appetizing, simple, fast and discovery-focused.

Food truck experience:
professional, organized, operational and dashboard-focused.

==================================================
3. PUBLIC EXPERIENCE — NO LOGIN REQUIRED
==================================================

A very important rule:

THE USER MUST BE ABLE TO ENTER CYBERFOOD WITHOUT LOGGING IN.

The first page must already show FOOD TRUCKS.

Do not force login immediately.

The visitor should be able to:

- see food trucks;
- search food trucks;
- view food truck information;
- open a food truck;
- view its menu.

However, actions involving personal data or purchases require authentication.

For example:

If a visitor tries to:

- favorite a food truck;
- add a product to the cart;
- checkout;
- place an order;
- view private order history;

then open the login flow.

After authentication, return the user to the action they were trying to perform.

==================================================
4. HOME PAGE
==================================================

Create a beautiful modern homepage.

HEADER:

CyberFood logo on the LEFT.

Search bar in the CENTER.

Navigation on the RIGHT:

Food Trucks
Favoritos
Login

The logo should stay discreetly positioned in the upper-left corner.

Do not center the logo.

The header should be clean and spacious.

LOGIN:

Create a login button/dropdown.

When the user hovers over or clicks Login, show:

Cliente
Food Truck

This makes it immediately clear that CyberFood supports two types of accounts.

==================================================
5. HOME HERO
==================================================

Create a strong but clean hero section.

Main message:

"Seu próximo sabor começa aqui."

Supporting text:

"Encontre food trucks, escolha seus pratos, faça seu pedido e retire onde quiser."

Primary CTA:

"Explorar Food Trucks"

Secondary CTA:

"Quero cadastrar meu Food Truck"

The hero should not hide the actual food trucks.

Immediately below the hero, show food trucks.

==================================================
6. FOOD TRUCK DISCOVERY
==================================================

Create a section such as:

"Explore os Food Trucks"

Show visually attractive food truck cards.

Each card should contain:

- food truck image/logo;
- name;
- category/cuisine;
- rating;
- number of ratings;
- approximate preparation time;
- operating status;
- opening hours;
- favorite button;
- "Ver cardápio" button.

Example food trucks can include:

Burger Express
Taco Loco
Pizza Street
Asia Fusion
Banana King

IMPORTANT:

These are demonstration accounts/data only.

They are NOT templates for new accounts.

==================================================
7. OPEN/CLOSED STATUS
==================================================

Every food truck must have a visible status:

🟢 Aberto

or

🔴 Fechado

The status should be visually clear but should not rely only on color.

Also display the operating hours.

Example:

Aberto
Hoje: 10:00 — 18:00

or

Fechado
Abre às 10:00

==================================================
8. FOOD TRUCK PAGE
==================================================

When the visitor clicks a food truck, open its dedicated page.

Show:

- logo/image;
- name;
- description;
- category;
- rating;
- opening hours;
- current status;
- location for pickup;
- menu.

The menu must belong ONLY to that food truck.

Example:

Burger Express:
Hambúrgueres
Batatas
Bebidas

Taco Loco:
Tacos
Burritos
Nachos
Bebidas

Pizza Street:
Pizzas
Massas
Bebidas

Do NOT give every food truck the same products.

==================================================
9. CLIENT AUTHENTICATION
==================================================

Create a clean authentication flow.

Login:

E-mail
Senha

Buttons:

Entrar
Criar conta

Also:

Esqueci minha senha

The login modal/page must NOT be transparent to the point of making the content difficult to read.

Use a solid, high-contrast surface with a subtle shadow.

==================================================
10. CLIENT REGISTRATION
==================================================

Client registration fields:

Nome completo
E-mail
Senha
Confirmar senha

After successful registration:

- create the client account;
- log the user in;
- redirect to the client experience.

A new client account must start with:

0 orders
0 favorites
0 reviews

Do not give new clients fake history.

==================================================
11. FOOD TRUCK REGISTRATION
==================================================

Food truck registration must be more complete.

Create a dedicated registration flow.

OWNER INFORMATION:

Nome completo
E-mail
Senha
Confirmar senha

FOOD TRUCK INFORMATION:

Nome do Food Truck
Descrição
Categoria
Telefone
Localização
Logo/imagem

OPERATING HOURS:

For each day:

Monday
Tuesday
Wednesday
Thursday
Friday
Saturday
Sunday

Allow:

Aberto / Fechado

If open:

Horário de abertura
Horário de fechamento

Example:

Segunda:
08:00 — 18:00

Terça:
08:00 — 18:00

Quarta:
Fechado

etc.

==================================================
12. CRITICAL RULE — NEW FOOD TRUCKS START EMPTY
==================================================

THIS IS ONE OF THE MOST IMPORTANT RULES IN THE ENTIRE PROJECT.

When a NEW FOOD TRUCK ACCOUNT is created, it MUST START COMPLETELY EMPTY.

Do NOT copy products from demonstration food trucks.

Do NOT copy inventory.

Do NOT copy orders.

Do NOT copy customers.

Do NOT copy reviews.

Do NOT copy promotions.

Do NOT copy sales.

Do NOT copy dashboard statistics.

Do NOT copy history except the account creation event.

A newly created food truck must have:

Products: 0
Inventory items: 0
Orders: 0
Customers: 0
Reviews: 0
Promotions: 0
Sales: 0

The dashboard for a new food truck must show proper empty states instead of fake information.

Example:

"Bem-vindo ao CyberFood!"
"Seu food truck está pronto para começar."

Actions:

"Adicionar primeiro produto"
"Configurar estoque"
"Configurar horários"

==================================================
13. DEMONSTRATION DATA VS REAL USER DATA
==================================================

There are two types of data:

A) DEMONSTRATION DATA

Used only to make the prototype visually demonstrable.

Example:

Burger Express
Taco Loco
Pizza Street
Asia Fusion
Banana King

These can have:

- products;
- orders;
- inventory;
- customers;
- reviews;
- statistics.

B) USER-CREATED DATA

Created by a person using the system.

This data must start empty.

NEVER use demonstration data as a template for a new account.

==================================================
14. FOOD TRUCK DATA ISOLATION
==================================================

Every food truck must have completely isolated management data.

Conceptually, each entity should be associated with a foodTruckId.

For example:

Product:
id
foodTruckId
name
price

Order:
id
foodTruckId
clientId
items
total
status

Inventory:
id
foodTruckId
product
quantity

This means:

Food Truck A can ONLY see Food Truck A's:

- products;
- inventory;
- orders;
- customers;
- reviews;
- promotions;
- history;
- statistics.

Food Truck A must NEVER see Food Truck B's management data.

==================================================
15. CLIENT CAN USE MULTIPLE FOOD TRUCKS
==================================================

A client can order from multiple food trucks.

For example:

Client João orders from Burger Express.

Later João orders from Taco Loco.

That is allowed.

However:

Burger Express can only see João's orders related to Burger Express.

Taco Loco can only see João's orders related to Taco Loco.

==================================================
16. FOOD TRUCK MANAGEMENT AREA
==================================================

Create a completely separate professional management interface.

Sidebar:

Dashboard
Pedidos
Produtos
Estoque
Reabastecimento
Promoções
Clientes
Histórico
Configurações

Top area:

CyberFood

Food Truck name

Current status:

🟢 Aberto
or
🔴 Fechado

User profile

Notifications

==================================================
17. FOOD TRUCK DASHBOARD
==================================================

The dashboard should contain:

Pedidos hoje
Faturamento
Produtos cadastrados
Itens com estoque baixo

And operational information such as:

Pedidos recentes
Produtos mais vendidos
Alertas de estoque

IMPORTANT:

If the food truck is newly created and has no data:

DO NOT display fake statistics.

Show:

0 pedidos
R$ 0,00
0 produtos

and useful empty states.

==================================================
18. FOOD TRUCK OPEN/CLOSE CONTROL
==================================================

The owner must be able to manually control whether the food truck is accepting orders.

Example:

🟢 Food Truck aberto

[Fechar Food Truck]

or:

🔴 Food Truck fechado

[Abrir Food Truck]

The system must also use the configured operating hours.

For example:

If the food truck operates from 10:00 to 18:00:

At 14:00:
Open.

At 20:00:
Closed.

==================================================
19. CLOSED FOOD TRUCK RULE
==================================================

THIS RULE MUST BE ENFORCED.

If the food truck is closed:

The customer CAN:

- view the food truck;
- view the menu;
- see products;
- see opening hours.

The customer CANNOT:

- add products to the cart;
- start a new order;
- checkout;
- place a new order.

Show a clear message:

"Este food truck está fechado no momento."

IMPORTANT:

Existing orders must NOT be cancelled just because the food truck closes.

An existing order must continue through:

Novo
→ Aceito
→ Preparando
→ Pronto para retirada
→ Retirado

==================================================
20. CLIENT EXPERIENCE AFTER LOGIN
==================================================

Once a client logs in, do NOT show the entire public landing page again.

The logged-in experience should focus on:

Food Trucks
Favoritos
Pedidos recentes
Recomendações

Example greeting:

"Olá, João!"

Then:

"Seus favoritos"

"Explore Food Trucks"

"Seu último pedido"

"Recomendados para você"

==================================================
21. FAVORITES
==================================================

Clients can favorite food trucks.

Unfavoriting must also work.

If the user is not logged in and clicks the favorite button:

Open login.

After login:

return to the food truck/action.

The logged-in client's home should show favorite food trucks near the top.

==================================================
22. CART
==================================================

A cart can contain products from ONLY ONE food truck.

Do not allow:

Burger Express + Taco Loco

in the same cart.

If the user tries to add a product from another food truck:

show a confirmation:

"Seu carrinho possui produtos de outro Food Truck."

"Você deseja limpar o carrinho e começar um novo pedido?"

Buttons:

Cancelar
Continuar

==================================================
23. CHECKOUT
==================================================

There is NO DELIVERY.

The checkout must clearly say:

"Retirada no Food Truck"

Show:

Food Truck
Pickup location
Products
Quantities
Total

Payment options for the prototype:

PIX
Cartão
Dinheiro na retirada

No real payment processing is required.

==================================================
24. ORDER STATUS
==================================================

Orders must have these states:

Novo
Aceito
Preparando
Pronto para retirada
Retirado

The customer must be able to track the order visually.

Create a timeline:

✓ Pedido recebido
✓ Pedido aceito
● Preparando
○ Pronto para retirada
○ Retirado

The current state must be obvious.

==================================================
25. FOOD TRUCK ORDER MANAGEMENT
==================================================

The food truck management area should display orders in a clear Kanban-style layout.

Columns:

NOVOS
EM PREPARO
PRONTOS
RETIRADOS

Each order card:

Order number
Customer name
Products
Quantity
Total
Time
Status

Allow the food truck to change order status.

Changes must be reflected in the client experience.

==================================================
26. PRODUCTS
==================================================

Food truck owners can:

Create product
Edit product
Delete product
Activate/deactivate product

Product fields:

Nome
Descrição
Preço
Imagem
Categoria
Ingredientes
Disponibilidade

Deleted products must no longer appear in the menu.

==================================================
27. INVENTORY
==================================================

Inventory categories:

Vegetais
Perecíveis
Laticínios
Carnes
Bebidas
Outros

Each inventory item:

Nome
Categoria
Quantidade
Unidade
Estoque mínimo
Estoque máximo

Inventory status:

🟢 Alto
🟡 Médio
🔴 Baixo

The system must also display the written status:

Alto
Médio
Baixo

Do not rely only on colors.

==================================================
28. LOW STOCK ALERT
==================================================

The system must alert the food truck owner when an inventory item reaches 20% or less of its defined stock capacity/minimum threshold.

Example:

"Estoque baixo"

"Queijo Cheddar está com apenas 18% do estoque disponível."

Create a notification system for this.

==================================================
29. RESTOCKING
==================================================

Create a dedicated:

"Reabastecimento"

page.

The owner can:

select inventory item;
see current quantity;
enter added quantity;
see new quantity;
add observation;
confirm restocking.

Every restocking action must be recorded in history.

==================================================
30. INVENTORY ESTIMATION
==================================================

The project should include a prototype of inventory consumption forecasting.

Do NOT claim that this is a real AI system.

Use available historical data such as:

- current quantity;
- recent consumption;
- average consumption.

Example:

"Estimativa baseada no histórico de consumo."

"Com o consumo atual, este estoque pode atender aproximadamente 42 pedidos."

If there is insufficient historical data:

"Dados insuficientes para realizar uma estimativa."

Do NOT invent predictions.

==================================================
31. CUSTOMERS
==================================================

Food truck owners can view customers related to their food truck.

Customers must be ordered alphabetically.

Example:

Ana Lima
Carlos Rocha
João Silva
Maria Santos

Clicking a customer should show:

Nome
E-mail
Quantidade de pedidos
Últimos pedidos
Avaliações
Total gasto

Only information related to that food truck should be shown.

==================================================
32. HISTORY / AUDIT LOG
==================================================

Create a complete history page.

Record actions such as:

Produto criado
Produto editado
Produto excluído
Estoque alterado
Reabastecimento realizado
Pedido atualizado
Promoção criada
Food Truck aberto
Food Truck fechado
Configuração alterada

Each history record should show:

Data
Hora
Ação
Responsável
Descrição

==================================================
33. PROMOTIONS
==================================================

Food trucks can:

Create promotions
Edit promotions
Activate/deactivate promotions
Delete promotions

Example:

Combo Família

De:
R$ 60,00

Por:
R$ 49,90

==================================================
34. REVIEWS
==================================================

After a completed order, the customer can evaluate the food truck.

Rating:

1 to 5 stars.

Optional comment.

Reviews must belong to the appropriate food truck.

==================================================
35. CUSTOMER FEEDBACK
==================================================

Create a section:

"Reclamações e sugestões"

Options:

Reclamação
Sugestão
Elogio

Fields:

Tipo
Assunto
Mensagem

Button:

Enviar

After sending:

"Obrigado pelo seu feedback!"

==================================================
36. RECOMMENDATIONS
==================================================

The system should recognize a customer's frequently purchased products.

If a customer has purchased the same product 3 or more times:

show it as a recommendation.

Example:

"Seu favorito está aqui!"

"Você já pediu este produto 3 vezes."

This recommendation should be based on actual order history.

Do NOT invent customer history.

==================================================
37. FOOD TRUCK SETTINGS
==================================================

The owner can edit:

Nome
Descrição
Categoria
Telefone
Localização
Logo/imagem
Horários
Status

==================================================
38. DELETE FOOD TRUCK
==================================================

The owner must have the ability to stop using CyberFood.

Create a:

"Zona de perigo"

section inside settings.

Option:

"Excluir Food Truck"

Explain clearly that deletion is permanent.

Require confirmation before deleting.

For example:

"Digite o nome do Food Truck para confirmar."

After deletion:

- the food truck disappears from the public platform;
- the owner is logged out;
- the owner returns to the public homepage.

The owner must NOT be able to delete another food truck.

==================================================
39. CLIENT ACCOUNT
==================================================

Client profile should contain:

Nome
E-mail
Pedidos
Favoritos
Último pedido

Allow logout.

==================================================
40. VISUAL DESIGN
==================================================

The visual identity must feel:

Modern
Professional
Clean
Young
Gastronomic
Technological
Friendly

Avoid:

- excessive neon;
- excessive glow;
- heavy black borders;
- excessive gradients;
- clutter;
- too many colors;
- childish UI.

The interface should feel like a modern Brazilian startup.

==================================================
41. COLOR SYSTEM
==================================================

Use a harmonious LIGHT MODE.

Primary CyberFood orange:

#F97316

Dark orange:

#EA580C

Background:

#FFFDF9

Secondary background:

#FFF7ED

Cards:

#FFFFFF

Primary text:

#172033

Secondary text:

#64748B

Borders:

#E7E5E4

Success:

#16A34A

Warning:

#D97706

Error:

#DC2626

Dark blue/navy:

#172033

IMPORTANT:

Orange is the brand color.

Do NOT make the entire interface orange.

Use orange primarily for:

- primary buttons;
- CTAs;
- active states;
- important highlights;
- branding.

==================================================
42. DARK MODE
==================================================

Also create a dark mode.

Allow the user to switch between:

☀️ Light
🌙 Dark

Dark mode must have its own harmonious color hierarchy.

Do not simply invert all colors.

==================================================
43. BORDERS AND CARDS
==================================================

Avoid excessive borders.

Do not put heavy black outlines around everything.

Use:

- whitespace;
- subtle shadows;
- soft borders;
- hierarchy;
- surface contrast.

Cards should feel light and modern.

==================================================
44. TYPOGRAPHY
==================================================

Use a modern, highly readable font.

Create clear hierarchy:

H1
H2
H3
Body
Caption

The CyberFood logo can have personality.

The rest of the interface should prioritize readability.

==================================================
45. RESPONSIVE DESIGN
==================================================

The entire application must work on:

Desktop
Tablet
Mobile

Desktop:

Sidebar for food truck management.

Mobile:

Sidebar becomes a menu/drawer.

Cards adapt.

Checkout becomes vertical.

Header adapts.

Search adapts.

==================================================
46. ACCESSIBILITY
==================================================

Use:

- readable contrast;
- visible focus states;
- labels for inputs;
- accessible buttons;
- clear status text;
- keyboard-friendly interaction.

Do not communicate important information using color alone.

==================================================
47. EMPTY STATES
==================================================

Create polished empty states.

Examples:

No products:

"Você ainda não possui produtos."
[Adicionar produto]

No inventory:

"Seu estoque está vazio."
[Adicionar item]

No orders:

"Você ainda não recebeu pedidos."

No favorites:

"Você ainda não favoritou nenhum Food Truck."

New food truck:

"Bem-vindo ao CyberFood!"
"Seu Food Truck está pronto para começar."

==================================================
48. PERSISTENCE
==================================================

For this frontend prototype, use local state/localStorage or an equivalent frontend persistence mechanism.

If a user:

- creates an account;
- creates a food truck;
- creates a product;
- changes inventory;
- creates an order;
- favorites a food truck;

the state should persist after refreshing the page.

==================================================
49. IMPORTANT SYSTEM RULES
==================================================

RULE 1:
A visitor can browse without login.

RULE 2:
Login is required for personal actions.

RULE 3:
A new client account starts with no history.

RULE 4:
A new food truck account starts completely empty.

RULE 5:
Demonstration data must NEVER be copied into newly created accounts.

RULE 6:
Each food truck sees only its own management data.

RULE 7:
A closed food truck cannot accept new orders.

RULE 8:
Closing a food truck does not cancel existing orders.

RULE 9:
There is NO delivery.

RULE 10:
All orders are pickup orders.

RULE 11:
A cart cannot contain products from multiple food trucks.

RULE 12:
Deleting a food truck removes it from the public platform.

RULE 13:
All important management actions should be recorded in history.

RULE 14:
Inventory status must include High / Medium / Low.

RULE 15:
Low inventory alerts must appear at the configured threshold.

==================================================
50. DATA MODEL CONCEPT
==================================================

Structure the application around entities such as:

User
FoodTruck
Product
InventoryItem
Order
OrderItem
Favorite
Review
Promotion
Restock
AuditLog
Feedback

Important relationships:

User → Client or Food Truck Owner

FoodTruck → Products

FoodTruck → Inventory

FoodTruck → Orders

FoodTruck → Reviews

FoodTruck → Promotions

FoodTruck → AuditLogs

Client → Orders

Client → Favorites

Client → Reviews

Every food truck-specific entity must be associated with its foodTruckId.

==================================================
51. INITIAL DEMONSTRATION DATA
==================================================

Create a small set of realistic demonstration food trucks so the public homepage is not empty on first launch.

Use different cuisines.

Example:

Burger Express
Taco Loco
Pizza Street
Asia Fusion
Banana King

Do not make all menus hamburgers.

Each should have its own culinary identity.

These are ONLY demonstration food trucks.

==================================================
52. DESIGN THE MAIN NAVIGATION
==================================================

PUBLIC:

Home
Food Trucks
Login

CLIENT:

Home
Food Trucks
Favoritos
Pedidos
Perfil
Carrinho

FOOD TRUCK:

Dashboard
Pedidos
Produtos
Estoque
Reabastecimento
Promoções
Clientes
Histórico
Configurações

==================================================
53. REQUIRED USER FLOWS
==================================================

FLOW A — Visitor

Home
→ Explore Food Trucks
→ Open Food Truck
→ View Menu

FLOW B — Visitor tries to buy

Home
→ Food Truck
→ Product
→ Add to Cart
→ Login
→ Return to intended action
→ Cart
→ Checkout
→ Confirm Order
→ Order Tracking

FLOW C — Client

Login
→ Client Home
→ Favorites / Food Trucks
→ Food Truck
→ Menu
→ Cart
→ Checkout
→ Order
→ Tracking

FLOW D — Food Truck registration

Home
→ Login
→ Food Truck
→ Create Account
→ Complete registration
→ Create Food Truck
→ Empty Dashboard

FLOW E — Food Truck operation

Login
→ Dashboard
→ Add Product
→ Add Inventory
→ Open Food Truck
→ Receive Order
→ Accept
→ Preparing
→ Ready
→ Pickup

FLOW F — Delete Food Truck

Settings
→ Danger Zone
→ Delete Food Truck
→ Confirm
→ Remove Food Truck
→ Logout
→ Home

==================================================
54. IMPORTANT IMPLEMENTATION PRINCIPLE
==================================================

Do not only create pretty screens.

The system must behave coherently.

For example:

Creating a product
→ product appears in that food truck's menu.

Deleting a product
→ product disappears from the menu.

Changing inventory
→ inventory dashboard updates.

Low stock
→ notification appears.

Closing food truck
→ new purchases are blocked.

Opening food truck
→ new purchases become available.

Creating a new food truck
→ it appears publicly.

New food truck
→ has zero products, zero inventory, zero orders and zero statistics.

Creating an order
→ order appears in food truck management.

Changing order status
→ customer sees the new status.

Deleting a food truck
→ it disappears from public discovery.

==================================================
55. FIRST IMPLEMENTATION PRIORITY
==================================================

DO NOT try to rush every advanced feature immediately.

Build the foundation correctly.

Start in this order:

1. Design system
2. Global layout
3. Public homepage
4. Food truck discovery
5. Food truck detail/menu
6. Authentication
7. Client experience
8. Food truck registration
9. Food truck dashboard
10. Products
11. Inventory
12. Orders
13. Settings
14. History
15. Advanced features

The architecture must allow the later features to connect naturally.

==================================================
56. FINAL QUALITY REQUIREMENT
==================================================

The final CyberFood should feel like a real product, not a school template.

Prioritize:

UX
Consistency
Visual hierarchy
Navigation
Data isolation
Responsive design
Accessibility
Realistic interactions
Clear empty states
Consistent visual identity

Do not fill screens with fake information just to make them look full.

Do not invent functionality that contradicts the rules above.

Do not create delivery functionality.

Do not force login before browsing food trucks.

Do not copy demonstration data into new accounts.

Do not mix data between food trucks.

Before considering the foundation complete, verify that the main user flows are coherent and connected.

IMPORTANT:
This is the FOUNDATION PROMPT.
First create the complete visual foundation, navigation structure, data architecture and core screens.

Do not sacrifice the quality of the foundation by trying to cram every feature into one screen.

Make the interface polished, coherent, modern and presentation-ready for a TCC.