import { useNavigate } from 'react-router-dom'
import { useApp } from '../../context/AppContext'
import type { SubscriptionPlan } from '../../lib/types'

const PLAN_LEVELS: Record<SubscriptionPlan, number> = { free: 0, essential: 1, professional: 2 }
const PLAN_NAMES: Record<SubscriptionPlan, string> = { free: 'Gratuito', essential: 'Essencial', professional: 'Profissional' }

interface PlanGateProps {
  requiredPlan: SubscriptionPlan
  featureName: string
  children: React.ReactNode
}

export function PlanGate({ requiredPlan, featureName, children }: PlanGateProps) {
  const { getMyFoodTruck } = useApp()
  const navigate = useNavigate()
  const ft = getMyFoodTruck()

  if (!ft) return null
  if (PLAN_LEVELS[ft.subscriptionPlan] >= PLAN_LEVELS[requiredPlan]) return <>{children}</>

  return (
    <div className="flex flex-col items-center justify-center py-20 text-center max-w-sm mx-auto">
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5"
        style={{ background: 'var(--primary-soft)' }}
      >
        <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--primary)' }}>
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0110 0v4" />
        </svg>
      </div>
      <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text)' }}>{featureName}</h3>
      <p className="text-sm mb-6 leading-relaxed" style={{ color: 'var(--text-muted)' }}>
        Este recurso está disponível a partir do plano <strong>{PLAN_NAMES[requiredPlan]}</strong>.
        Faça upgrade para desbloquear.
      </p>
      <button
        onClick={() => navigate('/manage/plans')}
        className="px-6 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90"
        style={{ background: 'var(--primary)' }}
      >
        Ver planos
      </button>
    </div>
  )
}
