import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import type { FoodTruck } from '../lib/types'

function Stars({ rating }: { rating: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <svg key={i} width="12" height="12" viewBox="0 0 24 24" fill={i <= Math.round(rating) ? '#F59E0B' : 'none'} stroke="#F59E0B" strokeWidth="2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      ))}
    </span>
  )
}

export default function FoodTruckCard({ ft }: { ft: FoodTruck }) {
  const { currentUser, isFavorite, toggleFavorite, openAuthModal } = useApp()
  const navigate = useNavigate()
  const fav = isFavorite(ft.id)

  const handleFavorite = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (!currentUser) {
      openAuthModal('login', `/food-truck/${ft.id}`)
      return
    }
    toggleFavorite(ft.id)
  }

  return (
    <Link to={`/food-truck/${ft.id}`} className="group block">
      <div
        className="rounded-2xl overflow-hidden transition-all duration-200 hover:-translate-y-1 cursor-pointer"
        style={{ background: 'var(--card)', boxShadow: 'var(--shadow-sm)', border: '1px solid var(--border)' }}
      >
        {/* Image */}
        <div className="relative h-44 overflow-hidden" style={{ background: 'var(--surface)' }}>
          <img
            src={ft.image}
            alt={ft.name}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          {/* Status badge */}
          <div
            className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
            style={{
              background: ft.isOpen ? 'rgba(22,163,74,0.92)' : 'rgba(100,116,139,0.92)',
              color: 'white',
              backdropFilter: 'blur(4px)',
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: ft.isOpen ? '#86EFAC' : '#CBD5E1' }} />
            {ft.isOpen ? 'Aberto' : 'Fechado'}
          </div>
          {/* Favorite */}
          <button
            onClick={handleFavorite}
            className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
            style={{ background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)' }}
            aria-label={fav ? 'Desfavoritar' : 'Favoritar'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill={fav ? '#EF4444' : 'none'} stroke={fav ? '#EF4444' : '#64748B'} strokeWidth="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
            </svg>
          </button>
          {/* Prep time */}
          <div
            className="absolute bottom-3 right-3 px-2 py-1 rounded-lg text-xs font-medium"
            style={{ background: 'rgba(23,32,51,0.8)', color: 'white', backdropFilter: 'blur(4px)' }}
          >
            {ft.prepTime}
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-bold text-base leading-tight" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>
              {ft.name}
            </h3>
            <span
              className="flex-shrink-0 text-xs px-2 py-0.5 rounded-full font-medium"
              style={{ background: 'var(--primary-soft)', color: 'var(--primary-dark)' }}
            >
              {ft.category}
            </span>
          </div>

          <p className="text-xs mb-3 line-clamp-2" style={{ color: 'var(--text-muted)' }}>{ft.description}</p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Stars rating={ft.avgRating} />
              <span className="text-xs font-semibold" style={{ color: 'var(--text)' }}>{ft.avgRating > 0 ? ft.avgRating.toFixed(1) : '—'}</span>
              {ft.totalReviews > 0 && <span className="text-xs" style={{ color: 'var(--text-muted)' }}>({ft.totalReviews})</span>}
            </div>
            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{ft.location.split(',')[0]}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}
