import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function AuthModal() {
  const { authModal, closeAuthModal, openAuthModal, login, registerClient, currentUser } = useApp()
  const navigate = useNavigate()
  const { open, mode, returnTo } = authModal

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    setEmail(''); setPassword(''); setName(''); setConfirmPassword(''); setError('')
  }, [mode, open])

  if (!open) return null

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    const result = login(email, password)
    setLoading(false)
    if (!result.ok) { setError(result.error || ''); return }
    closeAuthModal()
    // Always determine destination by account type — owners never enter the client experience
    const users = JSON.parse(localStorage.getItem('cf_users') || '[]')
    const user = users.find((u: { email: string }) => u.email.toLowerCase() === email.toLowerCase())
    if (user?.type === 'owner') {
      navigate('/manage')
    } else {
      navigate(returnTo || '/client')
    }
  }

  const handleRegisterClient = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    const trimmedEmail = email.trim().toLowerCase()
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Informe um e-mail válido.'); return
    }
    if (password !== password.trim()) { setError('A senha não pode ter espaços no início ou no fim.'); return }
    if (password.length < 8) { setError('A senha deve ter pelo menos 8 caracteres.'); return }
    if (password !== confirmPassword) { setError('As senhas não coincidem.'); return }
    setLoading(true)
    const result = registerClient(name.trim(), trimmedEmail, password)
    setLoading(false)
    if (!result.ok) { setError(result.error || ''); return }
    closeAuthModal()
    navigate(returnTo || '/client')
  }

  const baseInput = 'w-full px-4 py-2.5 rounded-xl text-sm outline-none transition-all'
  const inputStyle = { background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
      <div
        className="w-full max-w-md rounded-2xl p-6 relative"
        style={{ background: 'var(--card)', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--border)' }}
      >
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:bg-[var(--surface)]"
          style={{ color: 'var(--text-muted)' }}
          aria-label="Fechar"
        >
          ✕
        </button>

        {/* Logo */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-0.5 mb-2">
            <span className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--primary)' }}>Cyber</span>
            <span className="text-2xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Food</span>
          </div>
          {mode === 'login' && <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Bem-vindo de volta!</p>}
          {mode === 'register-client' && <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Crie sua conta de cliente</p>}
        </div>

        {/* Tab switcher */}
        {(mode === 'login' || mode === 'register-client') && (
          <div className="flex rounded-xl p-1 mb-5" style={{ background: 'var(--surface)' }}>
            <button
              onClick={() => openAuthModal('login', returnTo)}
              className="flex-1 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: mode === 'login' ? 'var(--card)' : 'transparent',
                color: mode === 'login' ? 'var(--primary)' : 'var(--text-muted)',
                boxShadow: mode === 'login' ? 'var(--shadow-sm)' : 'none',
              }}
            >
              Entrar
            </button>
            <button
              onClick={() => openAuthModal('register-client', returnTo)}
              className="flex-1 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: mode === 'register-client' ? 'var(--card)' : 'transparent',
                color: mode === 'register-client' ? 'var(--primary)' : 'var(--text-muted)',
                boxShadow: mode === 'register-client' ? 'var(--shadow-sm)' : 'none',
              }}
            >
              Criar conta
            </button>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mb-4 px-4 py-3 rounded-xl text-sm font-medium" style={{ background: 'var(--error-soft)', color: 'var(--error)' }}>
            {error}
          </div>
        )}

        {/* Login */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-3">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>E-mail</label>
              <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className={baseInput} style={inputStyle} placeholder="seu@email.com" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>Senha</label>
              <input type="password" required value={password} onChange={e => setPassword(e.target.value)} className={baseInput} style={inputStyle} placeholder="••••••••" />
            </div>
            <button type="button" className="text-sm" style={{ color: 'var(--primary)' }}>Esqueci minha senha</button>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-sm font-bold text-white mt-2 transition-all hover:opacity-90 disabled:opacity-50"
              style={{ background: 'var(--primary)' }}
            >
              {loading ? 'Entrando...' : 'Entrar'}
            </button>

            <div className="text-center text-sm" style={{ color: 'var(--text-muted)' }}>
              Não tem uma conta?{' '}
              <button type="button" onClick={() => openAuthModal('register-client', returnTo)} className="font-medium" style={{ color: 'var(--primary)' }}>
                Criar conta
              </button>
            </div>

            <div className="border-t pt-3 mt-3" style={{ borderColor: 'var(--border)' }}>
              <p className="text-center text-xs mb-2" style={{ color: 'var(--text-muted)' }}>Tem um food truck?</p>
              <button
                type="button"
                onClick={() => { closeAuthModal(); navigate('/register/food-truck') }}
                className="w-full py-2.5 rounded-xl text-sm font-medium transition-all hover:opacity-90"
                style={{ background: 'var(--surface)', border: '1.5px solid var(--border)', color: 'var(--text)' }}
              >
                Cadastrar Food Truck
              </button>
            </div>
          </form>
        )}

        {/* Register Client */}
        {mode === 'register-client' && (
          <form onSubmit={handleRegisterClient} className="space-y-3">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>Nome completo</label>
              <input required value={name} onChange={e => setName(e.target.value)} className={baseInput} style={inputStyle} placeholder="Seu nome" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>E-mail</label>
              <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className={baseInput} style={inputStyle} placeholder="seu@email.com" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>Senha</label>
              <input type="password" required value={password} onChange={e => setPassword(e.target.value)} className={baseInput} style={inputStyle} placeholder="Mínimo 6 caracteres" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text)' }}>Confirmar senha</label>
              <input type="password" required value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className={baseInput} style={inputStyle} placeholder="Repita a senha" />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-sm font-bold text-white mt-2 transition-all hover:opacity-90 disabled:opacity-50"
              style={{ background: 'var(--primary)' }}
            >
              {loading ? 'Criando conta...' : 'Criar conta'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
