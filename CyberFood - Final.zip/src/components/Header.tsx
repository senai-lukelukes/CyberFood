import { useState, useRef, useEffect } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function Header() {
  const { currentUser, logout, openAuthModal, cart, toggleTheme, theme } = useApp()
  const navigate = useNavigate()
  const location = useLocation()
  const [loginOpen, setLoginOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const [search, setSearch] = useState('')
  const loginRef = useRef<HTMLDivElement>(null)
  const userRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (loginRef.current && !loginRef.current.contains(e.target as Node)) setLoginOpen(false)
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const cartCount = cart.items.reduce((s, i) => s + i.quantity, 0)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (search.trim()) navigate(`/?q=${encodeURIComponent(search.trim())}`)
  }

  const handleLogout = () => {
    logout()
    setUserOpen(false)
    navigate('/')
  }

  return (
    <header
      className="sticky top-0 z-40 border-b"
      style={{ background: 'var(--card)', borderColor: 'var(--border)', boxShadow: 'var(--shadow-sm)' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-4 h-16">
        {/* Logo */}
        <Link to="/" className="flex-shrink-0 flex items-center gap-0.5">
          <span className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--primary)' }}>Cyber</span>
          <span className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--text)' }}>Food</span>
        </Link>

        {/* Search */}
        <form onSubmit={handleSearch} className="flex-1 max-w-xl mx-auto hidden sm:block">
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--text-muted)' }} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar food trucks ou pratos..."
              className="w-full pl-9 pr-4 py-2 rounded-full text-sm outline-none"
              style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)' }}
            />
          </div>
        </form>

        <div className="flex-1 sm:flex-none" />

        {/* Right nav */}
        <nav className="flex items-center gap-1">
          <Link to="/" className="hidden md:flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-all hover:bg-[var(--surface)]" style={{ color: 'var(--text)' }}>
            Food Trucks
          </Link>

          {currentUser?.type === 'client' && (
            <Link to="/client/favorites" className="hidden md:flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-all hover:bg-[var(--surface)]" style={{ color: 'var(--text)' }}>
              Favoritos
            </Link>
          )}
          {!currentUser && (
            <Link to="/" className="hidden md:flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-all hover:bg-[var(--surface)]" style={{ color: 'var(--text)' }}>
              Favoritos
            </Link>
          )}

          {/* Theme */}
          <button
            onClick={toggleTheme}
            className="w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:bg-[var(--surface)]"
            style={{ color: 'var(--text-muted)' }}
            aria-label="Alternar tema"
          >
            {theme === 'light' ? (
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" />
            </svg>
          ) : (
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="5" /><line x1="12" y1="1" x2="12" y2="3" /><line x1="12" y1="21" x2="12" y2="23" /><line x1="4.22" y1="4.22" x2="5.64" y2="5.64" /><line x1="18.36" y1="18.36" x2="19.78" y2="19.78" /><line x1="1" y1="12" x2="3" y2="12" /><line x1="21" y1="12" x2="23" y2="12" /><line x1="4.22" y1="19.78" x2="5.64" y2="18.36" /><line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>
          )}
          </button>

          {/* Cart */}
          {currentUser?.type === 'client' && (
            <Link
              to="/client/cart"
              className="relative w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:bg-[var(--surface)]"
              style={{ color: 'var(--text)' }}
              aria-label="Carrinho"
            >
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
                <line x1="3" x2="21" y1="6" y2="6" />
                <path d="M16 10a4 4 0 0 1-8 0" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-white text-[10px] font-bold flex items-center justify-center" style={{ background: 'var(--primary)' }}>
                  {cartCount > 9 ? '9+' : cartCount}
                </span>
              )}
            </Link>
          )}

          {/* Logged-in user */}
          {currentUser ? (
            <div className="relative" ref={userRef}>
              <button
                onClick={() => setUserOpen(o => !o)}
                className="flex items-center gap-2 px-2 py-1.5 rounded-lg transition-all hover:bg-[var(--surface)]"
              >
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: 'var(--primary)' }}>
                  {currentUser.name[0]?.toUpperCase()}
                </div>
                <span className="hidden sm:block text-sm font-medium" style={{ color: 'var(--text)' }}>
                  {currentUser.name.split(' ')[0]}
                </span>
                <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24" style={{ color: 'var(--text-muted)' }}>
                  <path d="m6 9 6 6 6-6" />
                </svg>
              </button>
              {userOpen && (
                <div className="absolute right-0 top-full mt-2 w-52 rounded-xl py-1 z-50" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-lg)' }}>
                  <div className="px-4 py-2 border-b" style={{ borderColor: 'var(--border)' }}>
                    <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>{currentUser.name}</p>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{currentUser.email}</p>
                  </div>
                  {currentUser.type === 'client' ? (
                    <>
                      <MenuItem to="/client" label="Início" onClick={() => setUserOpen(false)} />
                      <MenuItem to="/client/orders" label="Meus Pedidos" onClick={() => setUserOpen(false)} />
                      <MenuItem to="/client/favorites" label="Favoritos" onClick={() => setUserOpen(false)} />
                      <MenuItem to="/client/profile" label="Perfil" onClick={() => setUserOpen(false)} />
                    </>
                  ) : (
                    <MenuItem to="/manage" label="Painel de Gestão" onClick={() => setUserOpen(false)} />
                  )}
                  <div className="border-t mt-1 pt-1" style={{ borderColor: 'var(--border)' }}>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm transition-all hover:bg-[var(--surface)]"
                      style={{ color: 'var(--error)' }}
                    >
                      Sair
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="relative" ref={loginRef}>
              <button
                onClick={() => setLoginOpen(o => !o)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold text-white transition-all hover:opacity-90"
                style={{ background: 'var(--primary)' }}
              >
                Login
                <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path d="m6 9 6 6 6-6" />
                </svg>
              </button>
              {loginOpen && (
                <div className="absolute right-0 top-full mt-2 w-48 rounded-xl py-2 z-50" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-lg)' }}>
                  <p className="px-4 py-1 text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Entrar como</p>
                  <button
                    onClick={() => { setLoginOpen(false); openAuthModal('login') }}
                    className="w-full text-left px-4 py-2.5 text-sm font-medium transition-all hover:bg-[var(--surface)]"
                    style={{ color: 'var(--text)' }}
                  >
                    Cliente
                  </button>
                  <button
                    onClick={() => { setLoginOpen(false); openAuthModal('login') }}
                    className="w-full text-left px-4 py-2.5 text-sm font-medium transition-all hover:bg-[var(--surface)]"
                    style={{ color: 'var(--text)' }}
                  >
                    Food Truck
                  </button>
                  <div className="border-t mx-4 my-1" style={{ borderColor: 'var(--border)' }} />
                  <button
                    onClick={() => { setLoginOpen(false); openAuthModal('register-client') }}
                    className="w-full text-left px-4 py-2.5 text-sm transition-all hover:bg-[var(--surface)]"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    Criar conta
                  </button>
                </div>
              )}
            </div>
          )}
        </nav>
      </div>
    </header>
  )
}

function MenuItem({ to, label, onClick }: { to: string; label: string; onClick: () => void }) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="block px-4 py-2 text-sm transition-all hover:bg-[var(--surface)]"
      style={{ color: 'var(--text)' }}
    >
      {label}
    </Link>
  )
}
