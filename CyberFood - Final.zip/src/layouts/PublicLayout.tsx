import { Outlet } from 'react-router-dom'
import Header from '../components/Header'

export default function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--bg)', color: 'var(--text)' }}>
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <footer style={{ background: 'var(--navy)', color: '#94A3B8' }} className="py-8 px-6 text-center text-sm mt-16">
        <p className="font-semibold text-white mb-1" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif' }}>CyberFood</p>
        <p>© 2025 CyberFood. Todos os direitos reservados.</p>
        <p className="mt-1 text-xs opacity-60">Plataforma de food trucks • Retirada no local</p>
      </footer>
    </div>
  )
}
