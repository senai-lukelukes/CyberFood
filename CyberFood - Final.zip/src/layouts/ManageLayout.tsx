import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useApp } from '../context/AppContext'

type NavItem = { to: string; label: string; icon: string; end: boolean }

const NAV: NavItem[] = [
  { to: '/manage', label: 'Dashboard', icon: 'dashboard', end: true },
  { to: '/manage/orders', label: 'Pedidos', icon: 'orders', end: false },
  { to: '/manage/products', label: 'Produtos', icon: 'products', end: false },
  { to: '/manage/inventory', label: 'Estoque', icon: 'inventory', end: false },
  { to: '/manage/restocking', label: 'Reabastecimento', icon: 'restocking', end: false },
  { to: '/manage/lots', label: 'Lotes', icon: 'lots', end: false },
  { to: '/manage/promotions', label: 'Promoções', icon: 'promotions', end: false },
  { to: '/manage/customers', label: 'Clientes', icon: 'customers', end: false },
  { to: '/manage/history', label: 'Histórico', icon: 'history', end: false },
  { to: '/manage/settings', label: 'Configurações', icon: 'settings', end: false },
  { to: '/manage/waste', label: 'Descartes', icon: 'waste', end: false },
  { to: '/manage/analytics', label: 'Análises', icon: 'analytics', end: false },
  { to: '/manage/forecasting', label: 'Previsão', icon: 'forecasting', end: false },
  { to: '/manage/plans', label: 'Planos', icon: 'plans', end: false },
]

function NavIcon({ name }: { name: string }) {
  const cls = "w-[18px] h-[18px] flex-shrink-0"
  const shared = { fill: 'none' as const, stroke: 'currentColor' as const, strokeWidth: 1.75, viewBox: '0 0 24 24', strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const }

  if (name === 'dashboard') return (
    <svg className={cls} {...shared}>
      <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" />
    </svg>
  )
  if (name === 'orders') return (
    <svg className={cls} {...shared}>
      <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" /><rect x="9" y="3" width="6" height="4" rx="1" /><line x1="9" y1="12" x2="15" y2="12" /><line x1="9" y1="16" x2="13" y2="16" />
    </svg>
  )
  if (name === 'products') return (
    <svg className={cls} {...shared}>
      <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
    </svg>
  )
  if (name === 'inventory') return (
    <svg className={cls} {...shared}>
      <path d="M21 8v13H3V8" /><path d="M23 3H1v5h22V3z" /><line x1="10" y1="12" x2="14" y2="12" />
    </svg>
  )
  if (name === 'lots') return (
    <svg className={cls} {...shared}>
      <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
    </svg>
  )
  if (name === 'restocking') return (
    <svg className={cls} {...shared}>
      <polyline points="23 4 23 10 17 10" /><polyline points="1 20 1 14 7 14" /><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15" />
    </svg>
  )
  if (name === 'promotions') return (
    <svg className={cls} {...shared}>
      <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" /><line x1="7" y1="7" x2="7.01" y2="7" />
    </svg>
  )
  if (name === 'customers') return (
    <svg className={cls} {...shared}>
      <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 00-3-3.87" /><path d="M16 3.13a4 4 0 010 7.75" />
    </svg>
  )
  if (name === 'history') return (
    <svg className={cls} {...shared}>
      <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
    </svg>
  )
  if (name === 'settings') return (
    <svg className={cls} {...shared}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
    </svg>
  )
  if (name === 'plans') return (
    <svg className={cls} {...shared}>
      <rect x="1" y="4" width="22" height="16" rx="2" ry="2" /><line x1="1" y1="10" x2="23" y2="10" />
    </svg>
  )
  if (name === 'waste') return (
    <svg className={cls} {...shared}>
      <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2M10 11v6M14 11v6"/>
    </svg>
  )
  if (name === 'analytics') return (
    <svg className={cls} {...shared}>
      <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
    </svg>
  )
  if (name === 'forecasting') return (
    <svg className={cls} {...shared}>
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
    </svg>
  )
  return null
}

export default function ManageLayout() {
  const { currentUser, getMyFoodTruck, toggleFoodTruckOpen, logout, toggleTheme, theme } = useApp()
  const ft = getMyFoodTruck()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = () => { logout(); navigate('/') }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: 'var(--bg)' }}>
      {sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside
        className={`fixed lg:static inset-y-0 left-0 z-30 w-64 flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
        style={{ background: 'var(--navy)', borderRight: '1px solid rgba(255,255,255,0.07)' }}
      >
        {/* Logo */}
        <div className="px-6 py-5 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          <div className="flex items-center gap-0.5">
            <span className="text-xl font-black" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', color: 'var(--primary)' }}>Cyber</span>
            <span className="text-xl font-black text-white" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif' }}>Food</span>
          </div>
          {ft && <p className="text-xs mt-1 truncate" style={{ color: '#94A3B8' }}>{ft.name}</p>}
        </div>

        {/* Status toggle */}
        {ft && (
          <div className="px-4 py-3 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
            <button
              onClick={() => toggleFoodTruckOpen(ft.id)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: ft.isOpen ? 'rgba(22,163,74,0.15)' : 'rgba(220,38,38,0.12)',
                color: ft.isOpen ? '#4ADE80' : '#F87171',
              }}
            >
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full" style={{ background: ft.isOpen ? '#4ADE80' : '#F87171' }} />
                {ft.isOpen ? 'Aberto' : 'Fechado'}
              </span>
              <span className="text-xs opacity-60">{ft.isOpen ? 'Fechar' : 'Abrir'}</span>
            </button>
          </div>
        )}

        {/* Nav */}
        <nav className="flex-1 px-3 py-3 overflow-y-auto space-y-0.5">
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${isActive ? 'text-white' : 'hover:text-white'}`
              }
              style={({ isActive }) => ({
                background: isActive ? 'rgba(249,115,22,0.2)' : 'transparent',
                color: isActive ? '#FB923C' : '#94A3B8',
              })}
            >
              <NavIcon name={item.icon} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Bottom */}
        <div className="px-3 py-3 border-t space-y-1" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          <button
            onClick={toggleTheme}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all hover:text-white"
            style={{ color: '#94A3B8' }}
          >
            {theme === 'light' ? (
              <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="1.75" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" />
              </svg>
            ) : (
              <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="1.75" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="5" /><line x1="12" y1="1" x2="12" y2="3" /><line x1="12" y1="21" x2="12" y2="23" /><line x1="4.22" y1="4.22" x2="5.64" y2="5.64" /><line x1="18.36" y1="18.36" x2="19.78" y2="19.78" /><line x1="1" y1="12" x2="3" y2="12" /><line x1="21" y1="12" x2="23" y2="12" /><line x1="4.22" y1="19.78" x2="5.64" y2="18.36" /><line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
              </svg>
            )}
            {theme === 'light' ? 'Modo Escuro' : 'Modo Claro'}
          </button>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all hover:text-white"
            style={{ color: '#94A3B8' }}
          >
            <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="1.75" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" />
            </svg>
            Sair
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex-shrink-0 flex items-center justify-between px-4 lg:px-6 py-3 border-b" style={{ background: 'var(--card)', borderColor: 'var(--border)' }}>
          <button
            className="lg:hidden p-2 rounded-lg"
            style={{ background: 'var(--surface)' }}
            onClick={() => setSidebarOpen(true)}
            aria-label="Abrir menu"
          >
            <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12h18M3 6h18M3 18h18" />
            </svg>
          </button>
          <div className="flex-1 lg:flex-none" />
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white" style={{ background: 'var(--primary)' }}>
                {currentUser?.name[0]?.toUpperCase()}
              </div>
              <span className="text-sm font-medium hidden sm:block" style={{ color: 'var(--text)' }}>{currentUser?.name.split(' ')[0]}</span>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
