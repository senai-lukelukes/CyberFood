# CyberFood Design Guidelines

## Brand
**CyberFood** — Brazilian food truck discovery and ordering platform.
Logotype: "Cyber" in brand orange + "Food" in dark text, Plus Jakarta Sans Black.

## Aesthetic Stance
Modern Brazilian startup. Clean, appetizing, and technological. Two distinct product faces:
- **Public/Client**: visual-first, warm, discovery-focused
- **Management**: professional, operational, dashboard-focused

## Typography
- **Display/Headings**: Plus Jakarta Sans (400–800) — modern, rounded, young energy
- **Body/UI**: Inter (400–600) — excellent readability
- Hierarchy: H1 32–48px Black | H2 24px Bold | H3 18px Bold | Body 14px Regular | Caption 12px

## Color System

### Light Mode (default)
| Token | Value | Usage |
|-------|-------|-------|
| `--bg` | #FFFDF9 | Page background |
| `--surface` | #FFF7ED | Secondary surfaces, inputs |
| `--card` | #FFFFFF | Cards, modals, panels |
| `--primary` | #F97316 | Brand orange — CTAs, actions |
| `--primary-dark` | #EA580C | Hover states |
| `--primary-soft` | #FED7AA | Subtle orange fills |
| `--text` | #172033 | Primary text, headings |
| `--text-muted` | #64748B | Secondary text, labels |
| `--border` | #E7E5E4 | Borders, dividers |
| `--success` | #16A34A | Open status, success |
| `--warning` | #D97706 | Low stock, alerts |
| `--error` | #DC2626 | Errors, critical |

### Dark Mode
Background deepens to #0F1117. Cards to #1C2333. Text inverts to warm near-white.

## Usage Rules
- Orange is the brand color — use for primary actions only, not backgrounds
- Status indicators always use both color AND text label (accessibility)
- Cards use soft shadow (`--shadow-sm`) and 1px border, not heavy outlines
- Use whitespace generously; avoid information overload

## Layout
- Public: max-w-7xl, 4-column responsive grid
- Management: fixed 256px sidebar + flex main
- Border radius: `--radius` 12px (cards), `--radius-sm` 8px (inputs/buttons)

## Components
All custom-built. Key patterns:
- **Pill badges**: rounded-full with `--*-soft` background + matching text color
- **Toggle switches**: custom CSS, 36×20px
- **Status indicators**: dot + label, never color alone
- **Cart FAB**: floating button with orange glow shadow

## Data Architecture
localStorage-based. Entities: User, FoodTruck, Product, InventoryItem, Order, Favorite, Review, Promotion, Restock, AuditLog, Feedback. All food-truck-specific entities carry `foodTruckId`.
